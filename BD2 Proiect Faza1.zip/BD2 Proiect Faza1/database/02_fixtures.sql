-- Date exclusiv fictive; reper calendaristic: 2 noiembrie 2026.
-- Rulati o singura data, dupa 01_schema.sql; toate cele 256 randuri se insereaza atomic.
BEGIN;
SET LOCAL search_path = broker_crm, public;

INSERT INTO agentii (id, denumire, cod_demo, email, oras, creat_la) VALUES
(1,'Broker Demo Bucuresti','DEMO-AG-001','bucuresti@broker.example','Bucuresti','2026-09-01 08:00:00+03'),
(2,'Broker Demo Cluj','DEMO-AG-002','cluj@broker.example','Cluj-Napoca','2026-09-01 08:00:00+03');

INSERT INTO brokeri (id, agentie_id, nume, email, rol)
SELECT n, (n-1)%2+1,
       (ARRAY['Ana Demo','Mihai Demo','Elena Demo','Andrei Demo','Ioana Demo','Vlad Demo'])[n],
       'broker'||n||'@broker.example',
       CASE WHEN n <= 2 THEN 'administrator' ELSE 'broker' END
FROM generate_series(1,6) AS n;

INSERT INTO clienti (id, agentie_id, broker_id, nume, tip, email, oras, stare, creat_la)
SELECT n, (n-1)%2+1, (n-1)%6+1,
       CASE WHEN n%4=0 THEN 'Firma Demo '||lpad(n::text,2,'0')||' SRL'
            ELSE (ARRAY['Alex','Maria','Radu','Diana','Paul','Irina'])[(n-1)%6+1]||' Client Demo '||lpad(n::text,2,'0') END,
       CASE WHEN n%4=0 THEN 'firma' ELSE 'persoana' END,
       'client'||n||'@client.example',
       CASE WHEN n%2=1 THEN 'Bucuresti' ELSE 'Cluj-Napoca' END,
       CASE WHEN n<=18 THEN 'client' ELSE 'prospect' END,
       '2026-09-02 09:00:00+03'::timestamptz + (n-1)*interval '1 hour'
FROM generate_series(1,24) AS n;

INSERT INTO asiguratori (id, denumire, cod_demo, email)
SELECT n, (ARRAY['Atlas Demo Asigurari','Orion Demo Asigurari','Nord Demo Asigurari','Safir Demo Asigurari','Meridian Demo Asigurari'])[n],
       'DEMO-AS-'||lpad(n::text,3,'0'), 'contact'||n||'@asigurator.example'
FROM generate_series(1,5) AS n;

INSERT INTO produse_asigurare (id, asigurator_id, cod, denumire, categorie, descriere)
SELECT (a.id-1)*3+c.nr, a.id, 'DEMO-PROD-'||a.id||'-'||c.nr,
       c.categorie||' Demo - '||a.denumire, c.categorie,
       'Produs fictiv pentru proiectul universitar; conditiile si preturile nu sunt oferte comerciale.'
FROM asiguratori a
CROSS JOIN (VALUES (1,'RCA'),(2,'CASCO'),(3,'LOCUINTA')) AS c(nr,categorie);

INSERT INTO oportunitati (id, agentie_id, client_id, broker_id, titlu, categorie, etapa, sursa, valoare_estimata, creat_la, inchis_la)
SELECT n, c.agentie_id, c.id, c.broker_id,
       'Asigurare '||(ARRAY['RCA','CASCO','LOCUINTA'])[(n-1)%3+1]||' - '||c.nume,
       (ARRAY['RCA','CASCO','LOCUINTA'])[(n-1)%3+1],
       CASE WHEN n<=18 THEN 'castigat' WHEN n<=22 THEN 'pierdut'
            ELSE (ARRAY['nou','contactat','ofertare','negociere'])[(n-23)%4+1] END,
       (ARRAY['website','recomandare','telefon','campanie'])[(n-1)%4+1],
       (ARRAY[1200,4800,600])[(n-1)%3+1] + n*20,
       CASE WHEN n<=22 THEN '2026-09-10 10:00:00+03'::timestamptz ELSE '2026-10-25 10:00:00+03'::timestamptz END,
       CASE WHEN n<=22 THEN '2026-09-25 16:00:00+03'::timestamptz ELSE NULL END
FROM generate_series(1,30) AS n
JOIN clienti c ON c.id=(n-1)%24+1;

INSERT INTO oferte (id, oportunitate_id, produs_id, categorie, numar, prima_anuala, suma_asigurata, stare, emisa_la, valabila_pana)
SELECT (o.id-1)*2+v.nr, o.id,
       (((o.id-1)+(v.nr-1))%5)*3 + (o.id-1)%3+1,
       o.categorie, 'OF-DEMO-2026-'||lpad(((o.id-1)*2+v.nr)::text,4,'0'),
       o.valoare_estimata+(v.nr-1)*100,
       CASE o.categorie WHEN 'RCA' THEN 6000000 WHEN 'CASCO' THEN 120000 ELSE 350000 END,
       CASE WHEN o.etapa='castigat' AND v.nr=1 THEN 'acceptata'
            WHEN o.etapa IN ('castigat','pierdut') THEN 'respinsa'
            WHEN o.etapa IN ('nou','contactat') THEN 'ciorna'
            WHEN v.nr=1 THEN 'trimisa' ELSE 'ciorna' END,
       CASE WHEN o.id<=22 THEN DATE '2026-09-12' ELSE DATE '2026-10-26' END,
       CASE WHEN o.id<=22 THEN DATE '2026-09-30' ELSE DATE '2026-11-15' END
FROM oportunitati o CROSS JOIN (VALUES (1),(2)) v(nr);

INSERT INTO polite (id, oferta_id, numar, inceput_la, sfarsit_la, stare, comision_procente, emisa_la)
SELECT n, (n-1)*2+1, 'POL-DEMO-2026-'||lpad(n::text,4,'0'),
       DATE '2026-10-01', DATE '2027-10-01', 'activa',
       CASE (n-1)%3 WHEN 0 THEN 8 WHEN 1 THEN 15 ELSE 20 END,
       DATE '2026-09-25'
FROM generate_series(1,18) n;

INSERT INTO activitati (id, oportunitate_id, tip, subiect, descriere, scadenta_la, finalizata_la, stare)
SELECT (o.id-1)*2+v.nr, o.id,
       CASE WHEN v.nr=1 THEN 'apel' ELSE 'sarcina' END,
       CASE WHEN v.nr=1 THEN 'Discutie initiala cu clientul' ELSE 'Revenire si actualizare dosar' END,
       CASE WHEN v.nr=1 THEN 'Confirmare cerinte de asigurare si pregatire comparatie oferte.'
            WHEN o.etapa='castigat' THEN 'Confirmare emitere polita si comunicare calendar rate.'
            WHEN o.etapa='pierdut' THEN 'Inregistrare motiv pierdere: oferta amanata de client.'
            ELSE 'Revenire la client pentru alegerea ofertei.' END,
       CASE WHEN v.nr=1 THEN o.creat_la+interval '2 hours'
            WHEN o.inchis_la IS NOT NULL THEN o.inchis_la+interval '1 hour'
            ELSE '2026-11-05 11:00:00+02'::timestamptz END,
       CASE WHEN v.nr=1 THEN o.creat_la+interval '2 hours 15 minutes'
            WHEN o.inchis_la IS NOT NULL THEN o.inchis_la+interval '1 hour 15 minutes'
            ELSE NULL END,
       CASE WHEN v.nr=1 OR o.inchis_la IS NOT NULL THEN 'finalizata' ELSE 'planificata' END
FROM oportunitati o CROSS JOIN (VALUES (1),(2)) v(nr);

INSERT INTO plati (id, polita_id, numar_rata, suma, scadenta_la, platita_la, metoda, referinta_demo, stare)
SELECT (p.id-1)*2+v.nr, p.id, v.nr, ofr.prima_anuala/2,
       CASE WHEN v.nr=1 THEN DATE '2026-10-01' ELSE DATE '2027-04-01' END,
       CASE WHEN v.nr=1 THEN DATE '2026-10-01' ELSE NULL END,
       CASE WHEN v.nr=1 THEN CASE WHEN p.id%2=0 THEN 'card' ELSE 'transfer' END ELSE NULL END,
       CASE WHEN v.nr=1 THEN 'DEMO-TXN-'||lpad(p.id::text,4,'0') ELSE NULL END,
       CASE WHEN v.nr=1 THEN 'platita' ELSE 'planificata' END
FROM polite p JOIN oferte ofr ON ofr.id=p.oferta_id CROSS JOIN (VALUES (1),(2)) v(nr);

-- Aliniere identitati dupa inserarea ID-urilor deterministe.
DO $$
DECLARE t text;
BEGIN
    FOREACH t IN ARRAY ARRAY['agentii','brokeri','clienti','asiguratori','produse_asigurare','oportunitati','oferte','polite','activitati','plati']
    LOOP
        EXECUTE format('SELECT setval(pg_get_serial_sequence(%L, %L), (SELECT max(id) FROM %I))', 'broker_crm.'||t, 'id', t);
    END LOOP;
END $$;
COMMIT;
