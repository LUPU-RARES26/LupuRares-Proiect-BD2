# Jurnal de utilizare a inteligenței artificiale

**Proiect:** CRM pentru brokeri de asigurări, inspirat de tipul de platformă AgencyZoom  
**Etapă:** 1 — structură relațională, relații și date demo  
**Data activității:** 2 noiembrie 2026  
**Asistent AI utilizat:** OpenAI Codex, în aplicația de asistență pentru programare.

## Scopul utilizării AI

Asistentul AI a fost utilizat pentru: generarea datelor demonstrative si verificarea rezultatului. A primit cerințele în limbaj natural și le-a transformat în fișiere SQL, scripturi PowerShell, configurații pentru VS Code și documentație.

## Datele demo și verificările efectuate

Datele demo au fost construite prin instrucțiuni SQL deterministe. Numele, companiile, produsele, ofertele și valorile financiare sunt fictive; nu provin dintr-o bază de clienți reali. Reperul calendaristic este 2 noiembrie 2026.

Verificările executate au confirmat:

- existența a exact **10 tabele și 256 de înregistrări**;
- concordanța dintre clienți, oportunități câștigate și polițele emise;
- egalitatea dintre totalul ratelor unei polițe și prima anuală a ofertei;
- respingerea a opt cazuri invalide: broker din altă agenție, referință inexistentă, sumă negativă, două oferte acceptate pentru aceeași oportunitate, poliță emisă din ofertă respinsă, produs din altă categorie, ștergerea unei agenții cu dependențe și perioadă de asigurare nulă;
- executarea celor șase interogări demonstrative și reluarea configurării fără duplicarea datelor.

## Instrumente și surse consultate

Pentru diagrama entitate–relație, AI a folosit integrarea **tldraw**. A transpus schema SQL în forme editabile cu cele 10 entități, toate coloanele și cele 12 relații FK, apoi a verificat vizual diagrama și a exportat versiunea SVG în `diagrams/erd_broker_crm.svg`. Diagrama include cheile primare și străine, cardinalitățile, atributele opționale și explicațiile cheilor compuse.

AI a folosit PowerShell și utilitarele PostgreSQL pentru implementare și verificare, Docker CLI și Docker Compose pentru pornirea și verificarea bazei în container, interfața de comandă VS Code pentru deschiderea proiectului și consultarea documentației oficiale pentru detalii tehnice. Acestea sunt instrumente utilizate de asistent, nu modele AI suplimentare.

## Rularea în Docker — actualizare din 2 noiembrie 2026

După instalarea Docker Desktop de către utilizator, asistentul AI a pornit serviciul PostgreSQL din `compose.yaml`. Schema și fixture-urile au fost încărcate în volumul persistent Docker. Verificarea celor 10 tabele, a celor 256 de înregistrări, cele opt teste de respingere și cele șase rapoarte au fost executate cu succes în container.

AI a adăugat scriptul `scripts/docker.ps1`, sarcinile Docker din VS Code și profilul de conexiune **Broker CRM - Docker**, la `127.0.0.1:5434`. A verificat și conectarea la container din Windows. Baza din Docker are date independente de instanța locală anterioară de pe portul 5433. Parola este păstrată în `.env` și nu este inclusă în acest jurnal.

Surse tehnice consultate:

- [PostgreSQL 18 — constrângeri și chei străine](https://www.postgresql.org/docs/18/ddl-constraints.html).
- [PostgreSQL 18 — inițializarea unei instanțe cu initdb](https://www.postgresql.org/docs/18/app-initdb.html).
- [Imaginea oficială PostgreSQL pentru Docker](https://hub.docker.com/_/postgres).
- [Instalarea Docker Desktop pe Windows](https://docs.docker.com/desktop/setup/install/windows-install/).

