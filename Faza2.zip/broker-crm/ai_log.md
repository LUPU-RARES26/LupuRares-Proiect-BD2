# Jurnal de utilizare a inteligenței artificiale

**Proiect:** CRM pentru brokeri de asigurări, inspirat de tipul de platformă AgencyZoom  
**Etapă:** 1 — structură relațională, relații și date demo  
**Data activității:** 2 noiembrie 2026  
**Asistent AI utilizat:** OpenAI Codex, în aplicația de asistență pentru programare.

## Scopul utilizării AI

Asistentul AI a fost utilizat pentru: generarea datelor demonstrative si verificarea rezultatului. A primit cerințele în limbaj natural și le-a transformat în fișiere SQL, scripturi PowerShell, configurații pentru VS Code și documentație.

## Datele demo și verificările efectuate

Datele demo au fost construite prin instrucțiuni SQL deterministe. Numele, companiile, produsele, ofertele și valorile financiare sunt fictive; nu provin dintr-o bază de clienți reali. Reperul calendaristic este 2 noiembrie 2026.

Verificările executate au confirmat:

- existența a exact **10 tabele și 256 de înregistrări**;
- concordanța dintre clienți, oportunități câștigate și polițele emise;
- egalitatea dintre totalul ratelor unei polițe și prima anuală a ofertei;
- respingerea a opt cazuri invalide: broker din altă agenție, referință inexistentă, sumă negativă, două oferte acceptate pentru aceeași oportunitate, poliță emisă din ofertă respinsă, produs din altă categorie, ștergerea unei agenții cu dependențe și perioadă de asigurare nulă;
- executarea celor șase interogări demonstrative și reluarea configurării fără duplicarea datelor.

## Instrumente și surse consultate

Pentru diagrama entitate–relație, AI a folosit integrarea **tldraw**. A transpus schema SQL în forme editabile cu cele 10 entități, toate coloanele și cele 12 relații FK, apoi a verificat vizual diagrama și a exportat versiunea SVG în `diagrams/erd_broker_crm.svg`. Diagrama include cheile primare și străine, cardinalitățile, atributele opționale și explicațiile cheilor compuse.

AI a folosit PowerShell și utilitarele PostgreSQL pentru implementare și verificare, Docker CLI și Docker Compose pentru pornirea și verificarea bazei în container, interfața de comandă VS Code pentru deschiderea proiectului și consultarea documentației oficiale pentru detalii tehnice. Acestea sunt instrumente utilizate de asistent, nu modele AI suplimentare.

## Rularea în Docker — actualizare din 2 noiembrie 2026

După instalarea Docker Desktop de către utilizator, asistentul AI a pornit serviciul PostgreSQL din `compose.yaml`. Schema și fixture-urile au fost încărcate în volumul persistent Docker. Verificarea celor 10 tabele, a celor 256 de înregistrări, cele opt teste de respingere și cele șase rapoarte au fost executate cu succes în container.

AI a adăugat scriptul `scripts/docker.ps1`, sarcinile Docker din VS Code și profilul de conexiune **Broker CRM - Docker**, la `127.0.0.1:5434`. A verificat și conectarea la container din Windows. Baza din Docker are date independente de instanța locală anterioară de pe portul 5433. Parola este păstrată în `.env` și nu este inclusă în acest jurnal.

Surse tehnice consultate:

- [PostgreSQL 18 — constrângeri și chei străine](https://www.postgresql.org/docs/18/ddl-constraints.html).
- [PostgreSQL 18 — inițializarea unei instanțe cu initdb](https://www.postgresql.org/docs/18/app-initdb.html).
- [Imaginea oficială PostgreSQL pentru Docker](https://hub.docker.com/_/postgres).
- [Instalarea Docker Desktop pe Windows](https://docs.docker.com/desktop/setup/install/windows-install/).

## Operatii CRUD — actualizare din 15 noiembrie 2026

La cererea utilizatorului, OpenAI Codex a creat operatiile CRUD pentru fiecare dintre cele 10 tabele existente. AI a citit schema si constrangerile, apoi a generat 40 de functii PostgreSQL in `database/05_crud.sql`: adaugare, citire, modificare si stergere pentru fiecare tabel. Functiile folosesc parametri tipizati, drepturile apelantului si constrangerile deja definite in baza.

AI a creat `database/06_demo_crud.sql`, cu exemple pentru toate operatiile, si `database/07_verificare_crud.sql`, cu teste de integrare. A refacut `database/04_verificare.sql`, care lipsea desi era referit de scripturile proiectului. A actualizat scripturile de rulare, configuratia Docker, sarcinile VS Code si documentatia `CRUD.md`.

Pentru aceasta activitate au fost utilizate instrumentele de editare a fisierelor, un script Python local pentru generarea repetitiva a definitiilor si exemplelor SQL, PowerShell, Docker CLI si clientul PostgreSQL `psql`. Nu a fost utilizat conectorul MongoDB pentru CRUD. Nu au fost create trigger-e sau tabele permanente suplimentare.

Validarea a inclus o baza temporara separata, testata atat fara fixtures, cat si cu fixtures, reinstalarea functiilor si apoi instalarea/verificarea in baza curenta din Docker. Au trecut cele 40 de operatii, testele de listare si ID inexistent, 10 cazuri de respingere si verificarea valorilor `NULL`. Setul initial de 256 de randuri a fost pastrat; tranzactiile demonstrative sunt anulate cu `ROLLBACK`, dar secventele IDENTITY pot avansa. Baza temporara de test a fost eliminata dupa verificare.

Cele trei sarcini CRUD din VS Code apeleaza direct Docker CLI, deoarece Windows PowerShell bloca executarea fisierelor `.ps1`. Politica de executie a sistemului nu a fost modificata. Nu au fost folosite modele AI suplimentare pentru aceasta etapa.

## Aplicatie web integrata — 16 noiembrie 2026

La cererea utilizatorului, OpenAI Codex a implementat site-ul Broker CRM peste proiectul existent. A folosit skill-ul `frontend-app-builder` pentru fluxul de proiectare si verificare vizuala. Instrumentul integrat `imagegen` a generat doua concepte: dashboard si formular de client; identificatorul exact al modelului de generare a imaginilor nu a fost expus de instrument. Conceptele sunt pastrate in `web/design/`. Interfata efectiva este scrisa in React si CSS, cu text si controale functionale, nu este o imagine statica.

AI a creat frontendul React + Vite, backendul Node.js + Express, configuratia celor 10 formulare, validarea datelor, rutele API, mesajele de eroare in romana si rapoartele parametrizate. Backendul utilizeaza biblioteca `pg` si apeleaza functiile PostgreSQL CRUD deja implementate. Au fost adaugate serviciul Docker `web`, configuratia de construire, sarcini VS Code si ghidul `SITE.md`. Autentificarea si publicarea pe internet nu fac parte din aceasta implementare locala.

AI a folosit editorul de fisiere, PowerShell, npm, Node.js si Docker CLI pentru implementare, instalare, construire si testare. Browserul integrat al aplicatiei Codex a fost folosit pentru inspectia paginilor, formularelor, rapoartelor si aspectului pe desktop/mobil; capturile au fost comparate vizual cu conceptele. Nu a fost necesar un browser Playwright separat. Functiile de generare si modificare au fost scrise de Codex; nu au fost folositi subagenti.

Testarea a inclus sase teste automate de validare si corespondenta cu schema, operatiile Create/Read/Update/Delete pentru fiecare tabel prin HTTP, erori de integritate, toate cele sase rapoarte si filtrarea pe agentie. Din browser a fost creat si modificat un client temporar, apoi s-a verificat persistenta dupa reincarcare si dialogul de stergere. Clientul temporar a fost eliminat prin API, iar fixture-urile initiale au fost verificate din nou: 10 tabele si 256 de randuri.

Nu au fost trimise credentialele PostgreSQL in frontend, in imagini sau in acest jurnal. MongoDB nu a fost utilizat pentru site. Configuratia pastreaza baza si volumul Docker existente; aplicatia acceseaza aceleasi date ca interogarile SQL.

## Profiluri client/lead și sarcini — 16 noiembrie 2026

La cererea utilizatorului, OpenAI Codex a modificat site-ul existent. Utilizatorul a clarificat că leadurile sunt înregistrările din `oportunitati`, nu clienții cu starea Prospect. AI a implementat profiluri cu polițe, activități și plăți filtrate separat: profilul clientului reunește toate oportunitățile sale, iar profilul leadului include numai oportunitatea deschisă. Ofertele financiare rămân accesibile în profil, pentru legătura cu polițele. În meniul principal, Oferte a fost înlocuit cu Sarcini.

AI a extins tabelul `activitati` pentru atribuire unui agent, client/lead opțional, moment de afișare, termen-limită și tipurile Programare, Trimite email/SMS, Reminder, De făcut. A adăugat liste Disponibile, Programate și Istoric, căutare, editare, reatribuire și finalizare. Afișarea se calculează după ora PostgreSQL; interfața actualizează lista la 30 de secunde. Tipul Email/SMS nu trimite mesaje efective. Selectorul agentului nu reprezintă autentificare.

Înainte de migrare, AI a salvat un backup pg_dump în `backups/broker-before-profiles-tasks-2026-11-16.dump`. A modificat exclusiv baza PostgreSQL `broker_crm`, schema `broker_crm`, din Docker, accesibilă pe portul Windows 5434. Modificările persistente ale structurii sunt în `activitati` (patru coloane, FK, CHECK și indexuri) și `oportunitati` (o cheie unică compusă pentru FK). Cele 60 de activități existente au fost completate cu valorile derivate din oportunități. Funcțiile CREATE și UPDATE pentru activități au fost extinse cu parametri opționali pentru compatibilitate. Scripturile originale de demonstrare și verificare CRUD continuă să funcționeze.

AI a creat `database/08_profiluri_sarcini.sql`, a actualizat funcțiile din 05, agenda SQL din 03, backendul, frontendul, scripturile și documentația. Serviciul Docker temporar `migrate` aplică extensia și funcțiile înainte de pornirea site-ului. Celelalte baze PostgreSQL locale și MongoDB nu au fost modificate. Nu au fost create tabele permanente sau trigger-e; rămân 10 tabele și 40 de funcții CRUD.

Instrumente utilizate: editarea fișierelor, scripturi Python locale pentru modificări repetitive, PowerShell, npm/Node.js, Docker Compose, pg_dump și psql. Browserul integrat a fost folosit pentru verificarea vizuală și funcțională. Au fost păstrate componentele și stilurile interfeței existente; nu s-au generat concepte sau imagini AI noi și nu s-au folosit subagenți. Conectorul MongoDB nu a fost utilizat.

Verificări efectuate: șapte teste unitare; toate operațiile CRUD prin HTTP; izolarea datelor fiecărui client și lead; protejarea scrierilor în afara profilului prin rollback; toate cele patru tipuri; reatribuire între agenți; respingerea asocierilor greșite și termenelor invalide; trecerea automată din Programate în Disponibile la un prag temporal real; cele șase rapoarte. Verificările SQL 04 și 07 au trecut. În browser au fost testate profilul cu două oportunități, leadul fără poliță, selectorul de polițe limitat la client, validarea termenului, salvarea și finalizarea unei sarcini temporare, apoi istoricul. Datele de test au fost eliminate prin API; au rămas cele 256 de înregistrări demo. Secvențele IDENTITY pot avansa în urma testelor.

## Simplificarea filelor din profil — 16 noiembrie 2026

La cererea utilizatorului, OpenAI Codex a eliminat fila Oportunități din profilul clientului și filele Polițe/Plăți din profilul oportunității. Modificarea este în `web/src/ProfilePage.jsx`; selecția filelor diferă după tipul profilului, iar o adresă veche pentru o filă eliminată afișează Detalii. Au fost actualizate ghidurile SITE.md și README.md. Au fost folosite editarea fișierelor, PowerShell/Python pentru documentație și Docker pentru reconstruirea serviciului web. Această modificare privește interfața; nu necesită modificări SQL sau migrarea bazei de date.

Verificare: construirea Vite/Docker a reușit, serviciul web este healthy. În browser, adresa veche a polițelor unui lead a afișat Detalii; profilul oportunității are Detalii/Activități/Oferte, iar cel al clientului are Detalii/Polițe/Activități/Plăți/Oferte. A fost reconstruit doar serviciul web, cu `--no-deps`, fără rularea migrărilor și fără modificarea bazei de date.

## Repornirea instanței PostgreSQL locale — 16 noiembrie 2026

La cererea utilizatorului, Codex a diagnosticat conexiunea „Broker CRM - PostgreSQL local”. Portul 5433 nu avea server activ. A pornit instanța deja inițializată din `work/broker-crm-pgdata` cu `pg_ctl`, ascultând exclusiv pe 127.0.0.1:5433, apoi a verificat autentificarea prin psql din Windows. Baza locală `broker_crm` are 10 tabele, 24 de clienți și nu are funcțiile CRUD instalate; reprezintă versiunea inițială, separată de baza curentă a site-ului din Docker (5434). Nu au fost migrate, sincronizate sau șterse date. La reconectarea din VS Code, extensia a solicitat parola SQL Login; câmpul a fost lăsat utilizatorului pentru completare. Au fost folosite PowerShell, utilitarele PostgreSQL și controlul aplicației VS Code.

## Pachet Faza2 pentru GitHub — 16 noiembrie 2026

La cererea utilizatorului, OpenAI Codex a pregătit `Faza2.zip` cu proiectul actual `broker-crm`: surse frontend/backend, SQL, fixtures, CRUD, teste, migrare, configurația Docker și VS Code, diagrame, capturi și documentație. A adăugat `START_AICI.md` cu pașii de instalare pe alt calculator și rolul fiecărui director. Dependențele instalate, rezultatele construirii, backupurile, datele interne PostgreSQL, jurnalele și `.env` sunt excluse. Profilurile VS Code din arhivă sunt copii fără parole; profilurile locale ale utilizatorului nu sunt schimbate. Arhiva este verificată pentru integritate și pentru absența parolei locale. Instrumente: editarea fișierelor, PowerShell și biblioteca standard Python `zipfile`; nu sunt folosite modele sau subagenți suplimentari. Bazele de date nu sunt modificate pentru împachetare.
