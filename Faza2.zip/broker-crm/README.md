# Broker CRM — aplicatie web si baza de date relationala

## Site integrat — 16 noiembrie 2026

Aplicatia este disponibila local la **http://localhost:3000**, conectata la PostgreSQL din Docker si la cele 40 de functii CRUD. Include dashboard, administrarea celor 10 tabele, cautare, filtre, formulare cu relatii, paginare si cele sase rapoarte. Ghid complet: [SITE.md](SITE.md). Cod: [web/](web/).

```powershell
docker compose up -d --build --wait
```

Din VS Code: **Terminal > Run Task > Site: pornire si actualizare**. Modificarile facute din site se salveaza in baza existenta. Aplicatia este un spatiu local demonstrativ, fara autentificare si fara publicare pe internet.

Proiect de baza de date pentru un viitor site de gestionare a agentiilor, clientilor, ofertelor, politelor si activitatilor comerciale, inspirat de tipul de produs AgencyZoom. Implementare: **PostgreSQL 18, exact 10 tabele, 256 inregistrari demo**. Datele, asiguratorii, produsele si preturile sunt fictive; reperul temporal al demo-ului este **2 noiembrie 2026**.

MongoDB nu este o baza relationala SQL. Clusterul MongoDB `DiagnosticJS` si baza lui existenta `cabinet_diagnostic` nu au fost modificate. Acest pachet foloseste un server PostgreSQL separat.

## Operatii CRUD — actualizare din 15 noiembrie 2026

Sunt disponibile **40 de functii PostgreSQL**, cate un Create, Read, Update si Delete pentru fiecare tabel. Definitii: [database/05_crud.sql](database/05_crud.sql). Exemple pentru toate operatiile: [database/06_demo_crud.sql](database/06_demo_crud.sql). Teste automate: [database/07_verificare_crud.sql](database/07_verificare_crud.sql). Instructiuni si explicatii: [CRUD.md](CRUD.md).

```powershell
.\scripts\docker.ps1 InstallCrud
.\scripts\docker.ps1 CrudDemo
.\scripts\docker.ps1 VerifyCrud
```

Containerul trebuie pornit mai intai cu actiunea `Start`. Instalarea poate fi repetata; demonstratia si testele anuleaza modificarile randurilor prin `ROLLBACK`. Pentru utilizare directa, de exemplu: `SELECT * FROM broker_crm.clienti_read();`. Functiile pastreaza toate constrangerile existente si sterg numai randul identificat prin ID, respectand cheile straine. Cele 10 tabele raman aceleasi.

## Utilizare curenta: PostgreSQL in Docker

Proiectul este pornit si verificat in Docker. In VS Code, deschideti `broker-crm.code-workspace` si selectati profilul PostgreSQL **Broker CRM - Docker**.

| Parametru | Valoare |
|---|---|
| Host | `127.0.0.1` |
| Port | `5434` |
| Baza si schema | `broker_crm` |
| Utilizator | `broker_demo` |
| Parola | `POSTGRES_PASSWORD` din `.env` |

In **Terminal > Run Task**, folositi sarcinile care incep cu **Docker:**. Sarcina de test implicita este **Docker: verificare etapa 1**. Din terminalul proiectului sunt disponibile comenzile:

```powershell
.\scripts\docker.ps1 Start
.\scripts\docker.ps1 Verify
.\scripts\docker.ps1 Query
.\scripts\docker.ps1 Status
.\scripts\docker.ps1 Stop
```

Actiunea `Setup` porneste containerul, verifica fixture-urile si instaleaza functiile CRUD. Datele sunt persistente in volumul `broker-crm_postgres_data`; oprirea containerului pastreaza datele. Cele 10 tabele, cele 256 de inregistrari, cele opt teste de respingere si cele sase rapoarte au fost verificate in container. Conexiunea pe portul 5434 a fost verificata si din Windows.

Instanta locala de pe portul 5433, descrisa mai jos, este o alternativa cu date independente. Pentru lucrul curent selectati **Broker CRM - Docker**.

## Alternativa: PostgreSQL local fara Docker

Deschideti `broker-crm.code-workspace` in VS Code. Proiectul contine scripturi SQL in `database/`, configuratie PostgreSQL, sarcini VS Code si `compose.yaml` pentru Docker.

Instanta locala a proiectului este separata de serviciul PostgreSQL existent de pe portul 5432. Conexiunea pregatita in extensia PostgreSQL este **Broker CRM - PostgreSQL local**:

| Parametru | Valoare |
|---|---|
| Host | `127.0.0.1` |
| Port | `5433` |
| Baza | `broker_crm` |
| Schema | `broker_crm` |
| Utilizator | `broker_demo` |
| Parola | Valoarea `POSTGRES_PASSWORD` din fisierul local `.env` |

Parola este generata local si exclusa din Git. Instanta asculta numai pe interfata locala si foloseste autentificare SCRAM. In VS Code, deschideti panoul PostgreSQL, selectati conexiunea de mai sus si introduceti parola din `.env` daca este ceruta.

In meniul **Terminal > Run Task** sunt disponibile actiunile de creare, pornire, verificare, rapoarte si oprire a bazei. Aceleasi actiuni se pot executa din terminalul PowerShell al proiectului:

```powershell
.\scripts\postgres.ps1 Setup
.\scripts\postgres.ps1 Verify
.\scripts\postgres.ps1 Query
.\scripts\postgres.ps1 Stop
.\scripts\postgres.ps1 Start
```

`Setup` nu sterge date: daca schema exista deja, ruleaza verificarile fara a reintroduce fixture-urile. Serverul poate fi repornit dupa restartul calculatorului folosind actiunea `Start`. Locatia datelor poate fi configurata prin `LOCAL_PGDATA` in `.env`; implicit este `.local/postgres` in proiect. Instanta este de dezvoltare pentru etapa 1, iar utilizatorul ei administreaza aceasta instanta dedicata.

## Configuratia Docker

Extensia Docker din VS Code foloseste aplicatia [Docker Desktop pentru Windows](https://docs.docker.com/desktop/setup/install/windows-install/). Containerul asculta pe `127.0.0.1:5434`, astfel incat poate coexista cu instanta locala de pe 5433. Datele sunt pastrate intr-un volum Docker, separat de instanta locala. Nu exista sincronizare intre ele.

Cu Docker Desktop pornit, din directorul proiectului:

```powershell
docker compose up -d --wait
```

Comanda initializeaza schema si fixture-urile numai pe un volum gol. Serviciul `migrate` aplica extensia idempotenta `08_profiluri_sarcini.sql` si reinstaleaza functiile din `05_crud.sql` inaintea site-ului, inclusiv pe un volum existent. Nu reexecuta 01/02 peste date existente. Pentru verificare folositi comanda de mai jos.

```powershell
.\scripts\docker.ps1 Verify
docker compose stop
```

Imaginea oficiala este `postgres:18`; volumul este montat la `/var/lib/postgresql`, conform structurii imaginii PostgreSQL 18. Referinta: [imaginea oficiala PostgreSQL](https://hub.docker.com/_/postgres). Versiunea verificata in container este PostgreSQL 18.6; containerul `broker-crm-postgres-1` raporteaza starea `healthy`.

## Instalare SQL manuala, pe alt server

1. Creati o baza noua, goala, numita `broker_crm`, pe un server PostgreSQL autentificat.
2. Executati `database/01_schema.sql` — creeaza schema `broker_crm`, cele 10 tabele, constrangerile si indexurile.
3. Executati `database/02_fixtures.sql` — insereaza toate datele demo intr-o tranzactie.
4. Executati `database/04_verificare.sql` — verifica numarul de tabele, randurile, coerenta si respingerea datelor invalide; la final face `ROLLBACK`.
5. Executati mai intai `database/08_profiluri_sarcini.sql`, apoi `database/03_interogari.sql` pentru rapoarte demonstrative.
6. Dupa extensia `database/08_profiluri_sarcini.sql`, executati `database/05_crud.sql` pentru instalarea celor 40 de functii; apoi `database/06_demo_crud.sql` pentru demonstratie si `database/07_verificare_crud.sql` pentru teste.

In pgAdmin, selectati baza `broker_crm`, deschideti Query Tool, apoi deschideti si executati fiecare fisier in ordinea de mai sus. Alternativ, din directorul acestui pachet:

```powershell
& 'C:\Program Files\PostgreSQL\18\bin\createdb.exe' -h 127.0.0.1 -U postgres broker_crm
& 'C:\Program Files\PostgreSQL\18\bin\psql.exe' -X -h 127.0.0.1 -U postgres -d broker_crm -v ON_ERROR_STOP=1 -f .\database\01_schema.sql -f .\database\02_fixtures.sql -f .\database\04_verificare.sql
```

Comenzile cer parola serverului local. Scripturile SQL nu contin parole; parola de dezvoltare este pastrata separat in `.env`, exclus din Git. Scripturile nu contin stergeri de baze sau scheme; o a doua rulare a schemei pe aceeasi baza se opreste deoarece schema exista deja. Pentru reluare folositi o alta baza goala. Aplicatia viitoare va utiliza nume calificate, de exemplu `broker_crm.clienti`, sau va configura `search_path` la conectare.

## Cele 10 tabele

| Tabel | Randuri | Rol si coloane principale |
|---|---:|---|
| agentii | 2 | Organizatiile de brokeraj: denumire, cod demo, email, oras |
| brokeri | 6 | Personalul agentiei: agentie_id, nume, email, rol, activ |
| clienti | 24 | Persoane si firme, inclusiv prospecti: agentie_id, broker_id, tip, stare |
| asiguratori | 5 | Catalog comun de companii fictive |
| produse_asigurare | 15 | Cate 3 produse RCA/CASCO/LOCUINTA pentru fiecare asigurator |
| oportunitati | 30 | Pipeline comercial: client, broker, agentie, categorie, etapa, sursa, valoare |
| oferte | 60 | Doua alternative per oportunitate: produs, prima, suma asigurata, valabilitate |
| polite | 18 | Contracte emise din oferte acceptate: numar, perioada, stare, comision |
| activitati | 60 | Activitati si sarcini atribuite agentilor, cu client/lead optional si moment de afisare |
| plati | 36 | Doua rate per polita: suma, scadenta, metoda si stare |
| **Total** | **256** | |

ID-urile sunt chei `bigint` cu identitate; fixture-urile folosesc ID-uri deterministe si ajusteaza secventele pentru inserari ulterioare. Sumele folosesc `numeric`, nu virgula mobila. Datele calendaristice sunt `date`, iar momentele sunt `timestamptz`. Moneda demo este RON. Adresele email folosesc domenii `.example`; nu se stocheaza CNP-uri, carduri sau parole.

## Relatii

| Parinte | Copil / cheie straina | Cardinalitate |
|---|---|---|
| agentii | brokeri.agentie_id | 1:N |
| agentii | clienti.agentie_id | 1:N |
| brokeri | clienti.(broker_id, agentie_id) | 1:N, aceeasi agentie |
| agentii | oportunitati.agentie_id | 1:N |
| clienti | oportunitati.(client_id, agentie_id) | 1:N, aceeasi agentie |
| brokeri | oportunitati.(broker_id, agentie_id) | 1:N, aceeasi agentie |
| asiguratori | produse_asigurare.asigurator_id | 1:N |
| oportunitati | oferte.(oportunitate_id, categorie) | 1:N, aceeasi categorie |
| produse_asigurare | oferte.(produs_id, categorie) | 1:N, aceeasi categorie |
| oferte | polite.(oferta_id, stare_oferta) | 1:0..1, doar oferta acceptata |
| oportunitati | activitati.oportunitate_id | 1:N |
| polite | plati.polita_id | 1:N |

Clientii si produsele au o relatie M:N realizata prin oportunitati si oferte. Nu este nevoie de al unsprezecelea tabel pentru aceasta asociere, deoarece ofertele sunt deja entitati de legatura cu atribute comerciale proprii. Oportunitatea poate fi repartizata unui alt broker decat responsabilul general al clientului, dar din aceeasi agentie.

Entitatile sunt separate pentru a evita duplicarea numelui clientului, asiguratorului sau produsului in polite si plati. Campurile repetate `agentie_id`, `categorie` si discriminatorul constant `stare_oferta` sunt pastrate intentionat pentru chei straine compuse care impun reguli intre tabele. Prima din oferta este valoarea contractuala istorica; platile se raporteaza la aceasta prin polita.

## Diagrama ER

Diagrama completa, cu toate coloanele si cheile: [SVG](diagrams/erd_broker_crm.svg) · [tldraw editabil](https://www.tldraw.com/f/Q4yr-vtpvOm2t8LSQ-VVw) · [legenda si relatii](diagrams/README.md).

```mermaid
erDiagram
    AGENTII ||--o{ BROKERI : are
    AGENTII ||--o{ CLIENTI : gestioneaza
    AGENTII ||--o{ OPORTUNITATI : detine
    BROKERI ||--o{ CLIENTI : administreaza
    BROKERI ||--o{ OPORTUNITATI : gestioneaza
    CLIENTI ||--o{ OPORTUNITATI : solicita
    ASIGURATORI ||--o{ PRODUSE_ASIGURARE : ofera
    PRODUSE_ASIGURARE ||--o{ OFERTE : cotat_in
    OPORTUNITATI ||--o{ OFERTE : compara
    OFERTE ||--o| POLITE : genereaza
    OPORTUNITATI ||--o{ ACTIVITATI : urmarita_prin
    POLITE ||--o{ PLATI : achitata_prin
```

## Reguli impuse de baza

- Chei primare pentru fiecare tabel, chei straine reale si `ON DELETE RESTRICT` pentru protejarea istoricului.
- Clientul, brokerul si oportunitatea apartin aceleiasi agentii prin chei compuse.
- Produsul ofertat corespunde categoriei oportunitatii, prin chei compuse.
- Maximum o oferta acceptata pentru fiecare oportunitate, prin index unic partial.
- Maximum o polita per oferta; polita poate referi numai o oferta acceptata, iar acea oferta nu poate fi schimbata in respinsa cat timp exista polita.
- Sume strict pozitive, comision intre 0 si 100, perioade valide, numere de polite si oferte unice, numere de rate unice in cadrul politei.
- O oportunitate inchisa are un moment de inchidere; plata achitata are data, metoda si referinta; activitatea finalizata are data finalizarii.

Cheile straine nu sunt autorizare: viitorul backend trebuie sa filtreze accesul dupa agentia utilizatorului autentificat. Fluxurile multi-tabel (acceptare oferta, emitere polita, creare rate) vor folosi tranzactii. Concordanta `castigat`/polita si totalul ratelor fata de prima sunt verificate pentru fixture-uri; nu sunt impuse automat pentru toate scrierile viitoare. Aceste reguli vor intra in serviciul tranzactional al aplicatiei sau in trigger-e intr-o etapa ulterioara. Aplicatia web locala si API-ul CRUD sunt acum implementate in directorul web/. Autentificarea si fluxurile comerciale multi-tabel raman extinderi ulterioare; detalii in SITE.md.

## Scenarii demo si verificare

Exista 18 oportunitati castigate, 4 pierdute si 8 deschise; 18 polite active la reperul demo, 18 rate platite si 18 rate viitoare. Fiecare polita are doua rate a caror suma este egala cu prima ofertei acceptate. Catalogul este comun celor doua agentii.

Verificarea automata include exact 10 tabele si 256 randuri, coerenta client/polita, oportunitate castigata/polita si total rate/prima, plus 8 incercari care trebuie respinse: broker din alta agentie, referinta inexistenta, suma negativa, doua oferte acceptate, polita din oferta respinsa, produs din alta categorie, stergerea unei agentii cu dependente si perioada nula.

Referinta tehnica pentru chei, constrangeri si integritate referentiala: [documentatia oficiala PostgreSQL 18](https://www.postgresql.org/docs/18/ddl-constraints.html).

## Profiluri si sarcini — 16 noiembrie 2026

Profilul clientului include Detalii, Polite, Activitati, Plati si Oferte, fara fila Oportunitati. Profilul leadului (oportunitatii) include numai Detalii, Activitati si Oferte, fara Polite sau Plati. Datele afisate sunt filtrate pentru profilul deschis. Meniul Oferte a fost inlocuit cu Sarcini; ofertele financiare raman in profil pentru emiterea politelor. Sarcinile au tip, agent, moment de afisare, termen-limita si descriere. Selectorul agentului ofera liste Disponibile / Programate / Istoric.

Extensia SQL este in `database/08_profiluri_sarcini.sql`: adauga atribute si relatii in `activitati` si o constrangere unica in `oportunitati`. Nu adauga tabele sau trigger-e. Pentru schema actuala se executa 01, 02, 08, 05 in aceasta ordine. Ghidul complet, API-ul, limitele demo-ului si baza modificata sunt documentate in [SITE.md](SITE.md).
