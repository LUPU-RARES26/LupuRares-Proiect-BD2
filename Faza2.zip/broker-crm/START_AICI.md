# Faza 2 — Broker CRM

Acest pachet contine sursele actuale ale site-ului, baza relationala PostgreSQL
(schema, fixtures, migrari, functii CRUD si verificari), configuratia Docker,
diagramele, capturile si documentatia proiectului.

## Pornire pe alt calculator

1. Extrageti arhiva si deschideti folderul `broker-crm` in VS Code.
2. Instalati si porniti Docker Desktop.
3. Copiati `.env.example` ca `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

4. In noul `.env`, inlocuiti valoarea `POSTGRES_PASSWORD` cu propria parola.
5. Din terminalul folderului `broker-crm`, executati:

   ```powershell
   docker compose up -d --build --wait
   ```

6. Deschideti http://localhost:3000.

Pe un volum Docker nou se creeaza baza `broker_crm`, cele 10 tabele, datele demo,
extensia pentru sarcini si cele 40 de functii CRUD. Nu este necesar Node.js pe
calculatorul gazda. Instalarea dependentelor si construirea site-ului au loc
in containere. Serviciul `migrate` se termina cu cod 0 dupa instalarea extensiei.

Pentru conectare din VS Code: profilul `Broker CRM - Docker`, server
`127.0.0.1`, port `5434`, baza `broker_crm`, utilizator `broker_demo` si parola
aleasa in `.env`. Parolele nu sunt incluse in profilurile distribuite.

## Continut

- `database/`: schema, 256 de inregistrari demo, 6 rapoarte, verificari,
  40 de functii CRUD, demonstratia CRUD si migrarea pentru profiluri/sarcini.
- `web/`: frontend, backend, teste, configuratia construirii si resurse vizuale.
- `scripts/`, `.vscode/`, `broker-crm.code-workspace`: instrumente de rulare.
- `compose.yaml`, `.env.example`, `.gitignore`: configuratia proiectului.
- `diagrams/`: diagrama ER exportata in SVG/PDF pentru etapa 1. Relatiile noi
  ale sarcinilor sunt documentate in `database/08_profiluri_sarcini.sql` si `SITE.md`.
- `README.md`, `SITE.md`, `CRUD.md`, `VERIFICARE.md`, `ai_log.md`: documentatie.

Arhiva omite `.env`, parolele salvate in profilurile VS Code, backupurile,
datele interne PostgreSQL, `node_modules`, `dist` si jurnalele. Baza de date
este reconstituita din fisierele SQL; arhiva nu reprezinta un backup al
volumului Docker sau al inregistrarilor introduse ulterior in site.

## Verificare

```powershell
docker compose ps -a
docker compose exec -T web node tests/api.integration.js
```

Testul API verifica CRUD, rapoartele, izolarea profilurilor si sarcinile;
creeaza si elimina propriile date de test. Detalii in `SITE.md`.

## Incarcare in GitHub

Pentru un repository cu surse vizibile si usor de evaluat, extrageti arhiva
si incarcati continutul folderului `broker-crm`, inclusiv fisierele care incep
cu punct. Pastrati `.env.example` si `.gitignore`; propria parola din `.env`
trebuie pastrata numai local. Pachetul poate fi incarcat si ca arhiva `Faza2.zip`.
