# Operatii CRUD — Broker CRM

Proiectul contine **40 de functii SQL reutilizabile**, cate patru pentru fiecare dintre cele 10 tabele. Functiile sunt salvate in schema `broker_crm` a bazei PostgreSQL. Nu adauga tabele si nu necesita un server web.

| Operatie | Semnificatie | Instructiunea din functie |
|---|---|---|
| Create | Adauga o inregistrare | `INSERT ... RETURNING *` |
| Read | Citeste o inregistrare sau lista | `SELECT` |
| Update | Modifica o inregistrare dupa ID | `UPDATE ... WHERE id = p_id RETURNING *` |
| Delete | Sterge o inregistrare dupa ID | `DELETE ... WHERE id = p_id RETURNING *` |

## Fisiere

- [database/05_crud.sql](database/05_crud.sql): definitiile celor 40 de functii, grupate pe tabele. Se executa integral dupa `database/08_profiluri_sarcini.sql`, pentru instalare sau actualizare.
- [database/06_demo_crud.sql](database/06_demo_crud.sql): exemple de apel pentru toate cele 40 de operatii. Creeaza propriile date, le citeste, le modifica, apoi le sterge in ordinea dependentei. La final executa `ROLLBACK`.
- [database/07_verificare_crud.sql](database/07_verificare_crud.sql): teste automate pentru toate operatiile, liste, ID-uri inexistente, restrictii si campuri nullable. Verifica si ca datele existente raman identice.

## Rulare in Docker

Calea recomandata in VS Code este **Terminal > Run Task > Docker: demonstratie CRUD** sau **Docker: verificare CRUD**. Pentru instalare folositi **Docker: instalare CRUD**. Aceste trei sarcini folosesc direct Docker CLI, fara executarea unui fisier PowerShell. Daca baza este oprita, rulati mai intai **Docker: pornire PostgreSQL**.

Din terminalul VS Code deschis in directorul proiectului:

```powershell
.\scripts\docker.ps1 Start
.\scripts\docker.ps1 InstallCrud
.\scripts\docker.ps1 CrudDemo
.\scripts\docker.ps1 VerifyCrud
```

`InstallCrud` poate fi repetat. La prima migrare completeaza atributele noi ale activitatilor existente; ulterior pastreaza valorile acestora. `CrudDemo` si `VerifyCrud` necesita functiile instalate si nu pastreaza modificarile randurilor. Sunt disponibile si sarcinile **Docker: instalare CRUD**, **Docker: demonstratie CRUD** si **Docker: verificare CRUD** in **Terminal > Run Task**.

Scripturile au fost testate cu PowerShell 7. Windows PowerShell poate afisa `running scripts is disabled`; in acest caz folositi sarcinile Docker directe de mai sus sau editorul SQL. Nu este necesara modificarea politicii de executie.

La prima initializare a unui volum Docker gol, `compose.yaml` instaleaza automat schema, fixture-urile si functiile. Pentru un volum existent, folositi `InstallCrud`. Schimbarea fisierului SQL nu actualizeaza singura functiile din baza. `Setup` instaleaza si el functiile, dupa verificarea fixture-urilor.

Pentru instanta PostgreSQL locala separata sunt disponibile aceleasi trei actiuni prin `scripts/postgres.ps1`. Instalarea in Docker nu instaleaza functiile si in instanta locala.

## Rulare din editorul SQL

1. Selectati conexiunea **Broker CRM - Docker** (portul `5434`).
2. Executati mai intai `database/08_profiluri_sarcini.sql`. Deschideti apoi `database/05_crud.sql`, selectati tot si executati cu **Ctrl + Shift + E**. Aceasta este instalarea functiilor.
3. Deschideti `database/06_demo_crud.sql`, selectati tot si executati in aceeasi conexiune pentru demonstratia completa.
4. Pentru teste, executati integral `database/07_verificare_crud.sql` si consultati mesajul `PASS CRUD`.

Exemplu de interogare pe care o puteti executa separat:

```sql
-- Lista tuturor clientilor:
SELECT * FROM broker_crm.clienti_read();

-- Numai clientul cu ID 1:
SELECT * FROM broker_crm.clienti_read(1);
```

Un apel de forma `SELECT * FROM broker_crm.agentii_create(...)` **adauga date**, desi incepe cu `SELECT`: acesta apeleaza functia care contine `INSERT`. Acelasi principiu se aplica functiilor `_update` si `_delete`.

Pentru adaugarea permanenta a unei agentii, executati separat, in afara unei tranzactii deschise:

```sql
SELECT * FROM broker_crm.agentii_create(
    p_denumire => 'Agentie Exemplu',
    p_cod_demo => 'AG-EXEMPLU-001',
    p_email => 'contact@agentie-exemplu.example',
    p_oras => 'Brasov'
);
```

Rezultatul contine ID-ul generat. Pentru modificare si stergere folositi ID-ul returnat, fara a presupune ca este urmatorul numar consecutiv. Codul si emailul trebuie sa fie unice; repetarea exemplului neschimbat este respinsa de `UNIQUE`.

Exemplu de modificare folosind parametri numiti (inlocuiti `123` cu ID-ul obtinut):

```sql
SELECT * FROM broker_crm.agentii_update(
    p_id => 123,
    p_denumire => 'Agentie Exemplu Actualizata',
    p_cod_demo => 'AG-EXEMPLU-001',
    p_email => 'contact@agentie-exemplu.example',
    p_oras => 'Sibiu'
);

-- Stergerea aceleiasi agentii, daca nu are inregistrari dependente:
SELECT * FROM broker_crm.agentii_delete(123);
```

Aceste ultime exemple sunt apeluri independente care pastreaza modificarile in modul autocommit. Pentru exercitii fara salvare, folositi fisierul demonstrativ sau incadrati apelurile in `BEGIN;` si `ROLLBACK;`. Pentru salvarea unei tranzactii folositi `COMMIT;`.

## Cele 40 de functii

| Tabel | Create | Read | Update | Delete |
|---|---|---|---|---|
| agentii | `agentii_create` | `agentii_read` | `agentii_update` | `agentii_delete` |
| brokeri | `brokeri_create` | `brokeri_read` | `brokeri_update` | `brokeri_delete` |
| clienti | `clienti_create` | `clienti_read` | `clienti_update` | `clienti_delete` |
| asiguratori | `asiguratori_create` | `asiguratori_read` | `asiguratori_update` | `asiguratori_delete` |
| produse_asigurare | `produse_asigurare_create` | `produse_asigurare_read` | `produse_asigurare_update` | `produse_asigurare_delete` |
| oportunitati | `oportunitati_create` | `oportunitati_read` | `oportunitati_update` | `oportunitati_delete` |
| oferte | `oferte_create` | `oferte_read` | `oferte_update` | `oferte_delete` |
| polite | `polite_create` | `polite_read` | `polite_update` | `polite_delete` |
| activitati | `activitati_create` | `activitati_read` | `activitati_update` | `activitati_delete` |
| plati | `plati_create` | `plati_read` | `plati_update` | `plati_delete` |

Toate numele se prefixeaza cu `broker_crm.`. Lista completa de parametri este in definitia fiecarei functii din `05_crud.sql`, iar valorile exemplu sunt in `06_demo_crud.sql`.

## Comportament si reguli

- `_create` returneaza randul nou, inclusiv ID-ul generat automat. Campurile `creat_la` ale agentiilor/clientilor si `stare_oferta` ale politelor folosesc valorile implicite din schema.
- `_read()` sau `_read(NULL)` returneaza toate randurile, ordonate dupa ID. `_read(id)` returneaza cel mult un rand.
- `_update` primeste ID-ul si **toate campurile editabile**, nu numai campul schimbat. `id` si `creat_la` sunt pastrate. Pentru a goli un camp nullable, transmiteti explicit `NULL`; acesta nu inseamna pastrarea valorii vechi.
- `_update(id, ...)` si `_delete(id)` returneaza zero randuri daca ID-ul nu exista. Nu creeaza automat o inregistrare si nu modifica alte randuri.
- Constrangerile `CHECK`, `UNIQUE`, `NOT NULL` si cheile straine se aplica la fiecare scriere. Nu sunt dezactivate de functii.
- Stergerea este explicita, fara cascada. De exemplu, o polita cu plati nu poate fi stearsa pana nu sunt eliminate platile. Pentru pastrarea istoricului folositi campurile `activ`/`stare` unde acestea exista.
- Parametrii sunt valori SQL, fara concatenare in SQL dinamic. Functiile ruleaza cu drepturile utilizatorului conectat; viitorul backend va aplica autentificarea, accesul pe agentie si parametri SQL legati prin driver.

Ordinea folosita pentru stergerea setului demonstrativ este:

`plati → activitati → polite → oferte → oportunitati → produse_asigurare → asiguratori → clienti → brokeri → agentii`

Acestea sunt functii apelate explicit, nu trigger-e. Un flux comercial care modifica mai multe tabele trebuie executat intr-o singura tranzactie: de exemplu acceptarea ofertei, emiterea politei si crearea ratelor. Functiile CRUD nu adauga reguli noi pentru egalitatea ratelor cu prima sau concordanta dintre etapa oportunitatii si existenta politei.

## Interpretarea verificarilor

`07_verificare_crud.sql` functioneaza si pe schema fara fixtures. Creeaza propriile inregistrari si verifica toate cele patru operatii pentru fiecare tabel, inclusiv rezultatele returnate si valorile din tabele. Testeaza 10 respingeri: suma negativa, plata fara metoda, broker inexistent, categorie incompatibila, doua oferte acceptate, stergere de agentie cu dependente, stergere de polita cu plati, activitate finalizata fara data, perioada nula si oportunitate inchisa fara data.

`04_verificare.sql` verifica separat setul initial de **256 de randuri** si regulile fixture-urilor etapei 1. Dupa adaugari sau stergeri permanente, numarul initial de randuri se schimba si aceasta verificare poate esua; acest lucru nu indica automat o problema a CRUD-ului. Fisierul lipsea din proiect si a fost refacut pentru comenzile existente `Setup`/`Verify`.

Demonstrarea si testarea CRUD folosesc `ROLLBACK`, astfel incat valorile randurilor initiale raman identice. Secventele `IDENTITY` avanseaza chiar daca tranzactia este anulata; golurile dintre ID-uri sunt normale. Daca un apel da eroare intr-o tranzactie explicita, executati `ROLLBACK;` in aceeasi conexiune inainte de a continua.

## Parametri noi pentru activitati

Dupa migrarea 08, `activitati_create` si `activitati_update` accepta la final `p_broker_id`, `p_client_id`, `p_agentie_id`, `p_vizibila_de_la`, toate cu default NULL pentru compatibilitatea exemplelor vechi. Cu un lead, valorile omise pentru agent/client/agentie sunt obtinute din oportunitate. Pentru sarcini fara lead se trimit explicit agentul si agentia; clientul ramane optional. Site-ul trimite explicit momentul afisarii si valideaza termenul-limita. Pentru apeluri vechi, momentul afisarii implicit nu depaseste termenul-limita.

O asociere lead-client-agentie inconsistenta este respinsa de FK. Termenul-limita anterior afisarii este respins de CHECK. Asignarea unei sarcini nu schimba brokerul responsabil al clientului sau al oportunitatii.
