SET search_path = broker_crm, public;

-- 1. Pipeline comercial per agentie.
SELECT a.denumire, o.etapa, count(*) AS oportunitati,
       sum(o.valoare_estimata) AS valoare_estimata_ron
FROM oportunitati o JOIN agentii a ON a.id=o.agentie_id
GROUP BY a.id, a.denumire, o.etapa ORDER BY a.id, o.etapa;

-- 2. Comparatia ofertelor pentru un client, cu produsul si asiguratorul.
SELECT c.nume AS client, o.titlu, f.numar, p.denumire AS produs,
       a.denumire AS asigurator, f.prima_anuala, f.stare
FROM oferte f JOIN oportunitati o ON o.id=f.oportunitate_id
JOIN clienti c ON c.id=o.client_id
JOIN produse_asigurare p ON p.id=f.produs_id
JOIN asiguratori a ON a.id=p.asigurator_id
WHERE c.id=1 ORDER BY o.id, f.prima_anuala;

-- 3. Portofoliul de polite: client, broker, asigurator si comision estimat.
SELECT p.numar, c.nume AS client, b.nume AS broker, a.denumire AS asigurator,
       pr.categorie, f.prima_anuala, p.sfarsit_la,
       round(f.prima_anuala*p.comision_procente/100,2) AS comision_estimat_ron
FROM polite p JOIN oferte f ON f.id=p.oferta_id
JOIN oportunitati o ON o.id=f.oportunitate_id
JOIN clienti c ON c.id=o.client_id JOIN brokeri b ON b.id=o.broker_id
JOIN produse_asigurare pr ON pr.id=f.produs_id
JOIN asiguratori a ON a.id=pr.asigurator_id
ORDER BY p.id;

-- 4. Sarcinile disponibile ale agentului 1, inclusiv cele fara lead/client.
-- Necesita extensia 08_profiluri_sarcini.sql; momentul afisarii este evaluat la executie.
SELECT ac.vizibila_de_la, ac.scadenta_la, ac.subiect, ac.tip, c.nume AS client, o.titlu
FROM activitati ac LEFT JOIN oportunitati o ON o.id=ac.oportunitate_id
LEFT JOIN clienti c ON c.id=ac.client_id
WHERE ac.broker_id=1 AND ac.stare='planificata' AND ac.vizibila_de_la <= now()
ORDER BY ac.scadenta_la;

-- 5. Calendarul ratelor viitoare (reper 2 noiembrie 2026).
SELECT p.numar, c.nume, r.numar_rata, r.suma, r.scadenta_la
FROM plati r JOIN polite p ON p.id=r.polita_id
JOIN oferte f ON f.id=p.oferta_id JOIN oportunitati o ON o.id=f.oportunitate_id
JOIN clienti c ON c.id=o.client_id
WHERE r.stare='planificata' AND r.scadenta_la>=DATE '2026-11-02'
ORDER BY r.scadenta_la, p.id;

-- 6. Relatie M:N: clientii si produsele ofertate, prin oportunitati si oferte.
SELECT DISTINCT c.id AS client_id, c.nume, pr.cod, pr.denumire
FROM clienti c JOIN oportunitati o ON o.client_id=c.id
JOIN oferte f ON f.oportunitate_id=o.id
JOIN produse_asigurare pr ON pr.id=f.produs_id
ORDER BY c.id, pr.cod;
