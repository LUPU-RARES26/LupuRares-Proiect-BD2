-- Verificarea fixture-urilor etapei 1; numerele sunt pentru setul initial demo.
-- Dupa adaugari/stergere permanenta de date, folositi 07_verificare_crud.sql
-- pentru testarea CRUD independent de numarul fixture-urilor.
BEGIN;
SET LOCAL search_path = broker_crm, public;
SET LOCAL lock_timeout = '5s';
DO $test$
DECLARE
    r record;
    v_count bigint;
    v_total bigint := 0;
BEGIN
    SELECT count(*) INTO v_count FROM information_schema.tables
    WHERE table_schema = 'broker_crm' AND table_type = 'BASE TABLE';
    IF v_count <> 10 THEN
        RAISE EXCEPTION 'FAIL: asteptate 10 tabele, gasite %', v_count;
    END IF;
    FOR r IN SELECT * FROM (VALUES
        ('agentii', 2), ('brokeri', 6), ('clienti', 24), ('asiguratori', 5),
        ('produse_asigurare', 15), ('oportunitati', 30), ('oferte', 60),
        ('polite', 18), ('activitati', 60), ('plati', 36)
    ) AS expected(tabel, randuri)
    LOOP
        EXECUTE format('SELECT count(*) FROM broker_crm.%I', r.tabel) INTO v_count;
        IF v_count <> r.randuri THEN
            RAISE EXCEPTION 'FAIL %: asteptate % randuri, gasite %', r.tabel, r.randuri, v_count;
        END IF;
        v_total := v_total + v_count;
    END LOOP;
    IF v_total <> 256 THEN RAISE EXCEPTION 'FAIL: total diferit de 256'; END IF;

    IF EXISTS (
        SELECT 1 FROM polite p JOIN oferte f ON f.id = p.oferta_id
        JOIN oportunitati o ON o.id = f.oportunitate_id WHERE o.etapa <> 'castigat'
    ) THEN RAISE EXCEPTION 'FAIL: polita fara oportunitate castigata'; END IF;

    IF EXISTS (
        SELECT 1 FROM oportunitati o WHERE o.etapa = 'castigat' AND NOT EXISTS (
            SELECT 1 FROM oferte f JOIN polite p ON p.oferta_id = f.id
            WHERE f.oportunitate_id = o.id
        )
    ) THEN RAISE EXCEPTION 'FAIL: oportunitate castigata fara polita'; END IF;

    IF EXISTS (
        SELECT p.id FROM polite p JOIN oferte f ON f.id = p.oferta_id
        LEFT JOIN plati rata ON rata.polita_id = p.id
        GROUP BY p.id, f.prima_anuala
        HAVING coalesce(sum(rata.suma), 0) <> f.prima_anuala
    ) THEN RAISE EXCEPTION 'FAIL: total rate diferit de prima'; END IF;

    IF EXISTS (
        SELECT 1 FROM clienti c WHERE (c.stare = 'client') <> EXISTS (
            SELECT 1 FROM oportunitati o JOIN oferte f ON f.oportunitate_id = o.id
            JOIN polite p ON p.oferta_id = f.id WHERE o.client_id = c.id
        )
    ) THEN RAISE EXCEPTION 'FAIL: stare client necorelata cu politele'; END IF;

    BEGIN
        UPDATE clienti SET broker_id = 2 WHERE id = 1;
        RAISE EXCEPTION 'FAIL: broker din alta agentie acceptat';
    EXCEPTION WHEN foreign_key_violation THEN NULL;
    END;
    BEGIN
        UPDATE plati SET polita_id = 999999 WHERE id = 1;
        RAISE EXCEPTION 'FAIL: polita inexistenta acceptata';
    EXCEPTION WHEN foreign_key_violation THEN NULL;
    END;
    BEGIN
        UPDATE plati SET suma = -1 WHERE id = 1;
        RAISE EXCEPTION 'FAIL: suma negativa acceptata';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    BEGIN
        UPDATE oferte SET stare = 'acceptata' WHERE id = 2;
        RAISE EXCEPTION 'FAIL: a doua oferta acceptata';
    EXCEPTION WHEN unique_violation THEN NULL;
    END;
    BEGIN
        UPDATE polite SET oferta_id = 2 WHERE id = 1;
        RAISE EXCEPTION 'FAIL: polita din oferta respinsa';
    EXCEPTION WHEN foreign_key_violation THEN NULL;
    END;
    BEGIN
        UPDATE oferte SET produs_id = 2 WHERE id = 1;
        RAISE EXCEPTION 'FAIL: produs din alta categorie acceptat';
    EXCEPTION WHEN foreign_key_violation THEN NULL;
    END;
    BEGIN
        DELETE FROM agentii WHERE id = 1;
        RAISE EXCEPTION 'FAIL: agentie cu dependente stearsa';
    EXCEPTION WHEN foreign_key_violation OR restrict_violation THEN NULL;
    END;
    BEGIN
        UPDATE polite SET sfarsit_la = inceput_la WHERE id = 1;
        RAISE EXCEPTION 'FAIL: perioada nula acceptata';
    EXCEPTION WHEN check_violation THEN NULL;
    END;
    RAISE NOTICE 'PASS: 10 tabele, 256 randuri, consistenta fixtures si 8 teste de respingere.';
END;
$test$;
ROLLBACK;
