-- CRUD pentru toate cele 10 tabele: 40 de functii PostgreSQL.
-- Rulati fisierul integral dupa 01_schema.sql (cu sau fara fixtures).
-- Instalarea este tranzactionala si poate fi repetata; nu modifica randurile.
-- CREATE/UPDATE/DELETE returneaza randul afectat (RETURNING *).
-- READ(NULL) / READ() listeaza tot; READ(id) citeste un singur rand.
-- UPDATE/DELETE pentru un id inexistent returneaza zero randuri.
-- UPDATE primeste toate campurile editabile; NULL este o valoare explicita,
-- nu inseamna "pastreaza valoarea anterioara". id si creat_la nu se modifica.
-- Functiile ruleaza cu drepturile apelantului (SECURITY INVOKER).
-- Nu inlocuiesc autorizarea si tranzactiile de business ale viitorului backend.
BEGIN;
SET LOCAL lock_timeout = '5s';


-- 1. AGENTII
-- Stergerea este permisa numai daca agentia nu are brokeri, clienti sau oportunitati.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.agentii_create(
    p_denumire varchar,
    p_cod_demo varchar,
    p_email varchar,
    p_oras varchar
)
RETURNS SETOF broker_crm.agentii
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.agentii (denumire, cod_demo, email, oras)
    VALUES (p_denumire, p_cod_demo, p_email, p_oras)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.agentii_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.agentii
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.agentii AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.agentii_update(
    p_id bigint,
    p_denumire varchar,
    p_cod_demo varchar,
    p_email varchar,
    p_oras varchar
)
RETURNS SETOF broker_crm.agentii
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.agentii AS t
    SET denumire = p_denumire,
        cod_demo = p_cod_demo,
        email = p_email,
        oras = p_oras
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.agentii_delete(p_id bigint)
RETURNS SETOF broker_crm.agentii
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.agentii AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 2. BROKERI
-- Agentia trebuie sa existe; brokerii cu clienti sau oportunitati nu pot fi stersi.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.brokeri_create(
    p_agentie_id bigint,
    p_nume varchar,
    p_email varchar,
    p_rol varchar,
    p_activ boolean
)
RETURNS SETOF broker_crm.brokeri
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.brokeri (agentie_id, nume, email, rol, activ)
    VALUES (p_agentie_id, p_nume, p_email, p_rol, p_activ)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.brokeri_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.brokeri
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.brokeri AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.brokeri_update(
    p_id bigint,
    p_agentie_id bigint,
    p_nume varchar,
    p_email varchar,
    p_rol varchar,
    p_activ boolean
)
RETURNS SETOF broker_crm.brokeri
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.brokeri AS t
    SET agentie_id = p_agentie_id,
        nume = p_nume,
        email = p_email,
        rol = p_rol,
        activ = p_activ
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.brokeri_delete(p_id bigint)
RETURNS SETOF broker_crm.brokeri
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.brokeri AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 3. CLIENTI
-- Brokerul si clientul trebuie sa apartina aceleiasi agentii (FK compusa).

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.clienti_create(
    p_agentie_id bigint,
    p_broker_id bigint,
    p_nume varchar,
    p_tip varchar,
    p_email varchar,
    p_oras varchar,
    p_stare varchar
)
RETURNS SETOF broker_crm.clienti
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.clienti (agentie_id, broker_id, nume, tip, email, oras, stare)
    VALUES (p_agentie_id, p_broker_id, p_nume, p_tip, p_email, p_oras, p_stare)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.clienti_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.clienti
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.clienti AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.clienti_update(
    p_id bigint,
    p_agentie_id bigint,
    p_broker_id bigint,
    p_nume varchar,
    p_tip varchar,
    p_email varchar,
    p_oras varchar,
    p_stare varchar
)
RETURNS SETOF broker_crm.clienti
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.clienti AS t
    SET agentie_id = p_agentie_id,
        broker_id = p_broker_id,
        nume = p_nume,
        tip = p_tip,
        email = p_email,
        oras = p_oras,
        stare = p_stare
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.clienti_delete(p_id bigint)
RETURNS SETOF broker_crm.clienti
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.clienti AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 4. ASIGURATORI
-- Un asigurator cu produse nu poate fi sters; activ=false permite dezactivarea.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.asiguratori_create(
    p_denumire varchar,
    p_cod_demo varchar,
    p_email varchar,
    p_activ boolean
)
RETURNS SETOF broker_crm.asiguratori
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.asiguratori (denumire, cod_demo, email, activ)
    VALUES (p_denumire, p_cod_demo, p_email, p_activ)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.asiguratori_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.asiguratori
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.asiguratori AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.asiguratori_update(
    p_id bigint,
    p_denumire varchar,
    p_cod_demo varchar,
    p_email varchar,
    p_activ boolean
)
RETURNS SETOF broker_crm.asiguratori
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.asiguratori AS t
    SET denumire = p_denumire,
        cod_demo = p_cod_demo,
        email = p_email,
        activ = p_activ
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.asiguratori_delete(p_id bigint)
RETURNS SETOF broker_crm.asiguratori
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.asiguratori AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 5. PRODUSE_ASIGURARE
-- Categoria poate fi RCA, CASCO sau LOCUINTA; ofertele protejeaza produsul referit.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.produse_asigurare_create(
    p_asigurator_id bigint,
    p_cod varchar,
    p_denumire varchar,
    p_categorie varchar,
    p_descriere text,
    p_activ boolean
)
RETURNS SETOF broker_crm.produse_asigurare
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.produse_asigurare (asigurator_id, cod, denumire, categorie, descriere, activ)
    VALUES (p_asigurator_id, p_cod, p_denumire, p_categorie, p_descriere, p_activ)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.produse_asigurare_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.produse_asigurare
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.produse_asigurare AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.produse_asigurare_update(
    p_id bigint,
    p_asigurator_id bigint,
    p_cod varchar,
    p_denumire varchar,
    p_categorie varchar,
    p_descriere text,
    p_activ boolean
)
RETURNS SETOF broker_crm.produse_asigurare
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.produse_asigurare AS t
    SET asigurator_id = p_asigurator_id,
        cod = p_cod,
        denumire = p_denumire,
        categorie = p_categorie,
        descriere = p_descriere,
        activ = p_activ
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.produse_asigurare_delete(p_id bigint)
RETURNS SETOF broker_crm.produse_asigurare
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.produse_asigurare AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 6. OPORTUNITATI
-- Etapele castigat/pierdut necesita inchis_la; brokerul/clientul apartin aceleiasi agentii.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.oportunitati_create(
    p_agentie_id bigint,
    p_client_id bigint,
    p_broker_id bigint,
    p_titlu varchar,
    p_categorie varchar,
    p_etapa varchar,
    p_sursa varchar,
    p_valoare_estimata numeric,
    p_moneda varchar,
    p_creat_la timestamptz,
    p_inchis_la timestamptz
)
RETURNS SETOF broker_crm.oportunitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.oportunitati (agentie_id, client_id, broker_id, titlu, categorie, etapa, sursa, valoare_estimata, moneda, creat_la, inchis_la)
    VALUES (p_agentie_id, p_client_id, p_broker_id, p_titlu, p_categorie, p_etapa, p_sursa, p_valoare_estimata, p_moneda, p_creat_la, p_inchis_la)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.oportunitati_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.oportunitati
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.oportunitati AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.oportunitati_update(
    p_id bigint,
    p_agentie_id bigint,
    p_client_id bigint,
    p_broker_id bigint,
    p_titlu varchar,
    p_categorie varchar,
    p_etapa varchar,
    p_sursa varchar,
    p_valoare_estimata numeric,
    p_moneda varchar,
    p_inchis_la timestamptz
)
RETURNS SETOF broker_crm.oportunitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.oportunitati AS t
    SET agentie_id = p_agentie_id,
        client_id = p_client_id,
        broker_id = p_broker_id,
        titlu = p_titlu,
        categorie = p_categorie,
        etapa = p_etapa,
        sursa = p_sursa,
        valoare_estimata = p_valoare_estimata,
        moneda = p_moneda,
        inchis_la = p_inchis_la
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.oportunitati_delete(p_id bigint)
RETURNS SETOF broker_crm.oportunitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.oportunitati AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 7. OFERTE
-- Produsul si oportunitatea au aceeasi categorie; maximum o oferta acceptata per oportunitate.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.oferte_create(
    p_oportunitate_id bigint,
    p_produs_id bigint,
    p_categorie varchar,
    p_numar varchar,
    p_prima_anuala numeric,
    p_suma_asigurata numeric,
    p_moneda varchar,
    p_stare varchar,
    p_emisa_la date,
    p_valabila_pana date
)
RETURNS SETOF broker_crm.oferte
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.oferte (oportunitate_id, produs_id, categorie, numar, prima_anuala, suma_asigurata, moneda, stare, emisa_la, valabila_pana)
    VALUES (p_oportunitate_id, p_produs_id, p_categorie, p_numar, p_prima_anuala, p_suma_asigurata, p_moneda, p_stare, p_emisa_la, p_valabila_pana)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.oferte_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.oferte
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.oferte AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.oferte_update(
    p_id bigint,
    p_oportunitate_id bigint,
    p_produs_id bigint,
    p_categorie varchar,
    p_numar varchar,
    p_prima_anuala numeric,
    p_suma_asigurata numeric,
    p_moneda varchar,
    p_stare varchar,
    p_emisa_la date,
    p_valabila_pana date
)
RETURNS SETOF broker_crm.oferte
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.oferte AS t
    SET oportunitate_id = p_oportunitate_id,
        produs_id = p_produs_id,
        categorie = p_categorie,
        numar = p_numar,
        prima_anuala = p_prima_anuala,
        suma_asigurata = p_suma_asigurata,
        moneda = p_moneda,
        stare = p_stare,
        emisa_la = p_emisa_la,
        valabila_pana = p_valabila_pana
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.oferte_delete(p_id bigint)
RETURNS SETOF broker_crm.oferte
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.oferte AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 8. POLITE
-- Oferta trebuie sa fie acceptata. stare_oferta ramane constanta implicita a tabelului.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.polite_create(
    p_oferta_id bigint,
    p_numar varchar,
    p_inceput_la date,
    p_sfarsit_la date,
    p_stare varchar,
    p_comision_procente numeric,
    p_emisa_la date
)
RETURNS SETOF broker_crm.polite
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.polite (oferta_id, numar, inceput_la, sfarsit_la, stare, comision_procente, emisa_la)
    VALUES (p_oferta_id, p_numar, p_inceput_la, p_sfarsit_la, p_stare, p_comision_procente, p_emisa_la)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.polite_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.polite
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.polite AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.polite_update(
    p_id bigint,
    p_oferta_id bigint,
    p_numar varchar,
    p_inceput_la date,
    p_sfarsit_la date,
    p_stare varchar,
    p_comision_procente numeric,
    p_emisa_la date
)
RETURNS SETOF broker_crm.polite
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.polite AS t
    SET oferta_id = p_oferta_id,
        numar = p_numar,
        inceput_la = p_inceput_la,
        sfarsit_la = p_sfarsit_la,
        stare = p_stare,
        comision_procente = p_comision_procente,
        emisa_la = p_emisa_la
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.polite_delete(p_id bigint)
RETURNS SETOF broker_crm.polite
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.polite AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 9. ACTIVITATI
-- stare=finalizata necesita finalizata_la; celelalte stari necesita NULL.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.activitati_create(
    p_oportunitate_id bigint,
    p_tip varchar,
    p_subiect varchar,
    p_descriere text,
    p_scadenta_la timestamptz,
    p_finalizata_la timestamptz,
    p_stare varchar,
    p_broker_id bigint DEFAULT NULL,
    p_client_id bigint DEFAULT NULL,
    p_agentie_id bigint DEFAULT NULL,
    p_vizibila_de_la timestamptz DEFAULT NULL
)
RETURNS SETOF broker_crm.activitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.activitati (oportunitate_id, tip, subiect, descriere, scadenta_la, finalizata_la, stare, broker_id, client_id, agentie_id, vizibila_de_la)
    VALUES (p_oportunitate_id, p_tip, p_subiect, p_descriere, p_scadenta_la, p_finalizata_la, p_stare,
      COALESCE(p_broker_id, (SELECT broker_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
      COALESCE(p_client_id, (SELECT client_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
      COALESCE(p_agentie_id, (SELECT agentie_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
      COALESCE(p_vizibila_de_la, LEAST(now(), p_scadenta_la)))
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.activitati_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.activitati
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.activitati AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.activitati_update(
    p_id bigint,
    p_oportunitate_id bigint,
    p_tip varchar,
    p_subiect varchar,
    p_descriere text,
    p_scadenta_la timestamptz,
    p_finalizata_la timestamptz,
    p_stare varchar,
    p_broker_id bigint DEFAULT NULL,
    p_client_id bigint DEFAULT NULL,
    p_agentie_id bigint DEFAULT NULL,
    p_vizibila_de_la timestamptz DEFAULT NULL
)
RETURNS SETOF broker_crm.activitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.activitati AS t
    SET oportunitate_id = p_oportunitate_id, tip = p_tip, subiect = p_subiect,
        descriere = p_descriere, scadenta_la = p_scadenta_la,
        finalizata_la = p_finalizata_la, stare = p_stare,
        broker_id = COALESCE(p_broker_id, (SELECT broker_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
        client_id = COALESCE(p_client_id, (SELECT client_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
        agentie_id = COALESCE(p_agentie_id, (SELECT agentie_id FROM broker_crm.oportunitati WHERE id=p_oportunitate_id)),
        vizibila_de_la = COALESCE(p_vizibila_de_la, LEAST(t.vizibila_de_la, p_scadenta_la))
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.activitati_delete(p_id bigint)
RETURNS SETOF broker_crm.activitati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.activitati AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;


-- 10. PLATI
-- stare=platita necesita platita_la, metoda si referinta_demo; suma trebuie sa fie pozitiva.

-- C = CREATE (INSERT): id este generat automat.
CREATE OR REPLACE FUNCTION broker_crm.plati_create(
    p_polita_id bigint,
    p_numar_rata integer,
    p_suma numeric,
    p_moneda varchar,
    p_scadenta_la date,
    p_platita_la date,
    p_metoda varchar,
    p_referinta_demo varchar,
    p_stare varchar
)
RETURNS SETOF broker_crm.plati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    INSERT INTO broker_crm.plati (polita_id, numar_rata, suma, moneda, scadenta_la, platita_la, metoda, referinta_demo, stare)
    VALUES (p_polita_id, p_numar_rata, p_suma, p_moneda, p_scadenta_la, p_platita_la, p_metoda, p_referinta_demo, p_stare)
    RETURNING *;
$function$;

-- R = READ (SELECT): fara id se obtine lista ordonata dupa id.
CREATE OR REPLACE FUNCTION broker_crm.plati_read(p_id bigint DEFAULT NULL)
RETURNS SETOF broker_crm.plati
LANGUAGE sql STABLE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    SELECT t.* FROM broker_crm.plati AS t
    WHERE p_id IS NULL OR t.id = p_id
    ORDER BY t.id;
$function$;

-- U = UPDATE: modificare numai pentru cheia primara primita.
CREATE OR REPLACE FUNCTION broker_crm.plati_update(
    p_id bigint,
    p_polita_id bigint,
    p_numar_rata integer,
    p_suma numeric,
    p_moneda varchar,
    p_scadenta_la date,
    p_platita_la date,
    p_metoda varchar,
    p_referinta_demo varchar,
    p_stare varchar
)
RETURNS SETOF broker_crm.plati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    UPDATE broker_crm.plati AS t
    SET polita_id = p_polita_id,
        numar_rata = p_numar_rata,
        suma = p_suma,
        moneda = p_moneda,
        scadenta_la = p_scadenta_la,
        platita_la = p_platita_la,
        metoda = p_metoda,
        referinta_demo = p_referinta_demo,
        stare = p_stare
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

-- D = DELETE: cheile straine ON DELETE RESTRICT raman active.
CREATE OR REPLACE FUNCTION broker_crm.plati_delete(p_id bigint)
RETURNS SETOF broker_crm.plati
LANGUAGE sql VOLATILE SECURITY INVOKER
SET search_path = pg_catalog
AS $function$
    DELETE FROM broker_crm.plati AS t
    WHERE t.id = p_id
    RETURNING t.*;
$function$;

COMMIT;
