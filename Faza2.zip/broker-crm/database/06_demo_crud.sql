-- DEMONSTRATIE CRUD: 10 INSERT, 10 SELECT, 10 UPDATE, 10 DELETE prin functii.
-- Instalati intai 05_crud.sql. Rulati TOT fisierul in aceeasi conexiune.
-- Se creeaza un set nou, legat prin id-uri returnate de CREATE; nu folosim id=1.
-- Tabelul temporar retine aceste id-uri numai in sesiunea curenta.
-- Datele demo initiale sunt pastrate; ROLLBACK anuleaza tranzactia la final.
-- Secventele IDENTITY avanseaza inclusiv dupa ROLLBACK (comportament PostgreSQL).
BEGIN;
SET LOCAL lock_timeout = '5s';
CREATE TEMP TABLE crud_demo_ids (
    tabel text PRIMARY KEY,
    id bigint NOT NULL
) ON COMMIT DROP;

-- A. CREATE: mai intai parintii, apoi copiii.

-- C1. agentii
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'agentii', id FROM broker_crm.agentii_create(
    'Agentie CRUD Demo',
    'CRUD-AG-' || txid_current(),
    'agentie.' || txid_current() || '@crud.example',
    'Bucuresti'
)
RETURNING *;

-- C2. brokeri
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'brokeri', id FROM broker_crm.brokeri_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    'Broker CRUD Demo',
    'broker.' || txid_current() || '@crud.example',
    'broker',
    true
)
RETURNING *;

-- C3. clienti
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'clienti', id FROM broker_crm.clienti_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri'),
    'Client CRUD Demo',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Bucuresti',
    'prospect'
)
RETURNING *;

-- C4. asiguratori
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'asiguratori', id FROM broker_crm.asiguratori_create(
    'Asigurator CRUD ' || txid_current(),
    'CRUD-AS-' || txid_current(),
    'asigurator.' || txid_current() || '@crud.example',
    true
)
RETURNING *;

-- C5. produse_asigurare
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'produse_asigurare', id FROM broker_crm.produse_asigurare_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'asiguratori'),
    'CRUD-PROD-' || txid_current(),
    'RCA CRUD Demo',
    'RCA',
    'Produs fictiv pentru demonstratia CRUD.',
    true
)
RETURNING *;

-- C6. oportunitati
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'oportunitati', id FROM broker_crm.oportunitati_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'clienti'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri'),
    'Oportunitate CRUD Demo',
    'RCA',
    'nou',
    'website',
    1500.00,
    'RON',
    TIMESTAMPTZ '2026-11-15 09:00:00+02',
    NULL
)
RETURNING *;

-- C7. oferte
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'oferte', id FROM broker_crm.oferte_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'produse_asigurare'),
    'RCA',
    'CRUD-OF-' || txid_current(),
    1500.00,
    6000000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-11-30'
)
RETURNING *;

-- C8. polite
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'polite', id FROM broker_crm.polite_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oferte'),
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2027-11-16',
    'programata',
    10.00,
    DATE '2026-11-15'
)
RETURNING *;

-- C9. activitati
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'activitati', id FROM broker_crm.activitati_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati'),
    'apel',
    'Contact initial CRUD',
    'Activitate fictiva pentru CRUD.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    NULL,
    'planificata'
)
RETURNING *;

-- C10. plati
INSERT INTO pg_temp.crud_demo_ids (tabel, id)
SELECT 'plati', id FROM broker_crm.plati_create(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'polite'),
    1,
    1500.00,
    'RON',
    DATE '2026-11-16',
    NULL,
    NULL,
    NULL,
    'planificata'
)
RETURNING *;

-- B. READ: citirea fiecarui rand nou. Pentru lista completa: SELECT * FROM broker_crm.<tabel>_read();

-- R1. agentii
SELECT * FROM broker_crm.agentii_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii')
);

-- R2. brokeri
SELECT * FROM broker_crm.brokeri_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri')
);

-- R3. clienti
SELECT * FROM broker_crm.clienti_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'clienti')
);

-- R4. asiguratori
SELECT * FROM broker_crm.asiguratori_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'asiguratori')
);

-- R5. produse_asigurare
SELECT * FROM broker_crm.produse_asigurare_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'produse_asigurare')
);

-- R6. oportunitati
SELECT * FROM broker_crm.oportunitati_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati')
);

-- R7. oferte
SELECT * FROM broker_crm.oferte_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oferte')
);

-- R8. polite
SELECT * FROM broker_crm.polite_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'polite')
);

-- R9. activitati
SELECT * FROM broker_crm.activitati_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'activitati')
);

-- R10. plati
SELECT * FROM broker_crm.plati_read(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'plati')
);

-- C. UPDATE: RETURNING afiseaza noile valori. Parametrii nullable primesc explicit NULL cand este cazul.

-- U1. agentii
SELECT * FROM broker_crm.agentii_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    'Agentie CRUD Actualizata',
    'CRUD-AG-' || txid_current(),
    'agentie.' || txid_current() || '@crud.example',
    'Brasov'
);

-- U2. brokeri
SELECT * FROM broker_crm.brokeri_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    'Broker CRUD Actualizat',
    'broker.' || txid_current() || '@crud.example',
    'administrator',
    false
);

-- U3. clienti
SELECT * FROM broker_crm.clienti_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'clienti'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri'),
    'Client CRUD Actualizat',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Brasov',
    'client'
);

-- U4. asiguratori
SELECT * FROM broker_crm.asiguratori_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'asiguratori'),
    'Asigurator CRUD Actualizat ' || txid_current(),
    'CRUD-AS-' || txid_current(),
    'asigurator.' || txid_current() || '@crud.example',
    false
);

-- U5. produse_asigurare
SELECT * FROM broker_crm.produse_asigurare_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'produse_asigurare'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'asiguratori'),
    'CRUD-PROD-' || txid_current(),
    'RCA CRUD Actualizat',
    'RCA',
    'Descriere actualizata prin CRUD.',
    false
);

-- U6. oportunitati
SELECT * FROM broker_crm.oportunitati_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'clienti'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri'),
    'Oportunitate CRUD Actualizata',
    'RCA',
    'castigat',
    'telefon',
    1600.00,
    'RON',
    TIMESTAMPTZ '2026-11-15 12:00:00+02'
);

-- U7. oferte
SELECT * FROM broker_crm.oferte_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oferte'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'produse_asigurare'),
    'RCA',
    'CRUD-OF-' || txid_current(),
    1600.00,
    6500000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-12-05'
);

-- U8. polite
SELECT * FROM broker_crm.polite_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'polite'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oferte'),
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2027-11-16',
    'activa',
    12.50,
    DATE '2026-11-15'
);

-- U9. activitati
SELECT * FROM broker_crm.activitati_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'activitati'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati'),
    'email',
    'Confirmare polita CRUD',
    'Clientul a fost informat.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    TIMESTAMPTZ '2026-11-16 10:15:00+02',
    'finalizata'
);

-- U10. plati
SELECT * FROM broker_crm.plati_update(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'plati'),
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'polite'),
    1,
    1600.00,
    'RON',
    DATE '2026-11-16',
    DATE '2026-11-16',
    'transfer',
    'CRUD-TXN-' || txid_current(),
    'platita'
);

-- D. DELETE: ordine inversa, astfel incat sa nu ramana copii care refera un parinte sters.

-- D1. plati
SELECT * FROM broker_crm.plati_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'plati')
);

-- D2. activitati
SELECT * FROM broker_crm.activitati_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'activitati')
);

-- D3. polite
SELECT * FROM broker_crm.polite_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'polite')
);

-- D4. oferte
SELECT * FROM broker_crm.oferte_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oferte')
);

-- D5. oportunitati
SELECT * FROM broker_crm.oportunitati_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'oportunitati')
);

-- D6. produse_asigurare
SELECT * FROM broker_crm.produse_asigurare_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'produse_asigurare')
);

-- D7. asiguratori
SELECT * FROM broker_crm.asiguratori_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'asiguratori')
);

-- D8. clienti
SELECT * FROM broker_crm.clienti_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'clienti')
);

-- D9. brokeri
SELECT * FROM broker_crm.brokeri_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'brokeri')
);

-- D10. agentii
SELECT * FROM broker_crm.agentii_delete(
    (SELECT id FROM pg_temp.crud_demo_ids WHERE tabel = 'agentii')
);

ROLLBACK;
