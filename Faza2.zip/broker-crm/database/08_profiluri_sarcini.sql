-- Extensie compatibila cu cele 10 tabele ale proiectului.
-- Ordine pentru o instalare noua: 01, 02, 08, 05.
-- Pentru baza existenta: 08, 05. Nu sterge datele existente.
BEGIN;
SET LOCAL search_path = broker_crm, public;

DO $migration$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_schema='broker_crm' AND table_name='activitati' AND column_name='vizibila_de_la') THEN
    ALTER TABLE oportunitati ADD CONSTRAINT oportunitati_profil_unique UNIQUE (id, client_id, agentie_id);
    ALTER TABLE activitati
      ADD COLUMN broker_id bigint,
      ADD COLUMN client_id bigint,
      ADD COLUMN agentie_id bigint,
      ADD COLUMN vizibila_de_la timestamptz,
      ALTER COLUMN oportunitate_id DROP NOT NULL;

    UPDATE activitati a SET broker_id=o.broker_id, client_id=o.client_id,
      agentie_id=o.agentie_id, vizibila_de_la=LEAST(o.creat_la, a.scadenta_la)
    FROM oportunitati o WHERE o.id=a.oportunitate_id;

    ALTER TABLE activitati
      ALTER COLUMN broker_id SET NOT NULL,
      ALTER COLUMN agentie_id SET NOT NULL,
      ALTER COLUMN vizibila_de_la SET NOT NULL,
      DROP CONSTRAINT activitati_tip_check,
      ADD CONSTRAINT activitati_tip_check CHECK (tip IN ('apel','email','intalnire','sarcina','programare','email_sms','reminder','de_facut')),
      ADD CONSTRAINT activitati_agent_fk FOREIGN KEY (broker_id, agentie_id) REFERENCES brokeri(id, agentie_id) ON DELETE RESTRICT,
      ADD CONSTRAINT activitati_client_fk FOREIGN KEY (client_id, agentie_id) REFERENCES clienti(id, agentie_id) ON DELETE RESTRICT,
      ADD CONSTRAINT activitati_profil_fk FOREIGN KEY (oportunitate_id, client_id, agentie_id) REFERENCES oportunitati(id, client_id, agentie_id) ON DELETE RESTRICT,
      ADD CONSTRAINT activitati_lead_client_check CHECK (oportunitate_id IS NULL OR client_id IS NOT NULL),
      ADD CONSTRAINT activitati_interval_check CHECK (vizibila_de_la <= scadenta_la);
    CREATE INDEX activitati_agent_vizibilitate_idx ON activitati(broker_id, stare, vizibila_de_la, scadenta_la);
    CREATE INDEX activitati_client_idx ON activitati(client_id);
  END IF;
END;
$migration$;

-- Elimina doar semnaturile vechi. Versiunile noi din 05 accepta si apelurile vechi
-- prin parametri optionali; nu raman overload-uri ambigue.
DROP FUNCTION IF EXISTS broker_crm.activitati_create(bigint, varchar, varchar, text, timestamptz, timestamptz, varchar);
DROP FUNCTION IF EXISTS broker_crm.activitati_update(bigint, bigint, varchar, varchar, text, timestamptz, timestamptz, varchar);
COMMIT;
