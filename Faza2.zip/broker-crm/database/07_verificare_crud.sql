-- Teste de integrare pentru 05_crud.sql, independente de id-urile fixture-urilor.
-- Ruleaza pe baza existenta sau pe schema goala; creeaza propriile dependente.
-- Verifica randurile returnate, valorile persistate, listarea, lipsa id-ului,
-- constrangerile, NULL explicit si stergerea in ordinea corecta.
-- Toate modificarile randurilor sunt anulate. Secventele pot avansa.
BEGIN;
SET LOCAL lock_timeout = '5s';
DO $test$
DECLARE

    v_agentii bigint;

    v_brokeri bigint;

    v_clienti bigint;

    v_asiguratori bigint;

    v_produse_asigurare bigint;

    v_oportunitati bigint;

    v_oferte bigint;

    v_polite bigint;

    v_activitati bigint;

    v_plati bigint;

    r record;
    v_table text;
    v_count bigint;
    v_before jsonb := '{}'::jsonb;
    v_after jsonb := '{}'::jsonb;
    v_value jsonb;
BEGIN
    -- Snapshot al tuturor valorilor, nu doar al numarului de randuri.
    FOR v_table IN
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'broker_crm' AND table_type = 'BASE TABLE'
    LOOP
        EXECUTE format('SELECT coalesce(jsonb_agg(to_jsonb(t) ORDER BY t.id), ''[]''::jsonb) FROM broker_crm.%I AS t', v_table)
            INTO v_value;
        v_before := v_before || jsonb_build_object(v_table, v_value);
    END LOOP;
    IF (SELECT count(*) FROM information_schema.tables WHERE table_schema = 'broker_crm' AND table_type = 'BASE TABLE') <> 10 THEN
        RAISE EXCEPTION 'FAIL: schema trebuie sa contina exact 10 tabele';
    END IF;

    -- CREATE agentii: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.agentii_create(
    'Agentie CRUD Demo',
    'CRUD-AG-' || txid_current(),
    'agentie.' || txid_current() || '@crud.example',
    'Bucuresti'
);
    v_agentii := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Agentie CRUD Demo',
            'cod_demo', 'CRUD-AG-' || txid_current(),
            'email', 'agentie.' || txid_current() || '@crud.example',
            'oras', 'Bucuresti')) THEN
        RAISE EXCEPTION 'FAIL agentii create: valori diferite de cele cerute';
    END IF;

    IF v_agentii IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.agentii WHERE id = v_agentii) THEN
        RAISE EXCEPTION 'FAIL agentii CREATE: randul nu este persistat';
    END IF;

    -- CREATE brokeri: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.brokeri_create(
    v_agentii,
    'Broker CRUD Demo',
    'broker.' || txid_current() || '@crud.example',
    'broker',
    true
);
    v_brokeri := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'nume', 'Broker CRUD Demo',
            'email', 'broker.' || txid_current() || '@crud.example',
            'rol', 'broker',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL brokeri create: valori diferite de cele cerute';
    END IF;

    IF v_brokeri IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.brokeri WHERE id = v_brokeri) THEN
        RAISE EXCEPTION 'FAIL brokeri CREATE: randul nu este persistat';
    END IF;

    -- CREATE clienti: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.clienti_create(
    v_agentii,
    v_brokeri,
    'Client CRUD Demo',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Bucuresti',
    'prospect'
);
    v_clienti := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'broker_id', v_brokeri,
            'nume', 'Client CRUD Demo',
            'tip', 'persoana',
            'email', 'client.' || txid_current() || '@crud.example',
            'oras', 'Bucuresti',
            'stare', 'prospect')) THEN
        RAISE EXCEPTION 'FAIL clienti create: valori diferite de cele cerute';
    END IF;

    IF v_clienti IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.clienti WHERE id = v_clienti) THEN
        RAISE EXCEPTION 'FAIL clienti CREATE: randul nu este persistat';
    END IF;

    -- CREATE asiguratori: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.asiguratori_create(
    'Asigurator CRUD ' || txid_current(),
    'CRUD-AS-' || txid_current(),
    'asigurator.' || txid_current() || '@crud.example',
    true
);
    v_asiguratori := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Asigurator CRUD ' || txid_current(),
            'cod_demo', 'CRUD-AS-' || txid_current(),
            'email', 'asigurator.' || txid_current() || '@crud.example',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL asiguratori create: valori diferite de cele cerute';
    END IF;

    IF v_asiguratori IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.asiguratori WHERE id = v_asiguratori) THEN
        RAISE EXCEPTION 'FAIL asiguratori CREATE: randul nu este persistat';
    END IF;

    -- CREATE produse_asigurare: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.produse_asigurare_create(
    v_asiguratori,
    'CRUD-PROD-' || txid_current(),
    'RCA CRUD Demo',
    'RCA',
    'Produs fictiv pentru demonstratia CRUD.',
    true
);
    v_produse_asigurare := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'asigurator_id', v_asiguratori,
            'cod', 'CRUD-PROD-' || txid_current(),
            'denumire', 'RCA CRUD Demo',
            'categorie', 'RCA',
            'descriere', 'Produs fictiv pentru demonstratia CRUD.',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare create: valori diferite de cele cerute';
    END IF;

    IF v_produse_asigurare IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.produse_asigurare WHERE id = v_produse_asigurare) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare CREATE: randul nu este persistat';
    END IF;

    -- CREATE oportunitati: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.oportunitati_create(
    v_agentii,
    v_clienti,
    v_brokeri,
    'Oportunitate CRUD Demo',
    'RCA',
    'nou',
    'website',
    1500.00,
    'RON',
    TIMESTAMPTZ '2026-11-15 09:00:00+02',
    NULL
);
    v_oportunitati := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'client_id', v_clienti,
            'broker_id', v_brokeri,
            'titlu', 'Oportunitate CRUD Demo',
            'categorie', 'RCA',
            'etapa', 'nou',
            'sursa', 'website',
            'valoare_estimata', 1500.00,
            'moneda', 'RON',
            'creat_la', TIMESTAMPTZ '2026-11-15 09:00:00+02',
            'inchis_la', NULL)) THEN
        RAISE EXCEPTION 'FAIL oportunitati create: valori diferite de cele cerute';
    END IF;

    IF v_oportunitati IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.oportunitati WHERE id = v_oportunitati) THEN
        RAISE EXCEPTION 'FAIL oportunitati CREATE: randul nu este persistat';
    END IF;

    -- CREATE oferte: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.oferte_create(
    v_oportunitati,
    v_produse_asigurare,
    'RCA',
    'CRUD-OF-' || txid_current(),
    1500.00,
    6000000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-11-30'
);
    v_oferte := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'produs_id', v_produse_asigurare,
            'categorie', 'RCA',
            'numar', 'CRUD-OF-' || txid_current(),
            'prima_anuala', 1500.00,
            'suma_asigurata', 6000000.00,
            'moneda', 'RON',
            'stare', 'acceptata',
            'emisa_la', DATE '2026-11-15',
            'valabila_pana', DATE '2026-11-30')) THEN
        RAISE EXCEPTION 'FAIL oferte create: valori diferite de cele cerute';
    END IF;

    IF v_oferte IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.oferte WHERE id = v_oferte) THEN
        RAISE EXCEPTION 'FAIL oferte CREATE: randul nu este persistat';
    END IF;

    -- CREATE polite: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.polite_create(
    v_oferte,
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2027-11-16',
    'programata',
    10.00,
    DATE '2026-11-15'
);
    v_polite := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oferta_id', v_oferte,
            'numar', 'CRUD-POL-' || txid_current(),
            'inceput_la', DATE '2026-11-16',
            'sfarsit_la', DATE '2027-11-16',
            'stare', 'programata',
            'comision_procente', 10.00,
            'emisa_la', DATE '2026-11-15')) THEN
        RAISE EXCEPTION 'FAIL polite create: valori diferite de cele cerute';
    END IF;

    IF v_polite IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.polite WHERE id = v_polite) THEN
        RAISE EXCEPTION 'FAIL polite CREATE: randul nu este persistat';
    END IF;

    -- CREATE activitati: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.activitati_create(
    v_oportunitati,
    'apel',
    'Contact initial CRUD',
    'Activitate fictiva pentru CRUD.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    NULL,
    'planificata'
);
    v_activitati := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'tip', 'apel',
            'subiect', 'Contact initial CRUD',
            'descriere', 'Activitate fictiva pentru CRUD.',
            'scadenta_la', TIMESTAMPTZ '2026-11-16 10:00:00+02',
            'finalizata_la', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL activitati create: valori diferite de cele cerute';
    END IF;

    IF v_activitati IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.activitati WHERE id = v_activitati) THEN
        RAISE EXCEPTION 'FAIL activitati CREATE: randul nu este persistat';
    END IF;

    -- CREATE plati: exact un rand nou, cu valori corecte.
    SELECT * INTO STRICT r FROM broker_crm.plati_create(
    v_polite,
    1,
    1500.00,
    'RON',
    DATE '2026-11-16',
    NULL,
    NULL,
    NULL,
    'planificata'
);
    v_plati := r.id;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'polita_id', v_polite,
            'numar_rata', 1,
            'suma', 1500.00,
            'moneda', 'RON',
            'scadenta_la', DATE '2026-11-16',
            'platita_la', NULL,
            'metoda', NULL,
            'referinta_demo', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL plati create: valori diferite de cele cerute';
    END IF;

    IF v_plati IS NULL OR NOT EXISTS (SELECT 1 FROM broker_crm.plati WHERE id = v_plati) THEN
        RAISE EXCEPTION 'FAIL plati CREATE: randul nu este persistat';
    END IF;

    -- READ agentii: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.agentii_read(v_agentii);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Agentie CRUD Demo',
            'cod_demo', 'CRUD-AG-' || txid_current(),
            'email', 'agentie.' || txid_current() || '@crud.example',
            'oras', 'Bucuresti')) THEN
        RAISE EXCEPTION 'FAIL agentii create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.agentii_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.agentii) THEN
        RAISE EXCEPTION 'FAIL agentii READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.agentii_read(NULL) WHERE id = v_agentii) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL agentii READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.agentii_read(0)) THEN
        RAISE EXCEPTION 'FAIL agentii READ: id inexistent';
    END IF;

    -- READ brokeri: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.brokeri_read(v_brokeri);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'nume', 'Broker CRUD Demo',
            'email', 'broker.' || txid_current() || '@crud.example',
            'rol', 'broker',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL brokeri create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.brokeri_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.brokeri) THEN
        RAISE EXCEPTION 'FAIL brokeri READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.brokeri_read(NULL) WHERE id = v_brokeri) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL brokeri READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.brokeri_read(0)) THEN
        RAISE EXCEPTION 'FAIL brokeri READ: id inexistent';
    END IF;

    -- READ clienti: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.clienti_read(v_clienti);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'broker_id', v_brokeri,
            'nume', 'Client CRUD Demo',
            'tip', 'persoana',
            'email', 'client.' || txid_current() || '@crud.example',
            'oras', 'Bucuresti',
            'stare', 'prospect')) THEN
        RAISE EXCEPTION 'FAIL clienti create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.clienti_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.clienti) THEN
        RAISE EXCEPTION 'FAIL clienti READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.clienti_read(NULL) WHERE id = v_clienti) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL clienti READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.clienti_read(0)) THEN
        RAISE EXCEPTION 'FAIL clienti READ: id inexistent';
    END IF;

    -- READ asiguratori: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.asiguratori_read(v_asiguratori);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Asigurator CRUD ' || txid_current(),
            'cod_demo', 'CRUD-AS-' || txid_current(),
            'email', 'asigurator.' || txid_current() || '@crud.example',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL asiguratori create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.asiguratori_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.asiguratori) THEN
        RAISE EXCEPTION 'FAIL asiguratori READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.asiguratori_read(NULL) WHERE id = v_asiguratori) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL asiguratori READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.asiguratori_read(0)) THEN
        RAISE EXCEPTION 'FAIL asiguratori READ: id inexistent';
    END IF;

    -- READ produse_asigurare: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.produse_asigurare_read(v_produse_asigurare);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'asigurator_id', v_asiguratori,
            'cod', 'CRUD-PROD-' || txid_current(),
            'denumire', 'RCA CRUD Demo',
            'categorie', 'RCA',
            'descriere', 'Produs fictiv pentru demonstratia CRUD.',
            'activ', true)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.produse_asigurare_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.produse_asigurare) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.produse_asigurare_read(NULL) WHERE id = v_produse_asigurare) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL produse_asigurare READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.produse_asigurare_read(0)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare READ: id inexistent';
    END IF;

    -- READ oportunitati: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.oportunitati_read(v_oportunitati);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'client_id', v_clienti,
            'broker_id', v_brokeri,
            'titlu', 'Oportunitate CRUD Demo',
            'categorie', 'RCA',
            'etapa', 'nou',
            'sursa', 'website',
            'valoare_estimata', 1500.00,
            'moneda', 'RON',
            'creat_la', TIMESTAMPTZ '2026-11-15 09:00:00+02',
            'inchis_la', NULL)) THEN
        RAISE EXCEPTION 'FAIL oportunitati create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.oportunitati_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.oportunitati) THEN
        RAISE EXCEPTION 'FAIL oportunitati READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oportunitati_read(NULL) WHERE id = v_oportunitati) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL oportunitati READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oportunitati_read(0)) THEN
        RAISE EXCEPTION 'FAIL oportunitati READ: id inexistent';
    END IF;

    -- READ oferte: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.oferte_read(v_oferte);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'produs_id', v_produse_asigurare,
            'categorie', 'RCA',
            'numar', 'CRUD-OF-' || txid_current(),
            'prima_anuala', 1500.00,
            'suma_asigurata', 6000000.00,
            'moneda', 'RON',
            'stare', 'acceptata',
            'emisa_la', DATE '2026-11-15',
            'valabila_pana', DATE '2026-11-30')) THEN
        RAISE EXCEPTION 'FAIL oferte create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.oferte_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.oferte) THEN
        RAISE EXCEPTION 'FAIL oferte READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oferte_read(NULL) WHERE id = v_oferte) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL oferte READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oferte_read(0)) THEN
        RAISE EXCEPTION 'FAIL oferte READ: id inexistent';
    END IF;

    -- READ polite: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.polite_read(v_polite);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oferta_id', v_oferte,
            'numar', 'CRUD-POL-' || txid_current(),
            'inceput_la', DATE '2026-11-16',
            'sfarsit_la', DATE '2027-11-16',
            'stare', 'programata',
            'comision_procente', 10.00,
            'emisa_la', DATE '2026-11-15')) THEN
        RAISE EXCEPTION 'FAIL polite create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.polite_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.polite) THEN
        RAISE EXCEPTION 'FAIL polite READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.polite_read(NULL) WHERE id = v_polite) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL polite READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.polite_read(0)) THEN
        RAISE EXCEPTION 'FAIL polite READ: id inexistent';
    END IF;

    -- READ activitati: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.activitati_read(v_activitati);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'tip', 'apel',
            'subiect', 'Contact initial CRUD',
            'descriere', 'Activitate fictiva pentru CRUD.',
            'scadenta_la', TIMESTAMPTZ '2026-11-16 10:00:00+02',
            'finalizata_la', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL activitati create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.activitati_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.activitati) THEN
        RAISE EXCEPTION 'FAIL activitati READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.activitati_read(NULL) WHERE id = v_activitati) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL activitati READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.activitati_read(0)) THEN
        RAISE EXCEPTION 'FAIL activitati READ: id inexistent';
    END IF;

    -- READ plati: id, lista completa, id inexistent.
    SELECT * INTO STRICT r FROM broker_crm.plati_read(v_plati);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'polita_id', v_polite,
            'numar_rata', 1,
            'suma', 1500.00,
            'moneda', 'RON',
            'scadenta_la', DATE '2026-11-16',
            'platita_la', NULL,
            'metoda', NULL,
            'referinta_demo', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL plati create: valori diferite de cele cerute';
    END IF;

    SELECT count(*) INTO v_count FROM broker_crm.plati_read();
    IF v_count <> (SELECT count(*) FROM broker_crm.plati) THEN
        RAISE EXCEPTION 'FAIL plati READ: lista incompleta';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.plati_read(NULL) WHERE id = v_plati) IS NOT TRUE THEN
        RAISE EXCEPTION 'FAIL plati READ(NULL)';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.plati_read(0)) THEN
        RAISE EXCEPTION 'FAIL plati READ: id inexistent';
    END IF;

    -- UPDATE agentii: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.agentii_update(
    v_agentii,
    'Agentie CRUD Actualizata',
    'CRUD-AG-' || txid_current(),
    'agentie.' || txid_current() || '@crud.example',
    'Brasov'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Agentie CRUD Actualizata',
            'cod_demo', 'CRUD-AG-' || txid_current(),
            'email', 'agentie.' || txid_current() || '@crud.example',
            'oras', 'Brasov')) THEN
        RAISE EXCEPTION 'FAIL agentii update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.agentii WHERE id = v_agentii;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Agentie CRUD Actualizata',
            'cod_demo', 'CRUD-AG-' || txid_current(),
            'email', 'agentie.' || txid_current() || '@crud.example',
            'oras', 'Brasov')) THEN
        RAISE EXCEPTION 'FAIL agentii update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.agentii_update(
    0,
    'Agentie CRUD Actualizata',
    'CRUD-AG-' || txid_current(),
    'agentie.' || txid_current() || '@crud.example',
    'Brasov'
)) THEN
        RAISE EXCEPTION 'FAIL agentii UPDATE: id inexistent';
    END IF;

    -- UPDATE brokeri: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.brokeri_update(
    v_brokeri,
    v_agentii,
    'Broker CRUD Actualizat',
    'broker.' || txid_current() || '@crud.example',
    'administrator',
    false
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'nume', 'Broker CRUD Actualizat',
            'email', 'broker.' || txid_current() || '@crud.example',
            'rol', 'administrator',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL brokeri update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.brokeri WHERE id = v_brokeri;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'nume', 'Broker CRUD Actualizat',
            'email', 'broker.' || txid_current() || '@crud.example',
            'rol', 'administrator',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL brokeri update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.brokeri_update(
    0,
    v_agentii,
    'Broker CRUD Actualizat',
    'broker.' || txid_current() || '@crud.example',
    'administrator',
    false
)) THEN
        RAISE EXCEPTION 'FAIL brokeri UPDATE: id inexistent';
    END IF;

    -- UPDATE clienti: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.clienti_update(
    v_clienti,
    v_agentii,
    v_brokeri,
    'Client CRUD Actualizat',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Brasov',
    'client'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'broker_id', v_brokeri,
            'nume', 'Client CRUD Actualizat',
            'tip', 'persoana',
            'email', 'client.' || txid_current() || '@crud.example',
            'oras', 'Brasov',
            'stare', 'client')) THEN
        RAISE EXCEPTION 'FAIL clienti update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.clienti WHERE id = v_clienti;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'broker_id', v_brokeri,
            'nume', 'Client CRUD Actualizat',
            'tip', 'persoana',
            'email', 'client.' || txid_current() || '@crud.example',
            'oras', 'Brasov',
            'stare', 'client')) THEN
        RAISE EXCEPTION 'FAIL clienti update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.clienti_update(
    0,
    v_agentii,
    v_brokeri,
    'Client CRUD Actualizat',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Brasov',
    'client'
)) THEN
        RAISE EXCEPTION 'FAIL clienti UPDATE: id inexistent';
    END IF;

    -- UPDATE asiguratori: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.asiguratori_update(
    v_asiguratori,
    'Asigurator CRUD Actualizat ' || txid_current(),
    'CRUD-AS-' || txid_current(),
    'asigurator.' || txid_current() || '@crud.example',
    false
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Asigurator CRUD Actualizat ' || txid_current(),
            'cod_demo', 'CRUD-AS-' || txid_current(),
            'email', 'asigurator.' || txid_current() || '@crud.example',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL asiguratori update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.asiguratori WHERE id = v_asiguratori;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'denumire', 'Asigurator CRUD Actualizat ' || txid_current(),
            'cod_demo', 'CRUD-AS-' || txid_current(),
            'email', 'asigurator.' || txid_current() || '@crud.example',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL asiguratori update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.asiguratori_update(
    0,
    'Asigurator CRUD Actualizat ' || txid_current(),
    'CRUD-AS-' || txid_current(),
    'asigurator.' || txid_current() || '@crud.example',
    false
)) THEN
        RAISE EXCEPTION 'FAIL asiguratori UPDATE: id inexistent';
    END IF;

    -- UPDATE produse_asigurare: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.produse_asigurare_update(
    v_produse_asigurare,
    v_asiguratori,
    'CRUD-PROD-' || txid_current(),
    'RCA CRUD Actualizat',
    'RCA',
    'Descriere actualizata prin CRUD.',
    false
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'asigurator_id', v_asiguratori,
            'cod', 'CRUD-PROD-' || txid_current(),
            'denumire', 'RCA CRUD Actualizat',
            'categorie', 'RCA',
            'descriere', 'Descriere actualizata prin CRUD.',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.produse_asigurare WHERE id = v_produse_asigurare;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'asigurator_id', v_asiguratori,
            'cod', 'CRUD-PROD-' || txid_current(),
            'denumire', 'RCA CRUD Actualizat',
            'categorie', 'RCA',
            'descriere', 'Descriere actualizata prin CRUD.',
            'activ', false)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.produse_asigurare_update(
    0,
    v_asiguratori,
    'CRUD-PROD-' || txid_current(),
    'RCA CRUD Actualizat',
    'RCA',
    'Descriere actualizata prin CRUD.',
    false
)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare UPDATE: id inexistent';
    END IF;

    -- UPDATE oportunitati: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.oportunitati_update(
    v_oportunitati,
    v_agentii,
    v_clienti,
    v_brokeri,
    'Oportunitate CRUD Actualizata',
    'RCA',
    'castigat',
    'telefon',
    1600.00,
    'RON',
    TIMESTAMPTZ '2026-11-15 12:00:00+02'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'client_id', v_clienti,
            'broker_id', v_brokeri,
            'titlu', 'Oportunitate CRUD Actualizata',
            'categorie', 'RCA',
            'etapa', 'castigat',
            'sursa', 'telefon',
            'valoare_estimata', 1600.00,
            'moneda', 'RON',
            'creat_la', TIMESTAMPTZ '2026-11-15 09:00:00+02',
            'inchis_la', TIMESTAMPTZ '2026-11-15 12:00:00+02')) THEN
        RAISE EXCEPTION 'FAIL oportunitati update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.oportunitati WHERE id = v_oportunitati;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'client_id', v_clienti,
            'broker_id', v_brokeri,
            'titlu', 'Oportunitate CRUD Actualizata',
            'categorie', 'RCA',
            'etapa', 'castigat',
            'sursa', 'telefon',
            'valoare_estimata', 1600.00,
            'moneda', 'RON',
            'creat_la', TIMESTAMPTZ '2026-11-15 09:00:00+02',
            'inchis_la', TIMESTAMPTZ '2026-11-15 12:00:00+02')) THEN
        RAISE EXCEPTION 'FAIL oportunitati update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.oportunitati_update(
    0,
    v_agentii,
    v_clienti,
    v_brokeri,
    'Oportunitate CRUD Actualizata',
    'RCA',
    'castigat',
    'telefon',
    1600.00,
    'RON',
    TIMESTAMPTZ '2026-11-15 12:00:00+02'
)) THEN
        RAISE EXCEPTION 'FAIL oportunitati UPDATE: id inexistent';
    END IF;

    -- UPDATE oferte: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.oferte_update(
    v_oferte,
    v_oportunitati,
    v_produse_asigurare,
    'RCA',
    'CRUD-OF-' || txid_current(),
    1600.00,
    6500000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-12-05'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'produs_id', v_produse_asigurare,
            'categorie', 'RCA',
            'numar', 'CRUD-OF-' || txid_current(),
            'prima_anuala', 1600.00,
            'suma_asigurata', 6500000.00,
            'moneda', 'RON',
            'stare', 'acceptata',
            'emisa_la', DATE '2026-11-15',
            'valabila_pana', DATE '2026-12-05')) THEN
        RAISE EXCEPTION 'FAIL oferte update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.oferte WHERE id = v_oferte;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'produs_id', v_produse_asigurare,
            'categorie', 'RCA',
            'numar', 'CRUD-OF-' || txid_current(),
            'prima_anuala', 1600.00,
            'suma_asigurata', 6500000.00,
            'moneda', 'RON',
            'stare', 'acceptata',
            'emisa_la', DATE '2026-11-15',
            'valabila_pana', DATE '2026-12-05')) THEN
        RAISE EXCEPTION 'FAIL oferte update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.oferte_update(
    0,
    v_oportunitati,
    v_produse_asigurare,
    'RCA',
    'CRUD-OF-' || txid_current(),
    1600.00,
    6500000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-12-05'
)) THEN
        RAISE EXCEPTION 'FAIL oferte UPDATE: id inexistent';
    END IF;

    -- UPDATE polite: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.polite_update(
    v_polite,
    v_oferte,
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2027-11-16',
    'activa',
    12.50,
    DATE '2026-11-15'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oferta_id', v_oferte,
            'numar', 'CRUD-POL-' || txid_current(),
            'inceput_la', DATE '2026-11-16',
            'sfarsit_la', DATE '2027-11-16',
            'stare', 'activa',
            'comision_procente', 12.50,
            'emisa_la', DATE '2026-11-15')) THEN
        RAISE EXCEPTION 'FAIL polite update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.polite WHERE id = v_polite;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oferta_id', v_oferte,
            'numar', 'CRUD-POL-' || txid_current(),
            'inceput_la', DATE '2026-11-16',
            'sfarsit_la', DATE '2027-11-16',
            'stare', 'activa',
            'comision_procente', 12.50,
            'emisa_la', DATE '2026-11-15')) THEN
        RAISE EXCEPTION 'FAIL polite update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.polite_update(
    0,
    v_oferte,
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2027-11-16',
    'activa',
    12.50,
    DATE '2026-11-15'
)) THEN
        RAISE EXCEPTION 'FAIL polite UPDATE: id inexistent';
    END IF;

    -- UPDATE activitati: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.activitati_update(
    v_activitati,
    v_oportunitati,
    'email',
    'Confirmare polita CRUD',
    'Clientul a fost informat.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    TIMESTAMPTZ '2026-11-16 10:15:00+02',
    'finalizata'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'tip', 'email',
            'subiect', 'Confirmare polita CRUD',
            'descriere', 'Clientul a fost informat.',
            'scadenta_la', TIMESTAMPTZ '2026-11-16 10:00:00+02',
            'finalizata_la', TIMESTAMPTZ '2026-11-16 10:15:00+02',
            'stare', 'finalizata')) THEN
        RAISE EXCEPTION 'FAIL activitati update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.activitati WHERE id = v_activitati;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'tip', 'email',
            'subiect', 'Confirmare polita CRUD',
            'descriere', 'Clientul a fost informat.',
            'scadenta_la', TIMESTAMPTZ '2026-11-16 10:00:00+02',
            'finalizata_la', TIMESTAMPTZ '2026-11-16 10:15:00+02',
            'stare', 'finalizata')) THEN
        RAISE EXCEPTION 'FAIL activitati update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.activitati_update(
    0,
    v_oportunitati,
    'email',
    'Confirmare polita CRUD',
    'Clientul a fost informat.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    TIMESTAMPTZ '2026-11-16 10:15:00+02',
    'finalizata'
)) THEN
        RAISE EXCEPTION 'FAIL activitati UPDATE: id inexistent';
    END IF;

    -- UPDATE plati: exact un rand returnat, verificat apoi direct in tabel.
    SELECT * INTO STRICT r FROM broker_crm.plati_update(
    v_plati,
    v_polite,
    1,
    1600.00,
    'RON',
    DATE '2026-11-16',
    DATE '2026-11-16',
    'transfer',
    'CRUD-TXN-' || txid_current(),
    'platita'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'polita_id', v_polite,
            'numar_rata', 1,
            'suma', 1600.00,
            'moneda', 'RON',
            'scadenta_la', DATE '2026-11-16',
            'platita_la', DATE '2026-11-16',
            'metoda', 'transfer',
            'referinta_demo', 'CRUD-TXN-' || txid_current(),
            'stare', 'platita')) THEN
        RAISE EXCEPTION 'FAIL plati update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.plati WHERE id = v_plati;
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'polita_id', v_polite,
            'numar_rata', 1,
            'suma', 1600.00,
            'moneda', 'RON',
            'scadenta_la', DATE '2026-11-16',
            'platita_la', DATE '2026-11-16',
            'metoda', 'transfer',
            'referinta_demo', 'CRUD-TXN-' || txid_current(),
            'stare', 'platita')) THEN
        RAISE EXCEPTION 'FAIL plati update: valori diferite de cele cerute';
    END IF;

    IF EXISTS (SELECT 1 FROM broker_crm.plati_update(
    0,
    v_polite,
    1,
    1600.00,
    'RON',
    DATE '2026-11-16',
    DATE '2026-11-16',
    'transfer',
    'CRUD-TXN-' || txid_current(),
    'platita'
)) THEN
        RAISE EXCEPTION 'FAIL plati UPDATE: id inexistent';
    END IF;

    -- 10 cazuri negative prin functii (fara ocolirea cheilor/constrangerilor).

    BEGIN
        PERFORM * FROM broker_crm.plati_update(
    v_plati,
    v_polite,
    1,
    -1,
    'RON',
    DATE '2026-11-16',
    DATE '2026-11-16',
    'transfer',
    'CRUD-TXN-' || txid_current(),
    'platita'
);
        RAISE EXCEPTION 'FAIL: plata cu suma negativa nu a fost respins';
    EXCEPTION WHEN check_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.plati_update(
    v_plati,
    v_polite,
    1,
    1600.00,
    'RON',
    DATE '2026-11-16',
    DATE '2026-11-16',
    NULL,
    'CRUD-TXN-' || txid_current(),
    'platita'
);
        RAISE EXCEPTION 'FAIL: plata achitata fara metoda nu a fost respins';
    EXCEPTION WHEN check_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.clienti_update(
    v_clienti,
    v_agentii,
    0,
    'Client CRUD Actualizat',
    'persoana',
    'client.' || txid_current() || '@crud.example',
    'Brasov',
    'client'
);
        RAISE EXCEPTION 'FAIL: client cu broker inexistent nu a fost respins';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.oferte_update(
    v_oferte,
    v_oportunitati,
    v_produse_asigurare,
    'CASCO',
    'CRUD-OF-' || txid_current(),
    1600.00,
    6500000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-12-05'
);
        RAISE EXCEPTION 'FAIL: produs din alta categorie nu a fost respins';
    EXCEPTION WHEN foreign_key_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.oferte_create(
    v_oportunitati,
    v_produse_asigurare,
    'RCA',
    'CRUD-OF2-' || txid_current(),
    1500.00,
    6000000.00,
    'RON',
    'acceptata',
    DATE '2026-11-15',
    DATE '2026-11-30'
);
        RAISE EXCEPTION 'FAIL: a doua oferta acceptata nu a fost respins';
    EXCEPTION WHEN unique_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.agentii_delete(v_agentii);
        RAISE EXCEPTION 'FAIL: stergere agentie cu dependente nu a fost respins';
    EXCEPTION WHEN foreign_key_violation OR restrict_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.polite_delete(v_polite);
        RAISE EXCEPTION 'FAIL: stergere polita cu plati nu a fost respins';
    EXCEPTION WHEN foreign_key_violation OR restrict_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.activitati_update(
    v_activitati,
    v_oportunitati,
    'email',
    'Confirmare polita CRUD',
    'Clientul a fost informat.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    NULL,
    'finalizata'
);
        RAISE EXCEPTION 'FAIL: activitate finalizata fara data nu a fost respins';
    EXCEPTION WHEN check_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.polite_update(
    v_polite,
    v_oferte,
    'CRUD-POL-' || txid_current(),
    DATE '2026-11-16',
    DATE '2026-11-16',
    'activa',
    12.50,
    DATE '2026-11-15'
);
        RAISE EXCEPTION 'FAIL: perioada polita nula nu a fost respins';
    EXCEPTION WHEN check_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    BEGIN
        PERFORM * FROM broker_crm.oportunitati_update(
    v_oportunitati,
    v_agentii,
    v_clienti,
    v_brokeri,
    'Oportunitate CRUD Actualizata',
    'RCA',
    'castigat',
    'telefon',
    1600.00,
    'RON',
    NULL
);
        RAISE EXCEPTION 'FAIL: oportunitate inchisa fara data nu a fost respins';
    EXCEPTION WHEN check_violation THEN
        NULL; -- Doar eroarea asteptata este acceptata; orice alta eroare opreste testul.
    END;

    -- NULL trebuie sa stearga valoarea existenta, nu sa fie ignorat cu COALESCE.

    SELECT * INTO STRICT r FROM broker_crm.plati_update(
    v_plati,
    v_polite,
    1,
    1600.00,
    'RON',
    DATE '2026-11-16',
    NULL,
    NULL,
    NULL,
    'planificata'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'polita_id', v_polite,
            'numar_rata', 1,
            'suma', 1600.00,
            'moneda', 'RON',
            'scadenta_la', DATE '2026-11-16',
            'platita_la', NULL,
            'metoda', NULL,
            'referinta_demo', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL plati update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.activitati_update(
    v_activitati,
    v_oportunitati,
    'email',
    'Confirmare polita CRUD',
    'Clientul a fost informat.',
    TIMESTAMPTZ '2026-11-16 10:00:00+02',
    NULL,
    'planificata'
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'oportunitate_id', v_oportunitati,
            'tip', 'email',
            'subiect', 'Confirmare polita CRUD',
            'descriere', 'Clientul a fost informat.',
            'scadenta_la', TIMESTAMPTZ '2026-11-16 10:00:00+02',
            'finalizata_la', NULL,
            'stare', 'planificata')) THEN
        RAISE EXCEPTION 'FAIL activitati update: valori diferite de cele cerute';
    END IF;

    SELECT * INTO STRICT r FROM broker_crm.oportunitati_update(
    v_oportunitati,
    v_agentii,
    v_clienti,
    v_brokeri,
    'Oportunitate CRUD Actualizata',
    'RCA',
    'nou',
    'telefon',
    1600.00,
    'RON',
    NULL
);
    IF NOT (to_jsonb(r) @> jsonb_build_object(
            'agentie_id', v_agentii,
            'client_id', v_clienti,
            'broker_id', v_brokeri,
            'titlu', 'Oportunitate CRUD Actualizata',
            'categorie', 'RCA',
            'etapa', 'nou',
            'sursa', 'telefon',
            'valoare_estimata', 1600.00,
            'moneda', 'RON',
            'creat_la', TIMESTAMPTZ '2026-11-15 09:00:00+02',
            'inchis_la', NULL)) THEN
        RAISE EXCEPTION 'FAIL oportunitati update: valori diferite de cele cerute';
    END IF;

    -- DELETE plati: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.plati_delete(v_plati);
    IF r.id <> v_plati OR EXISTS (SELECT 1 FROM broker_crm.plati WHERE id = v_plati) THEN
        RAISE EXCEPTION 'FAIL plati DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.plati_delete(v_plati)) THEN
        RAISE EXCEPTION 'FAIL plati DELETE: apel repetat';
    END IF;

    -- DELETE activitati: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.activitati_delete(v_activitati);
    IF r.id <> v_activitati OR EXISTS (SELECT 1 FROM broker_crm.activitati WHERE id = v_activitati) THEN
        RAISE EXCEPTION 'FAIL activitati DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.activitati_delete(v_activitati)) THEN
        RAISE EXCEPTION 'FAIL activitati DELETE: apel repetat';
    END IF;

    -- DELETE polite: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.polite_delete(v_polite);
    IF r.id <> v_polite OR EXISTS (SELECT 1 FROM broker_crm.polite WHERE id = v_polite) THEN
        RAISE EXCEPTION 'FAIL polite DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.polite_delete(v_polite)) THEN
        RAISE EXCEPTION 'FAIL polite DELETE: apel repetat';
    END IF;

    -- DELETE oferte: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.oferte_delete(v_oferte);
    IF r.id <> v_oferte OR EXISTS (SELECT 1 FROM broker_crm.oferte WHERE id = v_oferte) THEN
        RAISE EXCEPTION 'FAIL oferte DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oferte_delete(v_oferte)) THEN
        RAISE EXCEPTION 'FAIL oferte DELETE: apel repetat';
    END IF;

    -- DELETE oportunitati: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.oportunitati_delete(v_oportunitati);
    IF r.id <> v_oportunitati OR EXISTS (SELECT 1 FROM broker_crm.oportunitati WHERE id = v_oportunitati) THEN
        RAISE EXCEPTION 'FAIL oportunitati DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.oportunitati_delete(v_oportunitati)) THEN
        RAISE EXCEPTION 'FAIL oportunitati DELETE: apel repetat';
    END IF;

    -- DELETE produse_asigurare: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.produse_asigurare_delete(v_produse_asigurare);
    IF r.id <> v_produse_asigurare OR EXISTS (SELECT 1 FROM broker_crm.produse_asigurare WHERE id = v_produse_asigurare) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.produse_asigurare_delete(v_produse_asigurare)) THEN
        RAISE EXCEPTION 'FAIL produse_asigurare DELETE: apel repetat';
    END IF;

    -- DELETE asiguratori: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.asiguratori_delete(v_asiguratori);
    IF r.id <> v_asiguratori OR EXISTS (SELECT 1 FROM broker_crm.asiguratori WHERE id = v_asiguratori) THEN
        RAISE EXCEPTION 'FAIL asiguratori DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.asiguratori_delete(v_asiguratori)) THEN
        RAISE EXCEPTION 'FAIL asiguratori DELETE: apel repetat';
    END IF;

    -- DELETE clienti: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.clienti_delete(v_clienti);
    IF r.id <> v_clienti OR EXISTS (SELECT 1 FROM broker_crm.clienti WHERE id = v_clienti) THEN
        RAISE EXCEPTION 'FAIL clienti DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.clienti_delete(v_clienti)) THEN
        RAISE EXCEPTION 'FAIL clienti DELETE: apel repetat';
    END IF;

    -- DELETE brokeri: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.brokeri_delete(v_brokeri);
    IF r.id <> v_brokeri OR EXISTS (SELECT 1 FROM broker_crm.brokeri WHERE id = v_brokeri) THEN
        RAISE EXCEPTION 'FAIL brokeri DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.brokeri_delete(v_brokeri)) THEN
        RAISE EXCEPTION 'FAIL brokeri DELETE: apel repetat';
    END IF;

    -- DELETE agentii: exact un rand sters; al doilea apel nu gaseste nimic.
    SELECT * INTO STRICT r FROM broker_crm.agentii_delete(v_agentii);
    IF r.id <> v_agentii OR EXISTS (SELECT 1 FROM broker_crm.agentii WHERE id = v_agentii) THEN
        RAISE EXCEPTION 'FAIL agentii DELETE';
    END IF;
    IF EXISTS (SELECT 1 FROM broker_crm.agentii_delete(v_agentii)) THEN
        RAISE EXCEPTION 'FAIL agentii DELETE: apel repetat';
    END IF;

    -- Orice modificare colaterala a datelor existente face testul sa esueze.
    FOR v_table IN
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'broker_crm' AND table_type = 'BASE TABLE'
    LOOP
        EXECUTE format('SELECT coalesce(jsonb_agg(to_jsonb(t) ORDER BY t.id), ''[]''::jsonb) FROM broker_crm.%I AS t', v_table)
            INTO v_value;
        v_after := v_after || jsonb_build_object(v_table, v_value);
    END LOOP;
    IF v_before IS DISTINCT FROM v_after THEN
        RAISE EXCEPTION 'FAIL: datele existente au fost modificate';
    END IF;
    RAISE NOTICE 'PASS CRUD: 40 operatii, liste/cazuri id inexistent, 10 respingeri, NULL explicit; datele existente sunt identice.';
END;
$test$;
ROLLBACK;
