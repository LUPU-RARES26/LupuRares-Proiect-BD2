param(
    [ValidateSet('Setup','Start','Stop','Verify','Query','Status','InstallCrud','CrudDemo','VerifyCrud')]
    [string]$Action = 'Status'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$projectRoot = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Docker CLI nu este disponibil. Porneste Docker Desktop si redeschide terminalul.'
}

function Invoke-DockerSql {
    param([string]$Sql)
    # Parola este citita in container, fara afisare sau includere in argumentele locale.
    $psqlCommand = 'PGPASSWORD="$POSTGRES_PASSWORD" psql -X -h 127.0.0.1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1'
    $Sql | docker compose exec -T postgres sh -c $psqlCommand
    if ($LASTEXITCODE -ne 0) { throw "Executia SQL in Docker a esuat (cod $LASTEXITCODE)." }
}

$oldOutputEncoding = $OutputEncoding
Push-Location -LiteralPath $projectRoot
try {
    $OutputEncoding = New-Object Text.UTF8Encoding $false
    switch ($Action) {
        { $_ -in @('Setup','Start') } {
            docker compose up -d --wait
            if ($LASTEXITCODE -ne 0) { throw 'Pornirea containerului PostgreSQL a esuat.' }
            if ($Action -eq 'Setup') {
                Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\04_verificare.sql')))
                Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\08_profiluri_sarcini.sql')))
                Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\05_crud.sql')))
            }
        }
        'Verify' {
            Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\04_verificare.sql')))
        }
        'Query' {
            Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\03_interogari.sql')))
        }
        'InstallCrud' {
            Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\08_profiluri_sarcini.sql')))
                Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\05_crud.sql')))
        }
        'CrudDemo' {
            Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\06_demo_crud.sql')))
        }
        'VerifyCrud' {
            Invoke-DockerSql -Sql ([IO.File]::ReadAllText((Join-Path $projectRoot 'database\07_verificare_crud.sql')))
        }
        'Status' {
            docker compose ps
            if ($LASTEXITCODE -ne 0) { throw 'Citirea starii containerului a esuat.' }
            Invoke-DockerSql -Sql "SELECT current_database(), current_user; SELECT table_name FROM information_schema.tables WHERE table_schema='broker_crm' AND table_type='BASE TABLE' ORDER BY table_name;"
        }
        'Stop' {
            docker compose stop
            if ($LASTEXITCODE -ne 0) { throw 'Oprirea containerului a esuat.' }
        }
    }
} finally {
    $OutputEncoding = $oldOutputEncoding
    Pop-Location
}
