param(
    [ValidateSet('Setup','Start','Stop','Verify','Query','Status','InstallCrud','CrudDemo','VerifyCrud')]
    [string]$Action = 'Status'
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$projectRoot = Split-Path -Parent $PSScriptRoot
$configPath = Join-Path $projectRoot '.env'

if (-not (Test-Path -LiteralPath $configPath)) {
    if ($Action -ne 'Setup') { throw 'Ruleaza mai intai: .\scripts\postgres.ps1 Setup' }
    $randomBytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($randomBytes) } finally { $rng.Dispose() }
    $localPassword = [Convert]::ToBase64String($randomBytes).TrimEnd('=').Replace('+','-').Replace('/','_')
    $lines = @('POSTGRES_DB=broker_crm','POSTGRES_USER=broker_demo',
        "POSTGRES_PASSWORD=$localPassword",'POSTGRES_PORT=5433','DOCKER_POSTGRES_PORT=5434',
        'PG_BIN=C:/Program Files/PostgreSQL/18/bin')
    [IO.File]::WriteAllLines($configPath, $lines, (New-Object Text.UTF8Encoding $false))
}

$config = @{}
foreach ($line in [IO.File]::ReadAllLines($configPath)) {
    if ($line -match '^([A-Z_]+)=(.*)$') { $config[$Matches[1]] = $Matches[2] }
}
foreach ($key in @('POSTGRES_DB','POSTGRES_USER','POSTGRES_PASSWORD','POSTGRES_PORT','PG_BIN')) {
    if (-not $config.ContainsKey($key) -or -not $config[$key]) { throw "Lipseste $key din .env" }
}
if ($config.POSTGRES_DB -notmatch '^[a-z][a-z0-9_]*$' -or $config.POSTGRES_USER -notmatch '^[a-z][a-z0-9_]*$') {
    throw 'Numele bazei si utilizatorului trebuie sa fie identificatori SQL simpli.'
}
if ($config.POSTGRES_PORT -notmatch '^\d+$' -or [int]$config.POSTGRES_PORT -lt 1024 -or [int]$config.POSTGRES_PORT -gt 65535) {
    throw 'Port local invalid.'
}
$dataDirectory = if ($config.ContainsKey('LOCAL_PGDATA')) { $config.LOCAL_PGDATA } else { Join-Path $projectRoot '.local\postgres' }
$dataDirectory = [IO.Path]::GetFullPath($dataDirectory)
$dataParent = Split-Path -Parent $dataDirectory
$pgBin = $config.PG_BIN
$pgCtl = Join-Path $pgBin 'pg_ctl.exe'
$psql = Join-Path $pgBin 'psql.exe'
if (-not (Test-Path -LiteralPath $pgCtl)) { throw "PostgreSQL nu este disponibil in $pgBin" }
$connectArgs = @('-X','-w','-h','127.0.0.1','-p',$config.POSTGRES_PORT,'-U',$config.POSTGRES_USER,'-v','ON_ERROR_STOP=1')

function Invoke-Psql {
    param([string]$Database, [string[]]$SqlArgs)
    & $psql @connectArgs -d $Database @SqlArgs
    if ($LASTEXITCODE -ne 0) { throw "psql a esuat (cod $LASTEXITCODE)." }
}
function Start-ProjectDatabase {
    if (-not (Test-Path -LiteralPath (Join-Path $dataDirectory 'PG_VERSION'))) {
        throw 'Instanta nu este initializata. Ruleaza actiunea Setup.'
    }
    & $pgCtl -D $dataDirectory status *> $null
    if ($LASTEXITCODE -ne 0) {
        $serverOptions = '-h 127.0.0.1 -p ' + $config.POSTGRES_PORT
        & $pgCtl -D $dataDirectory -l (Join-Path $dataParent 'broker-crm-postgres.log') -o $serverOptions -w start
        if ($LASTEXITCODE -ne 0) { throw 'Pornirea PostgreSQL a esuat. Verifica portul si jurnalul.' }
    }
}

$oldPassword = [Environment]::GetEnvironmentVariable('PGPASSWORD','Process')
try {
    $env:PGPASSWORD = $config.POSTGRES_PASSWORD
    switch ($Action) {
        'Setup' {
            if (-not (Test-Path -LiteralPath (Join-Path $dataDirectory 'PG_VERSION'))) {
                New-Item -ItemType Directory -Path $dataParent -Force | Out-Null
                $passwordFile = Join-Path $dataParent ('.initdb-' + [guid]::NewGuid().ToString('N') + '.tmp')
                try {
                    [IO.File]::WriteAllText($passwordFile, $config.POSTGRES_PASSWORD, (New-Object Text.UTF8Encoding $false))
                    & (Join-Path $pgBin 'initdb.exe') -D $dataDirectory -U $config.POSTGRES_USER -A scram-sha-256 --encoding=UTF8 --no-locale --pwfile=$passwordFile
                    if ($LASTEXITCODE -ne 0) { throw 'Initializarea PostgreSQL a esuat.' }
                } finally {
                    if (Test-Path -LiteralPath $passwordFile) { Remove-Item -LiteralPath $passwordFile -Force }
                }
            }
            Start-ProjectDatabase
            $exists = Invoke-Psql -Database 'postgres' -SqlArgs @('-At','-c',"SELECT 1 FROM pg_database WHERE datname = '$($config.POSTGRES_DB)';")
            if ($exists -ne '1') {
                & (Join-Path $pgBin 'createdb.exe') -w -h 127.0.0.1 -p $config.POSTGRES_PORT -U $config.POSTGRES_USER $config.POSTGRES_DB
                if ($LASTEXITCODE -ne 0) { throw 'Crearea bazei a esuat.' }
            }
            $schemaExists = Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-At','-c',"SELECT 1 FROM pg_namespace WHERE nspname='broker_crm';")
            if ($schemaExists -ne '1') {
                Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\01_schema.sql'),'-f',(Join-Path $projectRoot 'database\02_fixtures.sql'))
            }
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\04_verificare.sql'))
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\08_profiluri_sarcini.sql'),'-f',(Join-Path $projectRoot 'database\05_crud.sql'))
            Write-Host "Baza pregatita: 127.0.0.1:$($config.POSTGRES_PORT) / $($config.POSTGRES_DB); utilizator $($config.POSTGRES_USER)."
            Write-Host 'Parola locala se afla in .env.'
        }
        'Start' { Start-ProjectDatabase; Write-Host 'PostgreSQL pornit.' }
        'Stop' {
            & $pgCtl -D $dataDirectory -m fast -w stop
            if ($LASTEXITCODE -ne 0) { throw 'Oprirea PostgreSQL a esuat.' }
        }
        'Verify' {
            Start-ProjectDatabase
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\04_verificare.sql'))
        }
        'Query' {
            Start-ProjectDatabase
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\03_interogari.sql'))
        }
        'InstallCrud' {
            Start-ProjectDatabase
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\08_profiluri_sarcini.sql'),'-f',(Join-Path $projectRoot 'database\05_crud.sql'))
        }
        'CrudDemo' {
            Start-ProjectDatabase
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\06_demo_crud.sql'))
        }
        'VerifyCrud' {
            Start-ProjectDatabase
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-f',(Join-Path $projectRoot 'database\07_verificare_crud.sql'))
        }
        'Status' {
            & $pgCtl -D $dataDirectory status
            if ($LASTEXITCODE -ne 0) { throw 'Instanta proiectului este oprita.' }
            Invoke-Psql -Database $config.POSTGRES_DB -SqlArgs @('-c',"SELECT table_name FROM information_schema.tables WHERE table_schema='broker_crm' AND table_type='BASE TABLE' ORDER BY table_name;")
        }
    }
} finally {
    [Environment]::SetEnvironmentVariable('PGPASSWORD', $oldPassword, 'Process')
}
