# Broker CRM — aplicația web

Adresa locală: **http://localhost:3000**. Aplicația folosește PostgreSQL din Docker și cele 40 de funcții din `database/05_crud.sql`. Cele 10 tabele, relațiile și fixture-urile existente sunt păstrate.

## Pornire

Cu Docker Desktop pornit, din directorul proiectului:

```powershell
docker compose up -d --build --wait
```

Deschideți http://localhost:3000. În VS Code se poate folosi **Terminal > Run Task > Site: pornire si actualizare**. Nu este necesară instalarea Node.js în Windows pentru rularea prin Docker.

```powershell
docker compose ps
docker compose logs --tail 50 web
docker compose stop web
```

Ultima comandă oprește doar site-ul. Volumul PostgreSQL păstrează datele. Pentru repornire sau după modificarea surselor, reluați comanda `up` de mai sus.

Pe un volum nou, schema, fixture-urile, extensia pentru sarcini și funcțiile CRUD se instalează automat. Serviciul temporar `migrate` aplică idempotent `08_profiluri_sarcini.sql` și `05_crud.sql` înaintea pornirii site-ului, inclusiv pe volumul existent. Starea `Exited (0)` a acestui serviciu înseamnă succes. Nu reexecutați schema sau fixture-urile peste baza existentă.

Portul poate fi schimbat prin `WEB_PORT` în `.env`; implicit este `3000`. Serverul PostgreSQL rămâne accesibil din Windows pe portul `5434`, iar site-ul îl accesează în rețeaua Docker la `postgres:5432`. Parola este transmisă numai serviciului backend prin configurația Docker; nu intră în fișierele JavaScript trimise browserului.

## Arhitectură

```text
Browser (React + Vite, în română)
          │ cereri HTTP JSON, aceeași origine
          ▼
Node.js + Express — serviciul Docker «web», port 3000
          │ validare + parametri SQL legați ($1, $2...)
          ▼
PostgreSQL — serviciul Docker «postgres»
          │ broker_crm.<tabel>_create/read/update/delete
          ▼
10 tabele existente + PK / FK / UNIQUE / CHECK
```

Nu există o bază separată în browser și nu sunt folosite date simulate pentru liste. Înregistrările sunt încărcate într-un snapshot consistent; după o scriere, site-ul reîncarcă datele. Catalogul de asigurători și produse este comun agențiilor.

| Director / fișier | Rol |
|---|---|
| `web/src/` | Dashboard, liste, formulare, rapoarte și stiluri responsive |
| `web/shared/entities.js` | Configurația celor 10 entități, etichete și câmpuri |
| `web/server/app.js` | Rutele HTTP și apelurile către funcțiile CRUD |
| `web/server/validation.js` | Validare și mesaje de eroare în română |
| `web/server/reports.js` | Cele șase rapoarte SQL parametrizate |
| `web/tests/` | Teste de validare și integrare API ↔ PostgreSQL |
| `web/design/` | Concepte vizuale, capturi finale și verificarea designului |
| `web/Dockerfile` | Construirea frontendului și rularea backendului ca utilizator fără privilegii de root |

## API

`<tabel>` trebuie să fie unul dintre cele 10 nume din schema SQL. Numele sunt validate printr-o listă explicită; valorile sunt transmise ca parametri, nu concatenate în SQL.

| Metodă și adresă | Rezultat |
|---|---|
| `GET /api/health` | Disponibilitatea bazei și numărul funcțiilor CRUD |
| `GET /api/profiles/client/<id>` | Profil cu toate datele clientului, din toate oportunitățile sale |
| `GET /api/profiles/lead/<id>` | Profil limitat la o singură oportunitate |
| `GET /api/tasks?broker=<id>&view=available` | Sarcinile disponibile ale agentului; `scheduled` pentru viitoare și `history` pentru finalizate/anulate |
| `GET /api/bootstrap` | Snapshotul celor 10 tabele pentru interfață |
| `GET /api/<tabel>` | Lista înregistrărilor |
| `GET /api/<tabel>/<id>` | O înregistrare; `404` dacă nu există |
| `POST /api/<tabel>` | Adăugare; `201` și înregistrarea creată |
| `PUT /api/<tabel>/<id>` | Modificare completă a câmpurilor editabile |
| `DELETE /api/<tabel>/<id>` | Ștergere protejată de relațiile existente |
| `GET /api/reports/<raport>` | Raport SQL, cu parametrii `agency`, `id` sau `date` unde se aplică |

Scrierile necesită antetul `X-CRM-Request: 1`. Interfața îl trimite automat. API-ul validează originea pentru scrieri, nu oferă CORS public, limitează dimensiunea cererilor și nu returnează parole sau detalii interne SQL în erori. În `PUT` se trimit toate câmpurile editabile; `id` și `creat_la` sunt păstrate. Pentru golirea unui câmp opțional se transmite `null`.

## Testare

Test de integrare fără Node.js instalat pe Windows:

```powershell
docker compose exec -T web node tests/api.integration.js
```

Alternativ: **Terminal > Run Task > Site: verificare integrare CRUD**. Testul creează propriile date temporare, verifică toate cele 40 de operații, erori, cele șase rapoarte și filtrarea pe agenție, apoi șterge numai datele pe care le-a creat. Compară toate valorile inițiale înainte și după. Rulați-l fără modificări concurente în baza demo. Secvențele IDENTITY pot avansa în timpul testelor.

Pentru dezvoltare sunt necesare Node.js 22.12+ și npm. Din `web/`:

```powershell
npm ci
npm test
npm run build
npm run test:api
```

`npm test` verifică inclusiv concordanța parametrilor API cu definițiile funcțiilor SQL. `npm run dev` pornește frontendul pe `http://127.0.0.1:5173`; API-ul de pe `3000` trebuie să fie pornit, de exemplu prin Docker. Pentru instalarea standard folosiți Docker.


## Profiluri și sarcini — actualizare 16 noiembrie 2026

Deschideți numele unui client din **Clienți** sau titlul unui lead din **Oportunități**. Profilul clientului are filele **Detalii**, **Polițe**, **Activități**, **Plăți** și **Oferte**, cu datele sale reunite. Profilul oportunității are numai **Detalii**, **Activități** și **Oferte**, filtrate pentru oportunitatea respectivă. Fila Oportunități nu mai apare în profilul clientului; Polițe și Plăți nu mai apar în profilul oportunității. Adresele vechi ale filelor eliminate afișează Detalii. Selectorii din formulare folosesc aceleași limite. Ofertele financiare se gestionează tot în profil, deoarece polițele continuă să depindă de oferte acceptate.

În meniul principal, **Sarcini** înlocuiește **Oferte**. Alegeți **Sarcinile agentului**, apoi **Sarcină nouă**. Completați subiectul, tipul (Programare, Trimite email/SMS, Reminder sau De făcut), agenția, agentul, momentul afișării, termenul-limită și descrierea. Clientul și leadul sunt opționali pentru o sarcină internă. Agenții și clienții asociați trebuie să aparțină aceleiași agenții.

- **Disponibile**: planificate, cu data afișării deja atinsă.
- **Programate**: planificate pentru o dată viitoare.
- **Istoric**: finalizate sau anulate.

Disponibilitatea este calculată de PostgreSQL cu `now()`, nu de ceasul browserului. Lista se reîncarcă automat la 30 de secunde și la revenirea în fereastră. Datetimes sunt stocate `timestamptz`; afișarea listelor este în Europe/Bucharest, iar câmpurile calendaristice se introduc în fusul local al browserului. Bifa de pe un rând finalizează sarcina; creionul permite și reatribuirea sau anularea. Tipurile vechi Apel/Email/Întâlnire/Sarcină rămân disponibile în Activități și pentru datele istorice.

Acesta este un selector de agent în aplicația demo locală, nu un sistem de autentificare. Tipul **Trimite email/SMS** descrie lucrul de efectuat și nu trimite automat mesaje.

Scrierile din profil trimit `profileKind=client|lead` și `profileId=<id>`. API-ul verifică apartenența înainte și după scriere într-o tranzacție; o schimbare către alt profil este anulată. Aceste filtre păstrează contextul formularului; nu reprezintă autorizare per utilizator.

## Modificări SQL pentru această extensie

Baza folosită și modificată: **broker_crm**, schema **broker_crm**, în Docker, port Windows **5434**.

- `activitati`: coloane noi `broker_id`, `client_id`, `agentie_id`, `vizibila_de_la`; agentul, agenția și data afișării sunt obligatorii. Leadul și clientul pot lipsi pentru sarcini interne. Cele 60 de activități existente au fost completate din oportunitățile lor.
- `activitati`: patru tipuri noi, chei străine pentru agent/client/lead, verificarea `vizibila_de_la <= scadenta_la`, verificarea că un lead are client și indexuri pentru profil și agenda agentului.
- `oportunitati`: numai constrângerea unică `(id, client_id, agentie_id)`, necesară cheii străine compuse. Datele oportunităților sunt păstrate.
- Funcțiile `activitati_create` și `activitati_update` primesc patru parametri suplimentari opționali. Apelurile SQL vechi, cu oportunitate, continuă să funcționeze.

Rămân **10 tabele și 40 de funcții CRUD**. Nu există tabel permanent nou și nu au fost adăugate trigger-e. `oferte`, `polite` și `plati` își păstrează structura și datele. Instanțele locale 5432/5433 și MongoDB nu au fost modificate. Copia de siguranță anterioară migrării este `backups/broker-before-profiles-tasks-2026-11-16.dump`.

Pentru instalare SQL manuală de la zero: **01 → 02 → 08 → 05**, apoi 04/06/07 pentru verificări și 03 pentru rapoarte. Pentru o bază existentă: **08 → 05**. Diagramele exportate anterior descriu etapa 1; extensia curentă a relațiilor este definită în 08.
