# Broker CRM — specificatia interfetei

Referinte: `dashboard-concept.png` (1488 × 1056) si `client-form-concept.png` (1488 × 1056), generate pentru acest proiect. Directia este folosita pentru implementare fara o etapa separata de aprobare.

- Sidebar alb, 270 px la desktop; spatiu principal gri rece `#f7f8fb`; suprafete albe, text `#171b2e`, secundar `#667085`, borduri `#e3e6ef`, accent violet `#6850ca`, selectie `#eeebfc`.
- Font Inter / system sans; titluri 36 px, sectiuni 23 px, continut si controale 14–16 px, etichete 12 px. Iconografie Lucide, contur 1.7–1.8 px.
- Bara superioara 64 px; margini principale 28–32 px; panouri 12 px, campuri 7 px; spatiere 8/12/16/24/32 px. Fara imagini decorative sau gradiente.
- Dashboard: titlu si Client nou; banda cu 4 indicatori; parcurs oportunitati si agenda; tabel de polite.
- Navigatie: Prezentare generala, Clienti, Oportunitati, Oferte, Polite, Activitati, Plati, Rapoarte; apoi Agentii, Brokeri, Asiguratori, Produse.
- Liste: cautare, filtru de stare, numar rezultate, tabel, paginare, detalii, modificare, stergere. Formular in drawer lateral cu subsol fix si dialog separat pentru confirmarea stergerii.
- Pe mobil: navigatie pliabila, indicatori pe doua coloane, module verticale, tabele cu scroll in propria zona, formular pe latimea ecranului. Respecta preferinta pentru miscare redusa.

Textele de pe dashboard urmeaza conceptul. Valorile, numele, etapele si datele se citesc exclusiv din PostgreSQL; exemplele desenate de model care nu coincid cu fixture-urile sunt inlocuite cu datele reale. Filtrele, starile goale, erorile, formularele celorlalte tabele si rapoartele extind acelasi sistem vizual pentru functionalitatea ceruta.

Componente: AppShell, Dashboard, EntityPage, RecordDrawer, ConfirmDelete, Reports, DataTable, StatusBadge. Modelul tabelelor si campurilor este comun interfetei si API-ului. API-ul apeleaza cele 40 de functii CRUD existente.

## Extensie aprobată prin cerința utilizatorului: profiluri și sarcini

Structura de navigare este acum Clienți / Oportunități / Sarcini / Rapoarte, urmată de administrare. Ofertele financiare și cele trei colecții asociate sunt în profil. Dashboardul arată rezumate și acces la profiluri, iar noul ecran Sarcini reutilizează tabelele, filtrele și drawer-ul existente. Profilurile adaugă file cu numărul de înregistrări; Sarcini adaugă selectorul agentului și Disponibile/Programate/Istoric. Nicio imagine nouă nu este necesară pentru această extindere funcțională a sistemului existent.
