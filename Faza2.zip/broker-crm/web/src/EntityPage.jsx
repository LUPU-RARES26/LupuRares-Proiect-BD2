import React, { useState, useEffect } from 'react';
import { Plus, Search, Pencil, Trash2 } from 'lucide-react';
import { entities, labels } from '../shared/entities.js';
import { scopeRows, fieldText, normalize, recordName } from './lib.js';
import { PageHeading, DataTable, StatusBadge, Pagination } from './components.jsx';

export function EntityPage({ entity, data, agency, initialFilter = '', open, remove, rowsOverride, embedded = false }) {
  const config = entities[entity];
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState(initialFilter);
  const [page, setPage] = useState(1);
  const status = config.fields.find(f => ['stare', 'etapa', 'activ'].includes(f.key));
  const rows = (rowsOverride || scopeRows(data, entity, agency)).filter(row => (!filter || String(row[status?.key]) === filter) && (!search || config.fields.some(f => normalize(fieldText(f, row[f.key], data)).includes(normalize(search)))));
  useEffect(() => { setPage(1); }, [search, filter, agency]);
  useEffect(() => { if (page > Math.max(1, Math.ceil(rows.length / 12))) setPage(Math.max(1, Math.ceil(rows.length / 12))); }, [rows.length, page]);
  const columns = config.columns.map(key => {
    const field = config.fields.find(f => f.key === key);
    return { key, label: key === config.primary ? ({ clienti: 'Client', brokeri: 'Broker', agentii: 'Agenție', oferte: 'Ofertă', polite: 'Poliță', produse_asigurare: 'Produs', asiguratori: 'Asigurător' }[entity] || field.label) : field.label,
      render: row => (key === config.primary || (!config.columns.includes(config.primary) && key === config.columns[0])) ? <div className="primary-cell"><button className="record-link" onClick={() => open(entity, 'view', row)}>{fieldText(field, row[key], data)}</button>{entity === 'clienti' && <span>{row.email}</span>}</div> : ['stare', 'etapa', 'activ'].includes(key) ? <StatusBadge value={row[key]} /> : fieldText(field, row[key], data),
    };
  });
  columns.push({ key: 'actions', label: 'Acțiuni', render: row => <div className="row-actions"><button className="icon-button" aria-label={`Modifică ${recordName(entity, row)}`} title="Modifică" onClick={() => open(entity, 'edit', row)}><Pencil size={17} /></button><button className="icon-button danger-quiet" aria-label={`Șterge ${recordName(entity, row)}`} title="Șterge" onClick={() => remove(entity, row)}><Trash2 size={17} /></button></div> });
  return <>
    {embedded ? <div className="panel-heading profile-section-heading"><h2>{config.title}</h2><button className="button primary" onClick={() => open(entity, 'create')}><Plus size={18} />{config.createTitle}</button></div> : <PageHeading title={config.title} description={config.description}><button className="button primary" onClick={() => open(entity, 'create')}><Plus size={20} />{config.createTitle}</button></PageHeading>}
    <div className="list-toolbar"><div className="search-input"><Search size={19} /><input aria-label="Caută în înregistrări" placeholder={entity === 'clienti' ? 'Caută după nume, email sau oraș' : `Caută în ${config.title.toLowerCase()}`} value={search} onChange={e => setSearch(e.target.value)} /></div>{status && <select aria-label="Filtrează după stare" value={filter} onChange={e => setFilter(e.target.value)}><option value="">{status.key === 'etapa' ? 'Toate etapele' : 'Toate stările'}</option>{(status.choices || [true, false]).map(value => <option key={String(value)} value={String(value)}>{labels[value] || value}</option>)}</select>}<span className="result-count">{rows.length} rezultate</span></div>
    <section className="panel entity-table"><DataTable rows={rows.slice((page - 1) * 12, page * 12)} columns={columns} /><Pagination total={rows.length} page={page} onPage={setPage} /></section>
    {['asiguratori', 'produse_asigurare'].includes(entity) && <p className="list-note">Catalog comun tuturor agențiilor.</p>}
  </>;
}
