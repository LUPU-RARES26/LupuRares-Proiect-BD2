import React from 'react';
import { Plus, ArrowUpRight } from 'lucide-react';
import { stages, labels } from '../shared/entities.js';
import { scopeRows, findRecord } from './lib.js';
import { Icon, PageHeading, StatusBadge, DataTable } from './components.jsx';

export function Dashboard({ data, agency, navigate, open }) {
  const clients = scopeRows(data, 'clienti', agency), policies = scopeRows(data, 'polite', agency);
  const opportunities = scopeRows(data, 'oportunitati', agency), payments = scopeRows(data, 'plati', agency);
  const planned = scopeRows(data, 'activitati', agency).filter(a => a.stare === 'planificata');
  const metrics = [
    ['Clienți', clients.length, 'UsersRound', 'clienti'],
    ['Polițe active', policies.filter(p => p.stare === 'activa').length, 'Shield', 'clienti'],
    ['Oportunități deschise', opportunities.filter(o => !['castigat', 'pierdut'].includes(o.etapa)).length, 'Target', 'oportunitati'],
    ['Rate planificate', payments.filter(p => p.stare === 'planificata').length, 'CalendarDays', 'clienti'],
  ];
  const counts = stages.map(stage => opportunities.filter(o => o.etapa === stage).length), max = Math.max(1, ...counts);
  return <>
    <PageHeading title="Prezentare generală" description="Clienții, oportunitățile și pașii următori ai echipei."><button className="button primary" onClick={() => open('clienti', 'create')}><Plus size={20} />Client nou</button></PageHeading>
    <div className="metrics-band">{metrics.map(([label, value, icon, route]) => <button className="metric" key={label} onClick={() => navigate(route)}><span className="icon-tile"><Icon name={icon} size={27} /></span><span><span className="metric-label">{label}</span><strong>{value}</strong></span></button>)}</div>
    <div className="dashboard-grid">
      <section className="panel pipeline"><h2>Parcursul oportunităților</h2><div className="stage-list">{stages.map((stage, i) => <button key={stage} onClick={() => navigate('oportunitati', stage)} className="stage-row"><span>{labels[stage]}</span><span className="stage-track"><span style={{ width: `${counts[i] / max * 90}%` }} className={stage === 'castigat' ? 'won' : ''} /></span><strong>{counts[i]}</strong></button>)}</div></section>
      <section className="panel agenda"><h2>Pașii următori ai echipei</h2><div className="task-summary"><strong>{planned.length}</strong><span>activități și sarcini în așteptare</span></div><p className="section-copy">Alege un agent pentru a vedea sarcinile sale disponibile, programările viitoare și istoricul.</p><button className="button secondary" onClick={() => navigate('sarcini')}>Deschide Sarcini<ArrowUpRight size={17} /></button></section>
    </div>
    <section className="panel portfolio"><div className="panel-heading"><h2>Profilurile clienților</h2><button className="text-button" onClick={() => navigate('clienti')}>Vezi toți<ArrowUpRight size={16} /></button></div><DataTable rows={clients.slice(0, 4)} columns={[
      { key: 'nume', label: 'Client', render: row => <button className="record-link" onClick={() => open('clienti', 'view', row)}>{row.nume}</button> },
      { key: 'oras', label: 'Oraș' }, { key: 'broker_id', label: 'Agent', render: row => findRecord(data, 'brokeri', row.broker_id)?.nume },
      { key: 'stare', label: 'Stare', render: row => <StatusBadge value={row.stare} /> },
    ]} /><p className="list-note">Deschide un profil pentru polițele, activitățile și plățile sale.</p></section>
  </>;
}
