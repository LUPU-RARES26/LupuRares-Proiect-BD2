import React, { useEffect, useState } from 'react';
import { Plus, Search, Pencil, Trash2, Check, ArrowUpRight } from 'lucide-react';
import { entities, labels, taskTypes } from '../shared/entities.js';
import { api, dateText, findRecord, normalize, scopeRows } from './lib.js';
import { PageHeading, DataTable, Pagination, StatusBadge, ErrorBox } from './components.jsx';

export function TasksPage({ data, agency, open, remove, onSaved, navigate }) {
  const agents = scopeRows(data, 'brokeri', agency);
  const [selected, setSelected] = useState(() => localStorage.getItem('crm-task-agent') || '');
  const agent = agents.some(a => String(a.id) === selected) ? selected : String(agents.find(a => a.activ)?.id || agents[0]?.id || '');
  const [view, setView] = useState('available'), [type, setType] = useState(''), [search, setSearch] = useState(''), [page, setPage] = useState(1);
  const [result, setResult] = useState(null), [error, setError] = useState(null), [tick, setTick] = useState(0), [busy, setBusy] = useState('');
  const key = `${agent}-${view}-${agency}`;
  useEffect(() => { if (agent) localStorage.setItem('crm-task-agent', agent); }, [agent]);
  useEffect(() => { const timer = setInterval(() => setTick(t => t + 1), 30000); const focus = () => setTick(t => t + 1); window.addEventListener('focus', focus); return () => { clearInterval(timer); window.removeEventListener('focus', focus); }; }, []);
  useEffect(() => {
    if (!agent) return;
    const controller = new AbortController(); setError(null);
    api(`/tasks?broker=${agent}&view=${view}${agency ? `&agency=${agency}` : ''}`, { signal: controller.signal }).then(value => setResult({ key, rows: value.rows })).catch(e => { if (e.name !== 'AbortError') setError(e); });
    return () => controller.abort();
  }, [key, tick, data]);
  useEffect(() => { setPage(1); }, [key, type, search]);
  const rows = (result?.key === key ? result.rows : []).filter(row => (!type || row.tip === type) && (!search || normalize(`${row.subiect} ${row.descriere} ${findRecord(data, 'clienti', row.client_id)?.nume || ''}`).includes(normalize(search))));
  useEffect(() => { if (page > Math.max(1, Math.ceil(rows.length / 12))) setPage(Math.max(1, Math.ceil(rows.length / 12))); }, [rows.length, page]);
  async function complete(row) {
    setBusy(row.id); setError(null);
    try {
      const body = Object.fromEntries(entities.activitati.fields.map(f => [f.key, row[f.key]]));
      await api(`/activitati/${row.id}`, { method: 'PUT', body: JSON.stringify({ ...body, stare: 'finalizata', finalizata_la: new Date().toISOString() }) });
      onSaved('Sarcina a fost finalizată.');
    } catch (e) { setError(e); } finally { setBusy(''); }
  }
  function edit(mode, row) { open('activitati', mode, row, { task: true, initialValues: { broker_id: agent, agentie_id: findRecord(data, 'brokeri', agent)?.agentie_id || '' } }); }
  const columns = [
    { key: 'subiect', label: 'Sarcină', render: row => <div className="primary-cell"><button className="record-link" onClick={() => edit('view', row)}>{row.subiect}</button><span className="task-description">{row.descriere}</span></div> },
    { key: 'tip', label: 'Tip', render: row => labels[row.tip] },
    { key: 'client', label: 'Profil asociat', render: row => row.client_id ? <button className="text-button" onClick={() => navigate(`profil/${row.oportunitate_id ? 'lead' : 'client'}/${row.oportunitate_id || row.client_id}/activitati`)}>{findRecord(data, 'clienti', row.client_id)?.nume}<ArrowUpRight size={14} /></button> : 'Sarcină internă' },
    { key: 'vizibila_de_la', label: 'Apare la', render: row => dateText(row.vizibila_de_la, true) },
    { key: 'scadenta_la', label: 'Termen-limită', render: row => <span className={row.stare === 'planificata' && Date.parse(row.scadenta_la) < Date.now() ? 'overdue' : ''}>{dateText(row.scadenta_la, true)}</span> },
    { key: 'stare', label: 'Stare', render: row => <StatusBadge value={row.stare} /> },
    { key: 'actions', label: 'Acțiuni', render: row => <div className="row-actions">{row.stare === 'planificata' && <button className="icon-button" disabled={Boolean(busy)} aria-label={`Finalizează ${row.subiect}`} title="Finalizează sarcina" onClick={() => complete(row)}><Check size={18} /></button>}<button className="icon-button" aria-label={`Modifică ${row.subiect}`} title="Modifică" onClick={() => edit('edit', row)}><Pencil size={17} /></button><button className="icon-button danger-quiet" aria-label={`Șterge ${row.subiect}`} title="Șterge" onClick={() => remove('activitati', row)}><Trash2 size={17} /></button></div> },
  ];
  return <>
    <PageHeading title="Sarcini" description="Fiecare agent, cu pașii următori și termenele sale."><button className="button primary" disabled={!agent} onClick={() => edit('create')}><Plus size={19} />Sarcină nouă</button></PageHeading>
    <div className="task-agent"><label htmlFor="task-agent">Sarcinile agentului</label><select id="task-agent" value={agent} onChange={e => setSelected(e.target.value)}>{!agents.length && <option value="">Nu există agenți</option>}{agents.map(a => <option key={a.id} value={a.id}>{a.nume}{!a.activ ? ' (inactiv)' : ''}</option>)}</select><span>Data și ora sunt afișate în fusul Europe/Bucharest.</span></div>
    <nav className="section-tabs" aria-label="Liste de sarcini">{[['available', 'Disponibile'], ['scheduled', 'Programate'], ['history', 'Istoric']].map(([value, label]) => <button key={value} className={view === value ? 'selected' : ''} aria-current={view === value ? 'page' : undefined} onClick={() => setView(value)}>{label}</button>)}</nav>
    <p className="list-note">{view === 'available' ? 'Sarcinile apar aici la momentul ales. Lista se actualizează automat la 30 de secunde.' : view === 'scheduled' ? 'Sarcini pregătite pentru mai târziu; vor trece automat în Disponibile la data afișării.' : 'Sarcinile finalizate și anulate ale agentului selectat.'}</p>
    <ErrorBox error={error} />
    <div className="list-toolbar"><div className="search-input"><Search size={18} /><input aria-label="Caută sarcini" placeholder="Caută după titlu, descriere sau client" value={search} onChange={e => setSearch(e.target.value)} /></div><select aria-label="Tipul sarcinii" value={type} onChange={e => setType(e.target.value)}><option value="">Toate tipurile</option>{taskTypes.map(t => <option key={t} value={t}>{labels[t]}</option>)}</select><span className="result-count">{rows.length} sarcini</span></div>
    {agent && result?.key !== key && !error ? <p role="status">Se încarcă sarcinile…</p> : <section className="panel entity-table tasks-table"><DataTable columns={columns} rows={rows.slice((page - 1) * 12, page * 12)} /><Pagination total={rows.length} page={page} onPage={setPage} /></section>}
  </>;
}
