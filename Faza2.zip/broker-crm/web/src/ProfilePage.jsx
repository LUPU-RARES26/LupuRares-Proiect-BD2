import React, { useEffect, useState } from 'react';
import { ArrowLeft, Pencil, ArrowUpRight } from 'lucide-react';
import { entities } from '../shared/entities.js';
import { api, fieldText, findRecord } from './lib.js';
import { ErrorBox, PageHeading, StatusBadge } from './components.jsx';
import { EntityPage } from './EntityPage.jsx';

export function ProfilePage({ kind, id, tab = 'detalii', data, open, remove, navigate }) {
  const [profile, setProfile] = useState(null), [error, setError] = useState(null);
  useEffect(() => {
    const controller = new AbortController(); setError(null);
    api(`/profiles/${kind}/${id}`, { signal: controller.signal }).then(setProfile).catch(e => { if (e.name !== 'AbortError') setError(e); });
    return () => controller.abort();
  }, [kind, id, data]);
  const entity = kind === 'client' ? 'clienti' : 'oportunitati';
  const back = kind === 'client' ? 'clienti' : 'oportunitati';
  const tabs = kind === 'client'
    ? ['detalii', 'polite', 'activitati', 'plati', 'oferte']
    : ['detalii', 'activitati', 'oferte'];
  const activeTab = tabs.includes(tab) ? tab : 'detalii';
  if (error) return <><button className="text-button" onClick={() => navigate(back)}><ArrowLeft size={17} />Înapoi la listă</button><ErrorBox error={error} /></>;
  if (!profile) return <p role="status">Se încarcă profilul…</p>;
  const { record, client } = profile;
  const scope = { kind, id };
  const scopedData = { ...data, ...profile.data, clienti: [client], agentii: data.agentii.filter(a => String(a.id) === String(record.agentie_id)) };
  function openRelated(name, mode, row) {
    const initialValues = {
      agentie_id: record.agentie_id, client_id: client.id, broker_id: record.broker_id,
      ...(kind === 'lead' ? { oportunitate_id: id } : {}),
    };
    // Keep only actual form fields when passing initial values.
    const allowed = new Set(entities[name].fields.map(f => f.key));
    open(name, mode, row, { scope, scopeData: scopedData, initialValues: Object.fromEntries(Object.entries(initialValues).filter(([key]) => allowed.has(key))) });
  }
  return <>
    <button className="text-button profile-back" onClick={() => navigate(back)}><ArrowLeft size={17} />{kind === 'client' ? 'Toți clienții' : 'Toate oportunitățile'}</button>
    <PageHeading title={record[entities[entity].primary]} description={kind === 'client' ? `${record.email} · ${record.oras}` : `Lead / oportunitate #${id} · ${client.nume}`}>
      <button className="button secondary" onClick={() => open(entity, 'edit', record)}><Pencil size={17} />Modifică profilul</button>
    </PageHeading>
    <div className="profile-summary"><StatusBadge value={record.stare || record.etapa} /><span>Agent: <strong>{findRecord(data, 'brokeri', record.broker_id)?.nume}</strong></span><span>{findRecord(data, 'agentii', record.agentie_id)?.denumire}</span>{kind === 'lead' && <button className="text-button" onClick={() => navigate(`profil/client/${client.id}/detalii`)}>Profilul clientului<ArrowUpRight size={16} /></button>}</div>
    <nav className="section-tabs" aria-label="Secțiunile profilului">{tabs.map(key => <button key={key} aria-current={activeTab === key ? 'page' : undefined} className={activeTab === key ? 'selected' : ''} onClick={() => navigate(`profil/${kind}/${id}/${key}`)}>{key === 'detalii' ? 'Detalii' : entities[key].title}{key !== 'detalii' && <span>{profile.data[key].length}</span>}</button>)}</nav>
    {activeTab === 'detalii' ? <section className="panel profile-details"><h2>{kind === 'client' ? 'Datele clientului' : 'Datele leadului'}</h2><dl className="record-details">{entities[entity].fields.map(field => <div key={field.key}><dt>{field.label}</dt><dd>{fieldText(field, record[field.key], data)}</dd></div>)}</dl></section> : <div className="profile-content"><p className="list-note">{kind === 'client' ? `Doar înregistrările clientului ${client.nume}, din toate oportunitățile sale.` : 'Doar înregistrările acestui lead / acestei oportunități.'}</p><EntityPage key={activeTab} entity={activeTab} embedded data={data} rowsOverride={profile.data[activeTab]} open={openRelated} remove={(name, row) => remove(name, row, { scope })} /></div>}
  </>;
}
