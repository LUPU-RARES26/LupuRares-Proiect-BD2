import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { reportDefinitions, labels } from '../shared/entities.js';
import { api, scopeRows, recordName, dateText, money, today } from './lib.js';
import { PageHeading, DataTable, ErrorBox, Pagination } from './components.jsx';

const headings = { agentie: 'Agenție', etapa: 'Etapă', oportunitati: 'Oportunități', valoare_estimata_ron: 'Valoare estimată', client: 'Client', titlu: 'Oportunitate', numar: 'Număr', produs: 'Produs', asigurator: 'Asigurător', prima_anuala: 'Prima anuală', stare: 'Stare', broker: 'Broker', categorie: 'Categorie', sfarsit_la: 'Expiră la', comision_estimat_ron: 'Comision estimat', scadenta_la: 'Scadență', subiect: 'Subiect', numar_rata: 'Rată', suma: 'Sumă', client_id: 'ID client', cod: 'Cod produs' };
export function Reports({ data, agency }) {
  const [selected, setSelected] = useState('pipeline'), [person, setPerson] = useState(''), [date, setDate] = useState(today);
  const [result, setResult] = useState({ rows: [], columns: [] }), [error, setError] = useState(null), [loading, setLoading] = useState(true), [page, setPage] = useState(1);
  const definition = reportDefinitions.find(r => r.id === selected);
  const personEntity = definition.parameter === 'client' ? 'clienti' : 'brokeri';
  const people = scopeRows(data, personEntity, agency);
  const personId = people.some(p => String(p.id) === person) ? person : people[0]?.id || '';
  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams();
    if (agency) params.set('agency', agency);
    if (['client', 'broker'].includes(definition.parameter)) params.set('id', personId);
    if (definition.parameter === 'date') params.set('date', date);
    setLoading(true); setError(null); setPage(1);
    if ((['client', 'broker'].includes(definition.parameter) && !personId) || (definition.parameter === 'date' && !date)) { setResult({ rows: [], columns: [] }); setLoading(false); return () => controller.abort(); }
    api(`/reports/${selected}?${params}`, { signal: controller.signal }).then(setResult).catch(e => { if (e.name !== 'AbortError') setError(e); }).finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [selected, agency, personId, date, data]);
  const columns = result.columns.map(key => ({ key, label: headings[key] || key, render: row => {
    if (['prima_anuala', 'suma', 'valoare_estimata_ron', 'comision_estimat_ron'].includes(key)) return money(row[key]);
    if (key.endsWith('_la')) return dateText(row[key], String(row[key]).includes('T'));
    return labels[row[key]] || String(row[key] ?? '—');
  } }));
  return <><PageHeading title="Rapoarte" description="Transformă datele portofoliului în decizii informate." /><div className="reports-layout"><nav className="report-nav" aria-label="Alege raportul">{reportDefinitions.map((r, index) => <button className={selected === r.id ? 'selected' : ''} onClick={() => { setSelected(r.id); setPerson(''); }} key={r.id}><span className="report-index">0{index + 1}</span><span>{r.title}</span><ArrowRight size={16} /></button>)}</nav><section className="panel report-panel"><h2>{definition.title}</h2><p className="report-description">{definition.description}</p><div className="report-controls">{['client', 'broker'].includes(definition.parameter) && <label>{definition.parameter === 'client' ? 'Client' : 'Broker'}<select value={personId} onChange={e => setPerson(e.target.value)}>{people.map(p => <option key={p.id} value={p.id}>{recordName(personEntity, p)}</option>)}</select></label>}{definition.parameter === 'date' && <label>Rate scadente începând cu<input type="date" value={date} onChange={e => setDate(e.target.value)} /></label>}</div><ErrorBox error={error} />{loading ? <div className="loading-inline">Se calculează raportul…</div> : !error && <><DataTable columns={columns} rows={result.rows.slice((page - 1) * 12, page * 12)} /><Pagination total={result.rows.length} page={page} onPage={setPage} /></>}</section></div></>;
}
