import { entities, labels } from '../shared/entities.js';
export async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', 'X-CRM-Request': '1', ...options.headers },
  });
  const result = await response.json();
  if (!response.ok) { const error = new Error(result.error || 'Cererea nu a putut fi procesată.'); error.fields = result.fields || {}; throw error; }
  return result;
}
export const money = value => new Intl.NumberFormat('ro-RO', { style: 'currency', currency: 'RON', maximumFractionDigits: 2 }).format(Number(value || 0));
export const dateText = (value, time = false) => value ? new Intl.DateTimeFormat('ro-RO', { day: 'numeric', month: 'short', year: 'numeric', ...(time ? { hour: '2-digit', minute: '2-digit' } : {}), timeZone: 'Europe/Bucharest' }).format(new Date(value.length === 10 ? `${value}T12:00:00` : value)) : '—';
export const today = () => localDateTime(new Date()).slice(0, 10);
export function localDateTime(value) {
  const date = new Date(value);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}
export const findRecord = (data, entity, id) => (data[entity] || []).find(row => String(row.id) === String(id));
export function recordName(entity, row) {
  if (!row) return 'Înregistrare indisponibilă';
  if (entity === 'plati') return `Rata ${row.numar_rata} · ${money(row.suma)}`;
  if (entity === 'oportunitati') return `${row.titlu} · #${row.id}`;
  return String(row[entities[entity].primary] || `#${row.id}`);
}
export function fieldText(field, value, data) {
  if (value === null || value === undefined || value === '') return '—';
  if (field?.type === 'reference') return recordName(field.entity, findRecord(data, field.entity, value));
  if (field?.type === 'date' || field?.type === 'datetime-local') return dateText(value, field.type === 'datetime-local');
  if (field?.type === 'checkbox') return value ? 'Activ' : 'Inactiv';
  if (['suma', 'prima_anuala', 'valoare_estimata', 'suma_asigurata'].includes(field?.key)) return money(value);
  if (field?.key === 'comision_procente') return `${value}%`;
  return labels[value] || String(value);
}
export function agencyOf(entity, row, data) {
  if (!row) return null;
  if (entity === 'agentii') return String(row.id);
  if (row.agentie_id) return String(row.agentie_id);
  if (row.oportunitate_id) return agencyOf('oportunitati', findRecord(data, 'oportunitati', row.oportunitate_id), data);
  if (row.oferta_id) return agencyOf('oferte', findRecord(data, 'oferte', row.oferta_id), data);
  if (row.polita_id) return agencyOf('polite', findRecord(data, 'polite', row.polita_id), data);
  return null;
}
export const scopeRows = (data, entity, agency) => (data[entity] || []).filter(row => !agency || ['asiguratori', 'produse_asigurare'].includes(entity) || agencyOf(entity, row, data) === agency);
export const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export function defaults(entity, agency) {
  return Object.fromEntries(entities[entity].fields.map(field => [field.key,
    field.key === 'agentie_id' && agency ? agency : field.default === 'now' ? localDateTime(new Date()) : field.default === 'today' ? today() : field.default ?? '',
  ]));
}
export function formValues(entity, row) {
  return Object.fromEntries(entities[entity].fields.map(field => [field.key,
    row[field.key] == null ? '' : field.type === 'datetime-local' ? localDateTime(row[field.key]) : row[field.key],
  ]));
}
export function formBody(entity, values, editing) {
  return Object.fromEntries(entities[entity].fields.filter(f => !editing || !f.createOnly).map(f => [f.key,
    values[f.key] === '' || values[f.key] == null ? null : f.type === 'datetime-local' ? new Date(values[f.key]).toISOString() : values[f.key],
  ]));
}

export function relationOptions(field, values, data, current) {
  let rows = data[field.entity] || [];
  if (['broker_id', 'client_id'].includes(field.key) && values.agentie_id) rows = rows.filter(r => String(r.agentie_id) === String(values.agentie_id));
  if (field.key === 'oportunitate_id') rows = rows.filter(r => (!values.agentie_id || String(r.agentie_id) === String(values.agentie_id)) && (!values.client_id || String(r.client_id) === String(values.client_id)));
  if (field.key === 'produs_id' && values.categorie) rows = rows.filter(r => r.categorie === values.categorie);
  if (field.key === 'oferta_id') rows = rows.filter(r => r.stare === 'acceptata' && !(data.polite || []).some(p => String(p.oferta_id) === String(r.id) && String(p.id) !== String(current?.id)));
  return rows;
}
export const profileQuery = scope => scope ? `?profileKind=${scope.kind}&profileId=${scope.id}` : '';
