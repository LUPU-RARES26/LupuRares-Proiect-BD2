import React, { useEffect, useRef } from 'react';
import { Home, UsersRound, Target, FileText, Shield, CalendarDays, CreditCard, ChartNoAxesColumn, Building2, UserRound, Landmark, Layers, X, AlertCircle, Inbox, ChevronLeft, ChevronRight } from 'lucide-react';
import { labels } from '../shared/entities.js';
export const iconMap = { Home, UsersRound, Target, FileText, Shield, CalendarDays, CreditCard, ChartNoAxesColumn, Building2, UserRound, Landmark, Layers };
export function Icon({ name, ...props }) { const Component = iconMap[name] || FileText; return <Component size={21} strokeWidth={1.75} aria-hidden="true" {...props} />; }
export function StatusBadge({ value }) {
  const good = ['activa', 'client', 'castigat', 'acceptata', 'platita', 'finalizata', true].includes(value);
  const bad = ['pierdut', 'respinsa', 'restanta', 'anulata', 'inactiv', false].includes(value);
  return <span className={`badge ${good ? 'good' : bad ? 'muted' : 'pending'}`}>{labels[value] || value}</span>;
}
export function ErrorBox({ error }) { return error ? <div className="error-box" role="alert"><AlertCircle size={19} /><span>{error.message || error}</span></div> : null; }
export function Empty({ title = 'Nu există înregistrări', description = 'Adaugă o înregistrare sau modifică filtrele pentru a continua.' }) { return <div className="empty-state"><Inbox size={34} strokeWidth={1.4} /><h3>{title}</h3><p>{description}</p></div>; }
export function PageHeading({ title, description, children }) { return <div className="page-heading"><div><h1>{title}</h1><p>{description}</p></div>{children}</div>; }
export function DataTable({ columns, rows, rowKey = 'id' }) {
  if (!rows.length) return <Empty />;
  return <div className="table-scroll" tabIndex={0} role="region" aria-label="Tabel de date"><table><thead><tr>{columns.map(c => <th key={c.key} scope="col">{c.label}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={row[rowKey] ?? index}>{columns.map(c => <td key={c.key}>{c.render ? c.render(row) : row[c.key] ?? '—'}</td>)}</tr>)}</tbody></table></div>;
}
export function Pagination({ total, page, onPage, size = 12 }) {
  const pages = Math.max(1, Math.ceil(total / size));
  return <div className="pagination"><span>{total ? `${(page - 1) * size + 1}–${Math.min(page * size, total)} din ${total} înregistrări` : '0 înregistrări'}</span><div><button className="icon-button" aria-label="Pagina anterioară" disabled={page <= 1} onClick={() => onPage(page - 1)}><ChevronLeft size={18} /></button><span>{page} / {pages}</span><button className="icon-button" aria-label="Pagina următoare" disabled={page >= pages} onClick={() => onPage(page + 1)}><ChevronRight size={18} /></button></div></div>;
}
export function Dialog({ children, title, onClose, className = '', busy = false }) {
  const root = useRef(null);
  const close = useRef(onClose); close.current = onClose;
  const blocked = useRef(busy); blocked.current = busy;
  useEffect(() => {
    const previous = document.activeElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    root.current?.querySelector('input:not([disabled]), select:not([disabled]), button:not([disabled])')?.focus();
    function keydown(event) {
      if (event.key === 'Escape' && !blocked.current) close.current();
      if (event.key !== 'Tab') return;
      const focusable = [...root.current.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]')];
      const first = focusable[0], last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
    document.addEventListener('keydown', keydown);
    return () => { document.body.style.overflow = oldOverflow; document.removeEventListener('keydown', keydown); previous?.focus(); };
  }, []);
  return <div className={`dialog-backdrop ${className}`} onMouseDown={event => { if (event.target === event.currentTarget && !busy) onClose(); }}><section className="dialog-surface" role="dialog" aria-modal="true" aria-labelledby="dialog-title" ref={root}><header className="dialog-header"><h2 id="dialog-title">{title}</h2><button className="icon-button" onClick={onClose} disabled={busy} aria-label="Închide formularul"><X size={23} /></button></header>{children}</section></div>;
}
