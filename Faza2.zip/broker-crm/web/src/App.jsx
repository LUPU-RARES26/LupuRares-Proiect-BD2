import React, { useCallback, useEffect, useState } from 'react';
import { Menu, X, CheckCircle2, RefreshCw } from 'lucide-react';
import { entities, mainNavigation, adminNavigation } from '../shared/entities.js';
import { api } from './lib.js';
import { Icon, ErrorBox } from './components.jsx';
import { Dashboard } from './Dashboard.jsx';
import { EntityPage } from './EntityPage.jsx';
import { RecordDrawer, ConfirmDelete } from './RecordDrawer.jsx';
import { Reports } from './Reports.jsx';
import { ProfilePage } from './ProfilePage.jsx';
import { TasksPage } from './TasksPage.jsx';

const profilePattern = /^profil\/(client|lead)\/([1-9]\d*)\/(\w+)$/;
function currentPage() { const route = window.location.hash.slice(1); if (['polite', 'plati', 'activitati', 'oferte'].includes(route)) return 'clienti'; return ['rapoarte', 'sarcini', ...mainNavigation, ...adminNavigation].includes(route) || profilePattern.test(route) ? route : 'dashboard'; }
export function App() {
  const [page, setPage] = useState(currentPage), [initialFilter, setInitialFilter] = useState('');
  const [data, setData] = useState(null), [agency, setAgency] = useState('');
  const [error, setError] = useState(null), [loading, setLoading] = useState(true);
  const [drawer, setDrawer] = useState(null), [deletion, setDeletion] = useState(null), [toast, setToast] = useState(''), [mobileNav, setMobileNav] = useState(false);
  const reload = useCallback(async () => {
    setLoading(true); setError(null);
    try { const result = await api('/bootstrap'); setData(result.data); }
    catch (e) { setError(e); } finally { setLoading(false); }
  }, []);
  useEffect(() => { reload(); }, [reload]);
  useEffect(() => { function onHash() { setPage(currentPage()); setInitialFilter(''); setMobileNav(false); } window.addEventListener('hashchange', onHash); return () => window.removeEventListener('hashchange', onHash); }, []);
  useEffect(() => { if (!toast) return; const timeout = setTimeout(() => setToast(''), 5000); return () => clearTimeout(timeout); }, [toast]);
  const profileRoute = page.match(profilePattern);
  useEffect(() => { document.title = `${profileRoute ? 'Profil' : page === 'sarcini' ? 'Sarcini' : page === 'dashboard' ? 'Prezentare generală' : page === 'rapoarte' ? 'Rapoarte' : entities[page].title} · Broker CRM`; }, [page]);
  useEffect(() => { if (agency && data && !data.agentii.some(a => String(a.id) === agency)) setAgency(''); }, [data, agency]);
  function navigate(route, filter = '') { window.history.pushState(null, '', `#${route}`); setPage(route); setInitialFilter(filter); setMobileNav(false); window.scrollTo({ top: 0 }); }
  function open(entity, mode, row, extra = {}) { if (mode === 'view' && ['clienti', 'oportunitati'].includes(entity)) { navigate(`profil/${entity === 'clienti' ? 'client' : 'lead'}/${row.id}/detalii`); return; } setDrawer({ entity, mode, row, ...extra }); }
  function remove(entity, row, extra = {}) { setDeletion({ entity, row, ...extra }); }
  function saved(message) { setDrawer(null); setDeletion(null); setToast(message); reload(); }
  const navItem = (route, label, icon) => {
    const active = page === route || (profileRoute && route === (profileRoute[1] === 'client' ? 'clienti' : 'oportunitati'));
    return <a href={`#${route}`} className={`nav-item ${active ? 'active' : ''}`} aria-current={active ? 'page' : undefined} key={route} onClick={e => { e.preventDefault(); navigate(route); }}><Icon name={icon} /><span>{label}</span></a>;
  };
  return <div className="app-shell">
    <a href="#main-content" className="skip-link" onClick={event => { event.preventDefault(); document.getElementById('main-content')?.focus(); }}>Sari la conținut</a>
    {mobileNav && <button className="nav-overlay" aria-label="Închide meniul" onClick={() => setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav ? 'is-open' : ''}`} inert={Boolean(drawer || deletion)}><div className="brand"><Icon name="Shield" size={34} /><span>Broker CRM</span><button className="icon-button mobile-close" aria-label="Închide meniul" onClick={() => setMobileNav(false)}><X /></button></div><nav aria-label="Navigație principală">{navItem('dashboard', 'Prezentare generală', 'Home')}{mainNavigation.map(e => navItem(e, entities[e].title, entities[e].icon))}{navItem('sarcini', 'Sarcini', 'CalendarDays')}{navItem('rapoarte', 'Rapoarte', 'ChartNoAxesColumn')}<div className="nav-separator" />{adminNavigation.map(e => navItem(e, entities[e].title, entities[e].icon))}</nav><div className="sidebar-footer">Spațiu demonstrativ</div></aside>
    <div className="workspace" inert={Boolean(drawer || deletion)}><header className="topbar"><button className="icon-button mobile-menu" aria-label="Deschide meniul" onClick={() => setMobileNav(true)}><Menu /></button><span className="workspace-label">Portofoliul agenției</span><select className="agency-select" aria-label="Agenția afișată" value={agency} onChange={e => setAgency(e.target.value)}><option value="">Toate agențiile</option>{data?.agentii.map(a => <option key={a.id} value={a.id}>{a.denumire}</option>)}</select><div className="topbar-end"><button className="icon-button refresh" title="Reîncarcă datele" aria-label="Reîncarcă datele" disabled={loading} onClick={reload}><RefreshCw size={17} className={loading ? 'spinning' : ''} /></button><span className="avatar" aria-label="Broker CRM">BC</span></div></header>
      <main id="main-content" tabIndex={-1}><ErrorBox error={error} />{!data ? <div className="loading-screen">{loading ? <><span className="loader" /><p>Se încarcă portofoliul…</p></> : <><h1>Conexiunea este întreruptă</h1><p>Verifică dacă serviciile proiectului sunt pornite în Docker.</p><button className="button primary" onClick={reload}>Încearcă din nou</button></>}</div> : page === 'dashboard' ? <Dashboard data={data} agency={agency} navigate={navigate} open={open} /> : profileRoute ? <ProfilePage key={`${profileRoute[1]}-${profileRoute[2]}`} kind={profileRoute[1]} id={profileRoute[2]} tab={profileRoute[3]} data={data} open={open} remove={remove} navigate={navigate} /> : page === 'sarcini' ? <TasksPage data={data} agency={agency} open={open} remove={remove} onSaved={saved} navigate={navigate} /> : page === 'rapoarte' ? <Reports data={data} agency={agency} /> : <EntityPage key={`${page}-${initialFilter}`} entity={page} data={data} agency={agency} initialFilter={initialFilter} open={open} remove={remove} />}</main>
    </div>
    {drawer && data && <RecordDrawer key={`${drawer.entity}-${drawer.mode}-${drawer.row?.id || 'new'}`} {...drawer} data={data} agency={agency} onClose={() => setDrawer(null)} onSaved={saved} onEdit={() => setDrawer({ ...drawer, mode: 'edit' })} />}
    {deletion && <ConfirmDelete {...deletion} onClose={() => setDeletion(null)} onSaved={saved} />}
    {toast && <div className="toast" role="status"><CheckCircle2 size={20} /><span>{toast}</span><button className="icon-button" aria-label="Închide notificarea" onClick={() => setToast('')}><X size={17} /></button></div>}
  </div>;
}
