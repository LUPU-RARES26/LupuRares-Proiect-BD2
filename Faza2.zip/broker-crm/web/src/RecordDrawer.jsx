import React, { useState } from 'react';
import { Pencil, Trash2 } from 'lucide-react';
import { entities, labels, taskTypes } from '../shared/entities.js';
import { api, defaults, formValues, formBody, fieldText, recordName, relationOptions, findRecord, localDateTime, today, dateText, profileQuery } from './lib.js';
import { Dialog, ErrorBox } from './components.jsx';

export function RecordDrawer({ entity, mode, row, data, agency, onClose, onSaved, onEdit, initialValues = {}, scope, scopeData, task = false }) {
  const config = task ? { ...entities[entity], singular: 'sarcina', createTitle: 'Sarcină nouă', saveLabel: 'Salvează sarcina', helper: 'Alege agentul, momentul afișării și termenul-limită. Email/SMS este un tip de sarcină de efectuat.' } : entities[entity];
  const editing = mode === 'edit';
  const [values, setValues] = useState(() => row ? formValues(entity, row) : { ...defaults(entity, agency), ...initialValues });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const fields = config.formOrder ? [...config.fields].sort((a, b) => config.formOrder.indexOf(a.key) - config.formOrder.indexOf(b.key)) : config.fields;
  const title = mode === 'view' ? recordName(entity, row) : editing ? `Modifică ${config.singular}` : config.createTitle;
  function change(field, value) {
    setError(null);
    setValues(previous => {
      const next = { ...previous, [field.key]: value };
      if (field.key === 'agentie_id') { if ('broker_id' in next) next.broker_id = ''; if ('client_id' in next) next.client_id = ''; if (entity === 'activitati') next.oportunitate_id = ''; }
      if (field.key === 'client_id') {
        const client = findRecord(data, 'clienti', value);
        if (client) { next.agentie_id = client.agentie_id; if (entity !== 'activitati' || String(findRecord(data, 'brokeri', next.broker_id)?.agentie_id) !== String(client.agentie_id)) next.broker_id = client.broker_id; }
        if (entity === 'activitati') next.oportunitate_id = '';
      }
      if (entity === 'activitati' && field.key === 'oportunitate_id') {
        const lead = findRecord(data, 'oportunitati', value);
        if (lead) { next.client_id = lead.client_id; next.agentie_id = lead.agentie_id; if (String(findRecord(data, 'brokeri', next.broker_id)?.agentie_id) !== String(lead.agentie_id)) next.broker_id = lead.broker_id; }
      }
      if (entity === 'oferte' && field.key === 'oportunitate_id') {
        const opportunity = findRecord(data, 'oportunitati', value);
        if (opportunity) { next.categorie = opportunity.categorie; next.produs_id = ''; }
      }
      if (entity === 'oferte' && field.key === 'categorie') next.produs_id = '';
      if (field.key === 'etapa') next.inchis_la = ['castigat', 'pierdut'].includes(value) ? next.inchis_la || localDateTime(new Date()) : '';
      if (entity === 'activitati' && field.key === 'stare') next.finalizata_la = value === 'finalizata' ? next.finalizata_la || localDateTime(new Date()) : '';
      if (entity === 'plati' && field.key === 'stare') next.platita_la = value === 'platita' ? next.platita_la || today() : '';
      return next;
    });
  }
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError(null);
    try {
      await api(`/${entity}${editing ? `/${row.id}` : ''}${profileQuery(scope)}`, { method: editing ? 'PUT' : 'POST', body: JSON.stringify(formBody(entity, values, editing)) });
      onSaved(editing ? 'Modificările au fost salvate.' : 'Înregistrarea a fost adăugată.');
    } catch (error) { setError(error); } finally { setBusy(false); }
  }
  function required(field) {
    return field.required || (field.key === 'inchis_la' && ['castigat', 'pierdut'].includes(values.etapa))
      || (field.key === 'finalizata_la' && values.stare === 'finalizata')
      || (['platita_la', 'metoda', 'referinta_demo'].includes(field.key) && values.stare === 'platita');
  }
  return <Dialog title={title} onClose={onClose} className="drawer" busy={busy}>
    {mode === 'view' ? <>
      <div className="drawer-body"><p className="drawer-description">{config.title} · Înregistrarea #{row.id}</p><dl className="record-details">{config.fields.map(f => <div key={f.key}><dt>{f.label}</dt><dd>{fieldText(f, row[f.key], data)}</dd></div>)}{row.creat_la && !config.fields.some(f => f.key === 'creat_la') && <div><dt>Creată la</dt><dd>{dateText(row.creat_la, true)}</dd></div>}</dl></div>
      <footer className="dialog-footer"><button className="button secondary" onClick={onClose}>Închide</button><button className="button primary" onClick={onEdit}><Pencil size={17} />Modifică</button></footer>
    </> : <form onSubmit={submit} className="drawer-form">
      <div className="drawer-body"><p className="drawer-description">{config.helper || `Completează informațiile pentru ${config.singular}.`}</p><ErrorBox error={error} /><div className="form-grid">{fields.filter(f => !editing || !f.createOnly).map(field => {
        const full = ['nume', 'denumire', 'titlu', 'subiect', 'email', 'descriere', 'stare', 'oportunitate_id', 'oferta_id', 'polita_id'].includes(field.key);
        const props = {
          id: `field-${field.key}`, name: field.key, value: values[field.key] ?? '',
          onChange: event => change(field, event.target.value), required: required(field),
          'aria-invalid': error?.fields?.[field.key] ? true : undefined,
          'aria-describedby': error?.fields?.[field.key] ? `error-${field.key}` : undefined,
          disabled: busy || Boolean(scope && (['client_id', 'agentie_id'].includes(field.key) || (scope.kind === 'lead' && field.key === 'oportunitate_id'))),
        };
        let control;
        if (field.type === 'reference') {
          const options = relationOptions(field, values, scopeData || data, row);
          control = <><select {...props}><option value="">Selectează {field.label.toLowerCase()}</option>{options.map(item => <option key={item.id} value={item.id}>{recordName(field.entity, item)}</option>)}</select>{!options.length && <small className="field-hint">Nu există opțiuni eligibile. Adaugă mai întâi înregistrarea asociată.</small>}</>;
        } else if (field.type === 'select') {
          const choices = task && field.key === 'tip' ? [...taskTypes, ...(!taskTypes.includes(values.tip) && values.tip ? [values.tip] : [])] : field.choices;
          control = <select {...props}>{!field.required && <option value="">Nespecificată</option>}{choices.map(value => <option key={value} value={value}>{labels[value] || value}</option>)}</select>;
        } else if (field.type === 'textarea') control = <textarea {...props} rows={3} maxLength={field.maxLength} />;
        else if (field.type === 'checkbox') control = <label className="checkbox-row"><input type="checkbox" checked={Boolean(values[field.key])} onChange={e => change(field, e.target.checked)} disabled={busy} />Înregistrare activă</label>;
        else control = <input {...props} type={field.type} min={field.min} max={field.max} step={field.step} maxLength={field.maxLength} placeholder={field.type === 'text' || field.type === 'email' ? `Introdu ${field.label.toLowerCase()}` : undefined} />;
        return <div className={`form-field ${full ? 'full-width' : ''}`} key={field.key}><label htmlFor={field.type === 'checkbox' ? undefined : props.id}>{field.label}{!required(field) && field.type !== 'checkbox' && <span className="optional"> opțional</span>}</label>{control}{error?.fields?.[field.key] && <small className="field-error" id={`error-${field.key}`}>{error.fields[field.key]}</small>}</div>;
      })}</div></div>
      <footer className="dialog-footer"><button type="button" className="button secondary" disabled={busy} onClick={onClose}>Anulează</button><button type="submit" className="button primary" disabled={busy}>{busy ? 'Se salvează…' : config.saveLabel}</button></footer>
    </form>}
  </Dialog>;
}

export function ConfirmDelete({ entity, row, onClose, onSaved, scope }) {
  const [busy, setBusy] = useState(false), [error, setError] = useState(null);
  async function remove() {
    setBusy(true); setError(null);
    try { await api(`/${entity}/${row.id}${profileQuery(scope)}`, { method: 'DELETE' }); onSaved('Înregistrarea a fost ștearsă.'); }
    catch (error) { setError(error); } finally { setBusy(false); }
  }
  return <Dialog title={`Ștergi ${entities[entity].singular}?`} onClose={onClose} className="confirm-dialog" busy={busy}><div className="confirm-body"><div className="delete-symbol"><Trash2 size={25} /></div><p><strong>{recordName(entity, row)}</strong></p><p>Înregistrarea va fi eliminată permanent. Dacă are date asociate, baza de date va bloca ștergerea.</p><ErrorBox error={error} /></div><footer className="dialog-footer"><button className="button secondary" disabled={busy} onClick={onClose}>Anulează</button><button className="button danger" disabled={busy} onClick={remove}>{busy ? 'Se șterge…' : 'Șterge înregistrarea'}</button></footer></Dialog>;
}
