const field = (key, label, type = 'text', options = {}) => ({ key, label, type, required: true, ...options });
const ref = (key, label, entity, options = {}) => field(key, label, 'reference', { entity, ...options });
const select = (key, label, choices, options = {}) => field(key, label, 'select', { choices, ...options });
const money = (key, label, options = {}) => field(key, label, 'number', { min: 0.01, max: 9999999999.99, step: '0.01', ...options });
const date = (key, label, options = {}) => field(key, label, 'date', options);
const timestamp = (key, label, options = {}) => field(key, label, 'datetime-local', options);
const active = () => field('activ', 'Activ', 'checkbox', { default: true });
const currency = () => select('moneda', 'Monedă', ['RON'], { default: 'RON' });
export const categories = ['RCA', 'CASCO', 'LOCUINTA'];
export const stages = ['nou', 'contactat', 'ofertare', 'negociere', 'castigat', 'pierdut'];
export const taskTypes = ['programare', 'email_sms', 'reminder', 'de_facut'];
export const labels = {
  persoana: 'Persoană', firma: 'Firmă', prospect: 'Prospect', client: 'Client', inactiv: 'Inactiv',
  administrator: 'Administrator', broker: 'Broker', nou: 'Nou', contactat: 'Contactat', ofertare: 'Ofertare',
  negociere: 'Negociere', castigat: 'Câștigat', pierdut: 'Pierdut', website: 'Website', recomandare: 'Recomandare',
  telefon: 'Telefon', campanie: 'Campanie', ciorna: 'Ciornă', trimisa: 'Trimisă', acceptata: 'Acceptată',
  respinsa: 'Respinsă', expirata: 'Expirată', programata: 'Programată', activa: 'Activă', anulata: 'Anulată',
  apel: 'Apel', email: 'Email', intalnire: 'Întâlnire', sarcina: 'Sarcină', planificata: 'Planificată',
  finalizata: 'Finalizată', platita: 'Plătită', restanta: 'Restantă', card: 'Card', transfer: 'Transfer',
  numerar: 'Numerar', LOCUINTA: 'Locuință', true: 'Activ', false: 'Inactiv',
  programare: 'Programare', email_sms: 'Trimite email/SMS', reminder: 'Reminder', de_facut: 'De făcut',
};

export const entities = {
  agentii: { title: 'Agenții', singular: 'agenția', createTitle: 'Agenție nouă', saveLabel: 'Salvează agenția', icon: 'Building2', primary: 'denumire', description: 'Echipele și organizațiile din portofoliul tău.', columns: ['denumire', 'cod_demo', 'email', 'oras'], fields: [
    field('denumire', 'Denumire', 'text', { maxLength: 150 }), field('cod_demo', 'Cod', 'text', { maxLength: 30 }),
    field('email', 'Email', 'email', { maxLength: 150 }), field('oras', 'Oraș', 'text', { maxLength: 80 }),
  ]},
  brokeri: { title: 'Brokeri', singular: 'brokerul', createTitle: 'Broker nou', saveLabel: 'Salvează brokerul', icon: 'UserRound', primary: 'nume', description: 'Oamenii care construiesc relațiile cu clienții.', columns: ['nume', 'email', 'agentie_id', 'rol', 'activ'], fields: [
    ref('agentie_id', 'Agenție', 'agentii'), field('nume', 'Nume', 'text', { maxLength: 120 }),
    field('email', 'Email', 'email', { maxLength: 150 }), select('rol', 'Rol', ['broker', 'administrator'], { default: 'broker' }), active(),
  ]},
  clienti: { title: 'Clienți', singular: 'clientul', createTitle: 'Client nou', saveLabel: 'Salvează clientul', icon: 'UsersRound', primary: 'nume', description: 'Relațiile care îți construiesc portofoliul.', helper: 'Adaugă datele clientului și alege brokerul responsabil.', columns: ['nume', 'tip', 'oras', 'stare', 'broker_id'], formOrder: ['nume', 'tip', 'oras', 'email', 'agentie_id', 'broker_id', 'stare'], fields: [
    ref('agentie_id', 'Agenție', 'agentii'), ref('broker_id', 'Broker', 'brokeri'),
    field('nume', 'Nume', 'text', { maxLength: 150 }), select('tip', 'Tip', ['persoana', 'firma'], { default: 'persoana' }),
    field('email', 'Email', 'email', { maxLength: 150 }), field('oras', 'Oraș', 'text', { maxLength: 80 }),
    select('stare', 'Stare', ['prospect', 'client', 'inactiv'], { default: 'prospect' }),
  ]},
  asiguratori: { title: 'Asigurători', singular: 'asigurătorul', createTitle: 'Asigurător nou', saveLabel: 'Salvează asigurătorul', icon: 'Landmark', primary: 'denumire', description: 'Partenerii tăi pentru soluții de asigurare.', columns: ['denumire', 'cod_demo', 'email', 'activ'], fields: [
    field('denumire', 'Denumire', 'text', { maxLength: 150 }), field('cod_demo', 'Cod', 'text', { maxLength: 30 }),
    field('email', 'Email', 'email', { maxLength: 150 }), active(),
  ]},
  produse_asigurare: { title: 'Produse', singular: 'produsul', createTitle: 'Produs nou', saveLabel: 'Salvează produsul', icon: 'Layers', primary: 'denumire', description: 'Catalogul de produse RCA, CASCO și locuință.', columns: ['denumire', 'cod', 'categorie', 'asigurator_id', 'activ'], fields: [
    ref('asigurator_id', 'Asigurător', 'asiguratori'), field('cod', 'Cod produs', 'text', { maxLength: 40 }),
    field('denumire', 'Denumire', 'text', { maxLength: 150 }), select('categorie', 'Categorie', categories, { default: 'RCA' }),
    field('descriere', 'Descriere', 'textarea', { maxLength: 5000 }), active(),
  ]},
  oportunitati: { title: 'Oportunități', singular: 'oportunitatea', createTitle: 'Oportunitate nouă', saveLabel: 'Salvează oportunitatea', icon: 'Target', primary: 'titlu', description: 'De la primul contact la o relație de durată.', columns: ['titlu', 'client_id', 'categorie', 'etapa', 'valoare_estimata'], fields: [
    ref('agentie_id', 'Agenție', 'agentii'), ref('client_id', 'Client', 'clienti'), ref('broker_id', 'Broker', 'brokeri'),
    field('titlu', 'Titlu', 'text', { maxLength: 180 }), select('categorie', 'Categorie', categories, { default: 'RCA' }),
    select('etapa', 'Etapă', stages, { default: 'nou' }), select('sursa', 'Sursă', ['website', 'recomandare', 'telefon', 'campanie'], { default: 'website' }),
    money('valoare_estimata', 'Valoare estimată'), currency(), timestamp('creat_la', 'Creată la', { createOnly: true, default: 'now' }),
    timestamp('inchis_la', 'Închisă la', { required: false }),
  ]},
  oferte: { title: 'Oferte', singular: 'oferta', createTitle: 'Ofertă nouă', saveLabel: 'Salvează oferta', icon: 'FileText', primary: 'numar', description: 'Compară opțiunile și găsește protecția potrivită.', columns: ['numar', 'oportunitate_id', 'produs_id', 'prima_anuala', 'stare'], fields: [
    ref('oportunitate_id', 'Oportunitate', 'oportunitati'), ref('produs_id', 'Produs', 'produse_asigurare'),
    select('categorie', 'Categorie', categories, { default: 'RCA' }), field('numar', 'Număr ofertă', 'text', { maxLength: 40 }),
    money('prima_anuala', 'Prima anuală'), money('suma_asigurata', 'Suma asigurată', { max: 999999999999.99 }), currency(),
    select('stare', 'Stare', ['ciorna', 'trimisa', 'acceptata', 'respinsa', 'expirata'], { default: 'ciorna' }),
    date('emisa_la', 'Emisă la', { default: 'today' }), date('valabila_pana', 'Valabilă până la'),
  ]},
  polite: { title: 'Polițe', singular: 'polița', createTitle: 'Poliță nouă', saveLabel: 'Salvează polița', icon: 'Shield', primary: 'numar', description: 'Protecție activă și o vedere clară asupra portofoliului.', columns: ['numar', 'oferta_id', 'inceput_la', 'sfarsit_la', 'stare'], fields: [
    ref('oferta_id', 'Ofertă acceptată', 'oferte'), field('numar', 'Număr poliță', 'text', { maxLength: 40 }),
    date('inceput_la', 'Începutul asigurării'), date('sfarsit_la', 'Sfârșitul asigurării'),
    select('stare', 'Stare', ['programata', 'activa', 'expirata', 'anulata'], { default: 'programata' }),
    money('comision_procente', 'Comision (%)', { min: 0, max: 100 }), date('emisa_la', 'Emisă la', { default: 'today' }),
  ]},
  activitati: { title: 'Activități', singular: 'activitatea', createTitle: 'Activitate nouă', saveLabel: 'Salvează activitatea', icon: 'CalendarDays', primary: 'subiect', description: 'Următorul pas pentru fiecare relație cu un client.', columns: ['subiect', 'tip', 'broker_id', 'scadenta_la', 'stare'], fields: [
    ref('oportunitate_id', 'Lead / oportunitate', 'oportunitati', { required: false }), select('tip', 'Tip', [...taskTypes, 'apel', 'email', 'intalnire', 'sarcina'], { default: 'de_facut' }),
    field('subiect', 'Subiect', 'text', { maxLength: 180 }), field('descriere', 'Descriere', 'textarea', { maxLength: 5000 }),
    timestamp('scadenta_la', 'Termen-limită'), timestamp('finalizata_la', 'Finalizată la', { required: false }),
    select('stare', 'Stare', ['planificata', 'finalizata', 'anulata'], { default: 'planificata' }),
    ref('broker_id', 'Agent responsabil', 'brokeri'), ref('client_id', 'Client', 'clienti', { required: false }),
    ref('agentie_id', 'Agenție', 'agentii'), timestamp('vizibila_de_la', 'Apare în Sarcini la', { default: 'now' }),
  ]},
  plati: { title: 'Plăți', singular: 'plata', createTitle: 'Plată nouă', saveLabel: 'Salvează plata', icon: 'CreditCard', primary: 'id', description: 'Rate, încasări și scadențe, într-un singur loc.', columns: ['polita_id', 'numar_rata', 'suma', 'scadenta_la', 'stare'], fields: [
    ref('polita_id', 'Poliță', 'polite'), field('numar_rata', 'Număr rată', 'number', { min: 1, max: 32767, step: '1', default: 1 }),
    money('suma', 'Sumă'), currency(), date('scadenta_la', 'Scadență'), date('platita_la', 'Plătită la', { required: false }),
    select('metoda', 'Metodă', ['card', 'transfer', 'numerar'], { required: false }),
    field('referinta_demo', 'Referință tranzacție', 'text', { maxLength: 50, required: false }),
    select('stare', 'Stare', ['planificata', 'platita', 'restanta', 'anulata'], { default: 'planificata' }),
  ]},
};

entities.activitati.formOrder = ['subiect', 'tip', 'agentie_id', 'broker_id', 'client_id', 'oportunitate_id', 'vizibila_de_la', 'scadenta_la', 'descriere', 'stare', 'finalizata_la'];
export const mainNavigation = ['clienti', 'oportunitati'];
export const adminNavigation = ['agentii', 'brokeri', 'asiguratori', 'produse_asigurare'];
export const reportDefinitions = [
  { id: 'pipeline', title: 'Pipeline comercial', description: 'Numărul și valoarea oportunităților, pe agenții și etape.' },
  { id: 'comparatie', title: 'Compararea ofertelor', description: 'Produsele și asigurătorii propuși unui client.', parameter: 'client' },
  { id: 'portofoliu', title: 'Portofoliul de polițe', description: 'Clienți, brokeri și comisioane estimate.' },
  { id: 'agenda', title: 'Agenda brokerului', description: 'Activitățile planificate pentru brokerul selectat.', parameter: 'broker' },
  { id: 'scadente', title: 'Calendarul ratelor', description: 'Rate planificate, începând cu data aleasă.', parameter: 'date' },
  { id: 'produse_clienti', title: 'Clienți și produse', description: 'Relația dintre clienți și produsele ofertate.' },
];
