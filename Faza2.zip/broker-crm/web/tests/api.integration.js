import { testProfilesAndTasks } from './profiles.integration.js';
import assert from 'node:assert/strict';
import { randomUUID, createHash } from 'node:crypto';
const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';
const token = `WEB-${randomUUID().slice(0, 8)}`;
const created = [], ids = {}, originals = {};
async function request(path, method = 'GET', body, expected = 200, headers = {}) {
  const response = await fetch(`${base}/api${path}`, { method, headers: { 'Content-Type': 'application/json', 'X-CRM-Request': '1', ...headers }, ...(body ? { body: JSON.stringify(body) } : {}) });
  const result = await response.json();
  assert.equal(response.status, expected, `${method} ${path}: ${JSON.stringify(result)}`);
  return result;
}
const fingerprint = data => createHash('sha256').update(JSON.stringify(data)).digest('hex');
const before = (await request('/bootstrap')).data;
const fingerprintBefore = fingerprint(before);
const definitions = [
  ['agentii', () => ({ denumire: token, cod_demo: token, email: `${token}@agency.example`, oras: 'Brașov' }), 'oras', 'Sibiu'],
  ['brokeri', () => ({ agentie_id: ids.agentii, nume: token, email: `${token}@broker.example`, rol: 'broker', activ: true }), 'rol', 'administrator'],
  ['clienti', () => ({ agentie_id: ids.agentii, broker_id: ids.brokeri, nume: token, tip: 'persoana', email: `${token}@client.example`, oras: 'Brașov', stare: 'prospect' }), 'oras', 'Sibiu'],
  ['asiguratori', () => ({ denumire: token, cod_demo: token, email: `${token}@insurer.example`, activ: true }), 'activ', false],
  ['produse_asigurare', () => ({ asigurator_id: ids.asiguratori, cod: token, denumire: token, categorie: 'RCA', descriere: 'Test integrare web', activ: true }), 'descriere', 'Actualizat prin API'],
  ['oportunitati', () => ({ agentie_id: ids.agentii, client_id: ids.clienti, broker_id: ids.brokeri, titlu: token, categorie: 'RCA', etapa: 'nou', sursa: 'website', valoare_estimata: '1500.00', moneda: 'RON', creat_la: '2026-11-16T09:00:00+02:00', inchis_la: null }), 'etapa', 'contactat'],
  ['oferte', () => ({ oportunitate_id: ids.oportunitati, produs_id: ids.produse_asigurare, categorie: 'RCA', numar: token, prima_anuala: '1500.00', suma_asigurata: '6000000.00', moneda: 'RON', stare: 'acceptata', emisa_la: '2026-11-16', valabila_pana: '2026-12-01' }), 'suma_asigurata', '6500000.00'],
  ['polite', () => ({ oferta_id: ids.oferte, numar: token, inceput_la: '2026-11-17', sfarsit_la: '2027-11-17', stare: 'programata', comision_procente: '10.00', emisa_la: '2026-11-16' }), 'comision_procente', '12.50'],
  ['activitati', () => ({ oportunitate_id: ids.oportunitati, tip: 'apel', subiect: token, descriere: 'Test', scadenta_la: '2026-11-18T10:00:00+02:00', finalizata_la: null, stare: 'planificata', broker_id: ids.brokeri, client_id: ids.clienti, agentie_id: ids.agentii, vizibila_de_la: '2020-01-01T00:00:00Z' }), 'subiect', `${token} modificat`],
  ['plati', () => ({ polita_id: ids.polite, numar_rata: 1, suma: '1500.00', moneda: 'RON', scadenta_la: '2026-11-17', platita_la: null, metoda: null, referinta_demo: null, stare: 'planificata' }), 'scadenta_la', '2026-11-20'],
];
try {
  assert.equal((await request('/health')).crudFunctions, 40);
  for (const [entity, bodyFn, field, nextValue] of definitions) {
    const body = bodyFn(); originals[entity] = body;
    const row = await request(`/${entity}`, 'POST', body, 201);
    ids[entity] = row.id; created.push([entity, row.id]);
    const read = await request(`/${entity}/${row.id}`); assert.equal(read.id, row.id);
    const update = { ...body, [field]: nextValue }; delete update.creat_la;
    const modified = await request(`/${entity}/${row.id}`, 'PUT', update);
    assert.equal(modified[field], nextValue, `${entity} update`);
    assert.equal((await request(`/${entity}/${row.id}`))[field], nextValue);
  }
  await request(`/agentii/${ids.agentii}`, 'DELETE', undefined, 409);
  await request(`/polite/${ids.polite}`, 'DELETE', undefined, 409);
  await request('/agentii', 'POST', originals.agentii, 409);
  await request(`/plati/${ids.plati}`, 'PUT', { ...originals.plati, suma: '-1' }, 400);
  await request(`/activitati/${ids.activitati}`, 'PUT', { ...originals.activitati, stare: 'finalizata' }, 400);
  await request(`/clienti/${ids.clienti}`, 'PUT', { ...originals.clienti, broker_id: '9223372036854775807' }, 409);
  await request(`/polite/${ids.polite}`, 'PUT', { ...originals.polite, sfarsit_la: originals.polite.inceput_la }, 400);
  await request('/agentii', 'POST', originals.agentii, 403, { 'X-CRM-Request': '' });
  await request('/constructor', 'GET', undefined, 404);
  await request('/clienti/9223372036854775807', 'GET', undefined, 404);
  await request('/clienti/9223372036854775807', 'PUT', originals.clienti, 404);
  await request('/clienti/9223372036854775807', 'DELETE', undefined, 404);
  for (const report of ['pipeline', `comparatie?id=${ids.clienti}`, 'portofoliu', `agenda?id=${ids.brokeri}`, 'scadente?date=2026-11-02', 'produse_clienti']) {
    const result = await request(`/reports/${report}`); assert.ok(result.rows.length > 0, report); assert.ok(result.columns.length);
  }
  const scoped = await request(`/reports/pipeline?agency=${ids.agentii}`);
  assert.equal(scoped.rows.length, 1); assert.equal(scoped.rows[0].agentie, token);
  await testProfilesAndTasks({ request, ids, created, token });
  console.log('PASS: 10 CREATE, 10 READ, 10 UPDATE; restrictii, validare, ID inexistent, 6 rapoarte si filtrare agentie.');
} finally {
  for (const [entity, id] of [...created].reverse()) {
    await request(`/${entity}/${id}`, 'DELETE');
    await request(`/${entity}/${id}`, 'GET', undefined, 404);
  }
  const after = (await request('/bootstrap')).data;
  assert.equal(fingerprint(after), fingerprintBefore, 'Datele initiale trebuie sa ramana identice.');
  console.log('PASS: DELETE pentru toate tabelele; toate randurile initiale sunt identice.');
}
