import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';

export async function testProfilesAndTasks({ request, ids, created, token }) {
  const add = async (entity, body) => { const row = await request(`/${entity}`, 'POST', body, 201); created.push([entity, row.id]); return row; };
  const agent2 = await add('brokeri', { agentie_id: ids.agentii, nume: `${token} agent 2`, email: `${token}-2@broker.example`, rol: 'broker', activ: true });
  const client2 = await add('clienti', { agentie_id: ids.agentii, broker_id: agent2.id, nume: `${token} client 2`, email: `${token}-2@client.example`, oras: 'Iași', tip: 'persoana', stare: 'prospect' });
  const lead2 = await add('oportunitati', { agentie_id: ids.agentii, client_id: ids.clienti, broker_id: ids.brokeri, titlu: `${token} al doilea lead`, categorie: 'RCA', etapa: 'nou', sursa: 'telefon', valoare_estimata: '2000', moneda: 'RON', creat_la: new Date().toISOString(), inchis_la: null });
  const body = { oportunitate_id: null, tip: 'reminder', subiect: `${token} sarcină internă`, descriere: 'Test programare și atribuire', scadenta_la: '2099-12-31T12:00:00Z', finalizata_la: null, stare: 'planificata', broker_id: ids.brokeri, client_id: null, agentie_id: ids.agentii, vizibila_de_la: '2020-01-01T00:00:00Z' };
  const internal = await add('activitati', body);
  const future = await add('activitati', { ...body, tip: 'email_sms', subiect: `${token} viitoare`, vizibila_de_la: '2099-01-01T12:00:00Z' });
  const direct = await add('activitati', { ...body, tip: 'de_facut', client_id: client2.id });
  const appointment = await add('activitati', { ...body, tip: 'programare', client_id: ids.clienti, oportunitate_id: lead2.id });
  const taskIds = async (broker, view) => (await request(`/tasks?broker=${broker}&view=${view}`)).rows.map(t => t.id);
  assert.ok((await taskIds(ids.brokeri, 'available')).includes(internal.id));
  assert.ok(!(await taskIds(ids.brokeri, 'available')).includes(future.id));
  assert.ok((await taskIds(ids.brokeri, 'scheduled')).includes(future.id));
  await request(`/activitati/${internal.id}`, 'PUT', { ...body, broker_id: agent2.id });
  assert.ok(!(await taskIds(ids.brokeri, 'available')).includes(internal.id));
  assert.ok((await taskIds(agent2.id, 'available')).includes(internal.id));
  await request(`/activitati/${internal.id}`, 'PUT', { ...body, broker_id: agent2.id, stare: 'finalizata', finalizata_la: new Date().toISOString() });
  assert.ok(!(await taskIds(agent2.id, 'available')).includes(internal.id));
  assert.ok((await taskIds(agent2.id, 'history')).includes(internal.id));
  await request('/tasks?broker=1&view=unknown', 'GET', undefined, 400);
  await request('/tasks', 'GET', undefined, 400);
  await request('/activitati', 'POST', { ...body, vizibila_de_la: '2100-01-01T12:00:00Z' }, 400);
  await request('/activitati', 'POST', { ...body, oportunitate_id: lead2.id, client_id: client2.id }, 409);
  const all = (await request('/bootstrap')).data;
  const foreignAgent = all.brokeri.find(b => b.agentie_id !== ids.agentii);
  await request('/activitati', 'POST', { ...body, broker_id: foreignAgent.id }, 409);
  // Compare every client and lead to independent joins of the complete fixture graph.
  for (const [kind, records] of [['client', all.clienti], ['lead', all.oportunitati]]) {
    for (const record of records) {
      const profile = await request(`/profiles/${kind}/${record.id}`);
      const opportunities = all.oportunitati.filter(o => kind === 'client' ? o.client_id === record.id : o.id === record.id);
      const offers = all.oferte.filter(f => opportunities.some(o => o.id === f.oportunitate_id));
      const policies = all.polite.filter(p => offers.some(f => f.id === p.oferta_id));
      const payments = all.plati.filter(p => policies.some(o => o.id === p.polita_id));
      const activities = all.activitati.filter(a => kind === 'client' ? a.client_id === record.id : a.oportunitate_id === record.id);
      for (const [entity, expected] of Object.entries({ oportunitati: opportunities, oferte: offers, polite: policies, plati: payments, activitati: activities })) {
        assert.deepEqual(profile.data[entity].map(r => r.id), expected.map(r => r.id), `${kind} ${record.id} ${entity}: exclusive scope`);
      }
    }
  }
  const clientProfile = await request(`/profiles/client/${ids.clienti}`);
  assert.ok(clientProfile.data.activitati.some(a => a.id === appointment.id));
  assert.ok(!clientProfile.data.activitati.some(a => a.id === direct.id));
  assert.ok(!(await request(`/profiles/lead/${ids.oportunitati}`)).data.activitati.some(a => a.id === appointment.id));
  const wrongScope = `?profileKind=lead&profileId=${ids.oportunitati}`;
  await request(`/activitati/${appointment.id}${wrongScope}`, 'DELETE', undefined, 409);
  await request(`/activitati${wrongScope}`, 'POST', { ...body, client_id: client2.id }, 409);
  const offer = all.oferte.find(o => o.id === ids.oferte);
  const { id: ignoredId, ...offerBody } = offer;
  await request(`/oferte/${offer.id}${wrongScope}`, 'PUT', { ...offerBody, oportunitate_id: lead2.id }, 409);
  assert.equal((await request(`/oferte/${offer.id}`)).oportunitate_id, ids.oportunitati, 'out-of-scope update rolls back');
  await request('/profiles/lead/9223372036854775807', 'GET', undefined, 404);
  await request('/profiles/bad/1', 'GET', undefined, 400);
  // A real clock boundary proves scheduled tasks become available without a database edit.
  const boundary = await add('activitati', { ...body, vizibila_de_la: new Date(Date.now() + 1800).toISOString() });
  assert.ok(!(await taskIds(ids.brokeri, 'available')).includes(boundary.id));
  await delay(2100);
  assert.ok((await taskIds(ids.brokeri, 'available')).includes(boundary.id));
  console.log('PASS: profiluri client/lead izolate, 4 tipuri de sarcini, reasignare, intervale, FK, rollback în afara profilului și apariție automată la termen.');
}
