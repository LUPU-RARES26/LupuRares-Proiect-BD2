import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { entities } from '../shared/entities.js';
import { validId, isDate, entityFor, validateBody } from '../server/validation.js';
import { relationOptions, formBody, agencyOf } from '../src/lib.js';

test('API field order matches all existing CREATE / UPDATE functions', () => {
  const sql = readFileSync(new URL('../../database/05_crud.sql', import.meta.url), 'utf8');
  for (const [name, entity] of Object.entries(entities)) {
    for (const op of ['create', 'update']) {
      const parameters = sql.match(new RegExp(`FUNCTION broker_crm\\.${name}_${op}\\(([\\s\\S]*?)\\)`))[1];
      const names = [...parameters.matchAll(/p_(\w+)\s+/g)].map(m => m[1]);
      assert.deepEqual(names, [...(op === 'update' ? ['id'] : []), ...entity.fields.filter(f => op === 'create' || !f.createOnly).map(f => f.key)], `${name}_${op}`);
    }
  }
});
test('only known entities and positive bigint ids are accepted', () => {
  for (const bad of ['constructor', '__proto__', 'clienti; DROP TABLE clienti']) assert.throws(() => entityFor(bad));
  for (const bad of [0, -1, '1 OR 1=1', '1.5', '9223372036854775808']) assert.throws(() => validId(bad));
  assert.equal(validId('9223372036854775807'), '9223372036854775807');
});
test('validates real dates, required inputs, full updates and unknown keys', () => {
  assert.equal(isDate('2026-02-30'), false);
  assert.equal(isDate('2028-02-29'), true);
  const body = { denumire: 'Agenție Test', cod_demo: 'TEST', email: 'test@agency.example', oras: 'Iași' };
  assert.deepEqual(validateBody('agentii', body, 'create').values, Object.values(body));
  assert.throws(() => validateBody('agentii', { ...body, id: 1 }, 'create'));
  assert.throws(() => validateBody('agentii', { ...body, email: 'bad' }, 'create'));
  assert.throws(() => validateBody('agentii', { denumire: 'Parțial' }, 'update'));
});
test('optional fields retain explicit null; decimals are not rounded silently', () => {
  const p = { polita_id: '1', numar_rata: 1, suma: '1500.25', moneda: 'RON', scadenta_la: '2027-04-01', platita_la: null, metoda: null, referinta_demo: null, stare: 'planificata' };
  const { values } = validateBody('plati', p, 'create');
  assert.equal(values[2], '1500.25'); assert.equal(values[5], null);
  assert.throws(() => validateBody('plati', { ...p, suma: '1.999' }, 'create'));
  assert.throws(() => validateBody('plati', { ...p, suma: -1 }, 'create'));
});
test('dependent selectors keep agency/category relationships and eligible accepted offers', () => {
  const data = { brokeri: [{ id: '1', agentie_id: '1' }, { id: '2', agentie_id: '2' }], produse_asigurare: [{ id: '1', categorie: 'RCA' }, { id: '2', categorie: 'CASCO' }], oferte: [{ id: '1', stare: 'acceptata' }, { id: '2', stare: 'respinsa' }, { id: '3', stare: 'acceptata' }], polite: [{ id: '1', oferta_id: '1' }] };
  assert.deepEqual(relationOptions({ key: 'broker_id', entity: 'brokeri' }, { agentie_id: '1' }, data).map(x => x.id), ['1']);
  assert.deepEqual(relationOptions({ key: 'produs_id', entity: 'produse_asigurare' }, { categorie: 'CASCO' }, data).map(x => x.id), ['2']);
  assert.deepEqual(relationOptions({ key: 'oferta_id', entity: 'oferte' }, {}, data).map(x => x.id), ['3']);
  assert.deepEqual(relationOptions({ key: 'oferta_id', entity: 'oferte' }, {}, data, { id: '1' }).map(x => x.id), ['1', '3']);
});
test('forms preserve false and optional nulls; dates keep their calendar day', () => {
  const body = formBody('asiguratori', { denumire: 'Test', cod_demo: 'TEST', email: 't@test.example', activ: false }, false);
  assert.equal(body.activ, false);
  const data = { oportunitati: [{ id: '1', agentie_id: '2' }], oferte: [{ id: '3', oportunitate_id: '1' }], polite: [{ id: '4', oferta_id: '3' }] };
  assert.equal(agencyOf('plati', { polita_id: '4' }, data), '2');
});

test('task forms require an agent and reject a deadline before visibility', () => {
  const task = { oportunitate_id: null, tip: 'reminder', subiect: 'De urmărit', descriere: 'Descriere', scadenta_la: '2027-01-01T12:00:00Z', finalizata_la: null, stare: 'planificata', broker_id: '1', client_id: null, agentie_id: '1', vizibila_de_la: '2027-01-01T12:00:00Z' };
  assert.equal(validateBody('activitati', task, 'create').values.length, 11);
  assert.throws(() => validateBody('activitati', { ...task, broker_id: null }, 'create'));
  assert.throws(() => validateBody('activitati', { ...task, vizibila_de_la: '2027-01-02T12:00:00Z' }, 'create'));
  const leads = [{ id: '1', client_id: '5', agentie_id: '1' }, { id: '2', client_id: '6', agentie_id: '1' }, { id: '3', client_id: '5', agentie_id: '2' }];
  assert.deepEqual(relationOptions({ key: 'oportunitate_id', entity: 'oportunitati' }, { client_id: '5', agentie_id: '1' }, { oportunitati: leads }).map(r => r.id), ['1']);
});
