import { HttpError, validId } from './validation.js';

export function profileScope(kind, id) {
  if (!['client', 'lead'].includes(kind)) throw new HttpError(400, 'Tip de profil invalid.');
  return { kind, id: validId(id) };
}

// Identifiers and joins are fixed; profile and row IDs are always parameters.
export function profilePredicate(kind, entity) {
  const opportunity = kind === 'client' ? 'o.client_id=$1' : 'o.id=$1';
  const queries = {
    oportunitati: `t.id IN (SELECT o.id FROM broker_crm.oportunitati o WHERE ${opportunity})`,
    oferte: `t.oportunitate_id IN (SELECT o.id FROM broker_crm.oportunitati o WHERE ${opportunity})`,
    polite: `t.oferta_id IN (SELECT f.id FROM broker_crm.oferte f JOIN broker_crm.oportunitati o ON o.id=f.oportunitate_id WHERE ${opportunity})`,
    plati: `t.polita_id IN (SELECT p.id FROM broker_crm.polite p JOIN broker_crm.oferte f ON f.id=p.oferta_id JOIN broker_crm.oportunitati o ON o.id=f.oportunitate_id WHERE ${opportunity})`,
    activitati: kind === 'client' ? 't.client_id=$1' : 't.oportunitate_id=$1',
  };
  if (!Object.hasOwn(queries, entity)) throw new HttpError(400, 'Secțiunea nu aparține profilului.');
  return queries[entity];
}

export async function readProfile(db, scope) {
  const table = scope.kind === 'client' ? 'clienti' : 'oportunitati';
  const record = (await db.query(`SELECT * FROM broker_crm.${table} WHERE id=$1`, [scope.id])).rows[0];
  if (!record) throw new HttpError(404, 'Profilul nu mai există.');
  const client = scope.kind === 'client' ? record : (await db.query('SELECT * FROM broker_crm.clienti WHERE id=$1', [record.client_id])).rows[0];
  const data = {};
  for (const entity of ['oportunitati', 'oferte', 'polite', 'activitati', 'plati']) {
    data[entity] = (await db.query(`SELECT t.* FROM broker_crm.${entity} t WHERE ${profilePredicate(scope.kind, entity)} ORDER BY t.id`, [scope.id])).rows;
  }
  return { record, client, data };
}

export async function assertInProfile(db, scope, entity, id) {
  const result = await db.query(`SELECT t.id FROM broker_crm.${entity} t WHERE ${profilePredicate(scope.kind, entity)} AND t.id=$2 FOR UPDATE OF t`, [scope.id, id]);
  if (!result.rows.length) throw new HttpError(409, 'Înregistrarea trebuie să aparțină profilului deschis.');
}
