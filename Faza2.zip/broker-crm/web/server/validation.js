import { entities } from '../shared/entities.js';

export class HttpError extends Error {
  constructor(status, message, fields = {}) { super(message); this.status = status; this.fields = fields; }
}
export function entityFor(name) {
  if (!Object.hasOwn(entities, name)) throw new HttpError(404, 'Secțiunea solicitată nu există.');
  return entities[name];
}
export function validId(value) {
  if (!/^[1-9]\d{0,18}$/.test(String(value)) || BigInt(value) > 9223372036854775807n) {
    throw new HttpError(400, 'Identificator invalid.');
  }
  return String(value);
}
export function isDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)
    && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}
export function validateBody(name, body, operation) {
  const entity = entityFor(name);
  if (!body || Array.isArray(body) || typeof body !== 'object') throw new HttpError(400, 'Datele formularului sunt invalide.');
  const fields = entity.fields.filter(f => operation === 'create' || !f.createOnly);
  const allowed = new Set(fields.map(f => f.key));
  if (Object.keys(body).some(key => !allowed.has(key))) throw new HttpError(400, 'Formularul conține câmpuri necunoscute.');
  const errors = {};
  const values = fields.map(f => {
    let value = body[f.key];
    if (typeof value === 'string') value = value.trim();
    if (value === '' || value === null || value === undefined) {
      if (f.required) errors[f.key] = 'Completează acest câmp.';
      return null;
    }
    if (f.type === 'checkbox') {
      if (typeof value !== 'boolean') errors[f.key] = 'Alege o valoare validă.';
    } else if (f.type === 'reference') {
      try { value = validId(value); } catch { errors[f.key] = 'Selectează o înregistrare validă.'; }
    } else if (f.type === 'number') {
      if (!/^-?\d+(\.\d{1,2})?$/.test(String(value)) || !Number.isFinite(Number(value)) || Number(value) < f.min || Number(value) > f.max || (f.step === '1' && !Number.isInteger(Number(value)))) {
        errors[f.key] = `Introdu o valoare între ${f.min} și ${f.max}${f.step === '1' ? ', fără zecimale' : ', cu maximum două zecimale'}.`;
      }
    } else if (typeof value !== 'string') {
      errors[f.key] = 'Introdu o valoare text validă.';
    } else if (f.type === 'select' && !f.choices.includes(value)) {
      errors[f.key] = 'Selectează o valoare din listă.';
    } else if (f.maxLength && value.length > f.maxLength) {
      errors[f.key] = `Maximum ${f.maxLength} de caractere.`;
    } else if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      errors[f.key] = 'Introdu o adresă de email validă.';
    } else if (f.type === 'date' && !isDate(value)) {
      errors[f.key] = 'Introdu o dată calendaristică validă.';
    } else if (f.type === 'datetime-local' && (!/^\d{4}-\d{2}-\d{2}T.*(Z|[+-]\d{2}:\d{2})$/.test(value) || !isDate(value.slice(0, 10)) || !Number.isFinite(Date.parse(value)))) {
      errors[f.key] = 'Introdu o dată și o oră valide, cu fus orar.';
    }
    return value;
  });
  if (name === 'activitati' && Date.parse(body.vizibila_de_la) > Date.parse(body.scadenta_la)) errors.scadenta_la = 'Termenul-limită trebuie să fie după data afișării sau la aceeași oră.';
  if (Object.keys(errors).length) throw new HttpError(400, 'Verifică informațiile din formular.', errors);
  return { fields, values };
}

export function databaseError(error) {
  if (error instanceof HttpError) return error;
  const messages = {
    '23505': [409, 'Există deja o înregistrare cu aceste date unice (cod, număr sau email). O ofertă acceptată ori o poliță nu poate fi duplicată.'],
    '23503': [409, 'Relația nu este validă sau înregistrarea este folosită în alte tabele. Verifică agenția, categoria și înregistrările asociate.'],
    '23001': [409, 'Înregistrarea are date asociate și nu poate fi ștearsă.'],
    '23514': [400, 'Datele nu respectă regulile bazei: verifică sumele, perioada și completarea datelor pentru starea selectată.'],
    '23502': [400, 'Un câmp obligatoriu nu a fost completat.'],
    '22001': [400, 'Una dintre valori depășește lungimea permisă.'],
    '22003': [400, 'Valoarea numerică depășește limita permisă.'],
    '22007': [400, 'Formatul datei este invalid.'],
    '22008': [400, 'Data introdusă nu este validă.'],
    '22P02': [400, 'Un câmp conține o valoare invalidă.'],
    '55P03': [409, 'Înregistrarea este modificată în altă sesiune. Încearcă din nou.'],
  };
  if (messages[error.code]) return new HttpError(...messages[error.code]);
  return new HttpError(503, 'Baza de date nu este disponibilă momentan. Încearcă din nou.');
}
