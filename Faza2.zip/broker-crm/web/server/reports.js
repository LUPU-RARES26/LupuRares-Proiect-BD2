// Aceleasi sase rapoarte din database/03_interogari.sql, cu parametri legati.
export const reports = {
  pipeline: `SELECT a.denumire AS agentie, o.etapa, count(*) AS oportunitati,
    sum(o.valoare_estimata) AS valoare_estimata_ron FROM broker_crm.oportunitati o
    JOIN broker_crm.agentii a ON a.id=o.agentie_id
    WHERE ($1::bigint IS NULL OR o.agentie_id=$1) GROUP BY a.id, a.denumire, o.etapa ORDER BY a.id, o.etapa`,
  comparatie: `SELECT c.nume AS client, o.titlu, f.numar, p.denumire AS produs,
    a.denumire AS asigurator, f.prima_anuala, f.stare FROM broker_crm.oferte f
    JOIN broker_crm.oportunitati o ON o.id=f.oportunitate_id JOIN broker_crm.clienti c ON c.id=o.client_id
    JOIN broker_crm.produse_asigurare p ON p.id=f.produs_id JOIN broker_crm.asiguratori a ON a.id=p.asigurator_id
    WHERE ($1::bigint IS NULL OR o.agentie_id=$1) AND c.id=$2 ORDER BY o.id, f.prima_anuala`,
  portofoliu: `SELECT p.numar, c.nume AS client, b.nume AS broker, a.denumire AS asigurator,
    pr.categorie, f.prima_anuala, p.sfarsit_la,
    round(f.prima_anuala*p.comision_procente/100,2) AS comision_estimat_ron
    FROM broker_crm.polite p JOIN broker_crm.oferte f ON f.id=p.oferta_id
    JOIN broker_crm.oportunitati o ON o.id=f.oportunitate_id JOIN broker_crm.clienti c ON c.id=o.client_id
    JOIN broker_crm.brokeri b ON b.id=o.broker_id JOIN broker_crm.produse_asigurare pr ON pr.id=f.produs_id
    JOIN broker_crm.asiguratori a ON a.id=pr.asigurator_id
    WHERE ($1::bigint IS NULL OR o.agentie_id=$1) ORDER BY p.id`,
  agenda: `SELECT ac.scadenta_la, ac.subiect, ac.tip, c.nume AS client, o.titlu
    FROM broker_crm.activitati ac LEFT JOIN broker_crm.oportunitati o ON o.id=ac.oportunitate_id
    LEFT JOIN broker_crm.clienti c ON c.id=ac.client_id
    WHERE ($1::bigint IS NULL OR ac.agentie_id=$1) AND ac.broker_id=$2 AND ac.stare='planificata' AND ac.vizibila_de_la <= now()
    ORDER BY ac.scadenta_la`,
  scadente: `SELECT p.numar, c.nume AS client, r.numar_rata, r.suma, r.scadenta_la
    FROM broker_crm.plati r JOIN broker_crm.polite p ON p.id=r.polita_id JOIN broker_crm.oferte f ON f.id=p.oferta_id
    JOIN broker_crm.oportunitati o ON o.id=f.oportunitate_id JOIN broker_crm.clienti c ON c.id=o.client_id
    WHERE ($1::bigint IS NULL OR o.agentie_id=$1) AND r.stare='planificata' AND r.scadenta_la >= $2::date
    ORDER BY r.scadenta_la, p.id`,
  produse_clienti: `SELECT DISTINCT c.id AS client_id, c.nume AS client, pr.cod, pr.denumire AS produs
    FROM broker_crm.clienti c JOIN broker_crm.oportunitati o ON o.client_id=c.id
    JOIN broker_crm.oferte f ON f.oportunitate_id=o.id JOIN broker_crm.produse_asigurare pr ON pr.id=f.produs_id
    WHERE ($1::bigint IS NULL OR o.agentie_id=$1) ORDER BY c.id, pr.cod`,
};
