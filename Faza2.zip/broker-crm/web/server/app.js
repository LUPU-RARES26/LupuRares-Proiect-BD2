import express from 'express';
import { fileURLToPath } from 'node:url';
import { entities, reportDefinitions } from '../shared/entities.js';
import { HttpError, validId, entityFor, validateBody, databaseError, isDate } from './validation.js';
import { reports } from './reports.js';
import { profileScope, readProfile, assertInProfile } from './profiles.js';

export function createApp(pool) {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.set({
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin',
      'X-Frame-Options': 'DENY',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
    });
    if (!['localhost', '127.0.0.1', '[::1]'].includes(req.hostname)) return next(new HttpError(403, 'Accesul este disponibil numai local.'));
    if (req.path.startsWith('/api')) res.set('Cache-Control', 'no-store');
    if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
      if (req.get('X-CRM-Request') !== '1' || (req.get('Sec-Fetch-Site') && !['same-origin', 'none'].includes(req.get('Sec-Fetch-Site')))) return next(new HttpError(403, 'Cererea nu provine din aplicație.'));
      const origin = req.get('origin');
      if (origin && origin !== `${req.protocol}://${req.get('host')}` && !(process.env.NODE_ENV !== 'production' && origin === 'http://127.0.0.1:5173')) return next(new HttpError(403, 'Originea cererii nu este permisă.'));
    }
    next();
  });
  app.use(express.json({ limit: '64kb' }));
  app.get('/api/health', async (req, res) => {
    const { rows } = await pool.query(`SELECT count(*)::int AS total FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='broker_crm' AND p.proname ~ '_(create|read|update|delete)$'`);
    res.status(rows[0].total === 40 ? 200 : 503).json({ status: rows[0].total === 40 ? 'ok' : 'crud_missing', crudFunctions: rows[0].total });
  });
  app.get('/api/bootstrap', async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
      const data = {};
      for (const name of Object.keys(entities)) data[name] = (await client.query(`SELECT * FROM broker_crm.${name}_read()`)).rows;
      await client.query('COMMIT');
      res.json({ data, loadedAt: new Date().toISOString() });
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  });
  app.get('/api/reports/:name', async (req, res) => {
    const definition = reportDefinitions.find(r => r.id === req.params.name);
    if (!definition) throw new HttpError(404, 'Raportul nu există.');
    const params = [req.query.agency ? validId(req.query.agency) : null];
    if (definition.parameter === 'client' || definition.parameter === 'broker') params.push(validId(req.query.id));
    if (definition.parameter === 'date') {
      if (!isDate(req.query.date)) throw new HttpError(400, 'Alege data de început.');
      params.push(req.query.date);
    }
    const result = await pool.query(reports[definition.id], params);
    res.json({ rows: result.rows, columns: result.fields.map(f => f.name) });
  });
  app.get('/api/profiles/:kind/:id', async (req, res) => {
    const scope = profileScope(req.params.kind, req.params.id);
    const client = await pool.connect();
    try {
      await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
      const profile = await readProfile(client, scope);
      await client.query('COMMIT'); res.json(profile);
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  });
  app.get('/api/tasks', async (req, res) => {
    const broker = validId(req.query.broker);
    const view = req.query.view || 'available';
    const clauses = {
      available: "stare='planificata' AND vizibila_de_la <= now()",
      scheduled: "stare='planificata' AND vizibila_de_la > now()",
      history: "stare IN ('finalizata','anulata')",
    };
    if (!Object.hasOwn(clauses, view)) throw new HttpError(400, 'Lista de sarcini este invalidă.');
    const agency = req.query.agency ? validId(req.query.agency) : null;
    const { rows } = await pool.query(`SELECT * FROM broker_crm.activitati WHERE broker_id=$1 AND ($2::bigint IS NULL OR agentie_id=$2) AND ${clauses[view]} ORDER BY scadenta_la, id`, [broker, agency]);
    res.json({ rows });
  });
  app.get('/api/:entity', async (req, res) => {
    entityFor(req.params.entity);
    const { rows } = await pool.query(`SELECT * FROM broker_crm.${req.params.entity}_read()`);
    res.json({ rows });
  });
  app.get('/api/:entity/:id', async (req, res) => {
    entityFor(req.params.entity);
    const { rows } = await pool.query(`SELECT * FROM broker_crm.${req.params.entity}_read($1)`, [validId(req.params.id)]);
    if (!rows.length) throw new HttpError(404, 'Înregistrarea nu mai există.');
    res.json(rows[0]);
  });
  for (const [method, operation] of [['post', 'create'], ['put', 'update'], ['delete', 'delete']]) {
    app[method](`/api/:entity${operation === 'create' ? '' : '/:id'}`, async (req, res) => {
      const name = req.params.entity;
      entityFor(name); // identifiers below come only from this allowlist, never arbitrary user input
      const id = operation === 'create' ? null : validId(req.params.id);
      const params = operation === 'delete' ? [id] : validateBody(name, req.body, operation).values;
      if (operation === 'update') params.unshift(id);
      const placeholders = params.map((_, i) => `$${i + 1}`).join(', ');
      const scope = req.query.profileKind || req.query.profileId ? profileScope(req.query.profileKind, req.query.profileId) : null;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        if (scope && operation !== 'create') await assertInProfile(client, scope, name, id);
        const { rows } = await client.query(`SELECT * FROM broker_crm.${name}_${operation}(${placeholders})`, params);
        if (!rows.length) throw new HttpError(404, 'Înregistrarea nu mai există. Reîncarcă lista.');
        if (scope && operation !== 'delete') await assertInProfile(client, scope, name, rows[0].id);
        await client.query('COMMIT');
        res.status(operation === 'create' ? 201 : 200).json(rows[0]);
      } catch (error) { await client.query('ROLLBACK'); throw error; }
      finally { client.release(); }
    });
  }
  app.use('/api', (req, res, next) => next(new HttpError(404, 'Adresa API nu există.')));
  const dist = fileURLToPath(new URL('../dist/', import.meta.url));
  app.use(express.static(dist, { index: false }));
  app.get('/{*path}', (req, res) => res.sendFile(`${dist}/index.html`));
  app.use((error, req, res, next) => {
    if (res.headersSent) return next(error);
    const parsed = error.type === 'entity.parse.failed' ? new HttpError(400, 'Corpul JSON este invalid.') : error.type === 'entity.too.large' ? new HttpError(413, 'Formularul este prea mare.') : databaseError(error);
    if (parsed.status >= 500) console.error('Request failed:', error.code || error.name);
    res.status(parsed.status).json({ error: parsed.message, fields: parsed.fields });
  });
  return app;
}
