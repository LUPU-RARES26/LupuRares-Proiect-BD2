import pg from 'pg';
import { createApp } from './app.js';
// Preserve dates without a timezone shift. bigint and numeric remain strings.
pg.types.setTypeParser(1082, value => value);
const pool = new pg.Pool({
  host: process.env.PGHOST || '127.0.0.1', port: Number(process.env.PGPORT || 5434),
  database: process.env.PGDATABASE || 'broker_crm', user: process.env.PGUSER || 'broker_demo',
  password: process.env.PGPASSWORD, max: 8, connectionTimeoutMillis: 5000,
  statement_timeout: 10000, idleTimeoutMillis: 30000,
  options: '-c timezone=Europe/Bucharest -c lock_timeout=5000',
});
pool.on('error', error => console.error('Database connection:', error.code));
const port = Number(process.env.PORT || 3000);
const server = createApp(pool).listen(port, process.env.HOST || '127.0.0.1', () => console.log(`Broker CRM: http://localhost:${port}`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => server.close(() => pool.end().finally(() => process.exit(0))));
