# Rezultatul verificarii — 2 noiembrie 2026

Schema si fixture-urile au fost executate cu succes pe PostgreSQL local, apoi in Docker. Instanta curenta este PostgreSQL 18.6 in containerul `broker-crm-postgres-1`, la `127.0.0.1:5434`, baza `broker_crm`, schema `broker_crm`. Containerul raporteaza starea `healthy` si foloseste volumul persistent `broker-crm_postgres_data`.

- 10 tabele si 256 inregistrari, conform numarului documentat pentru fiecare tabel.
- Chei straine si reguli de integritate active; 8 incercari cu date invalide au fost respinse.
- Totalul ratelor coincide cu prima anuala pentru fiecare polita.
- Fiecare oportunitate castigata are polita, iar fiecare polita apartine unei oportunitati castigate.
- Starea clientilor corespunde portofoliului demo.
- Cele 6 interogari demonstrative au fost executate cu succes.
- Rularea repetata a actiunii `Setup` a pastrat cele 256 de randuri, fara duplicare.
- Instanta temporara folosita pentru testare a fost oprita. Instanta locala de pe portul 5433 este separata de cea curenta, din Docker, de pe portul 5434.
- Verificarile SQL si cele sase rapoarte au trecut si in containerul Docker.
- Reluarea `scripts/docker.ps1 Setup` a pastrat datele existente si a trecut verificarile.
- Conectarea la container din Windows, prin portul 5434 si autentificare cu parola, a fost verificata.

Mesajul verificarii SQL:

```text
PASS: 10 tabele, 256 randuri, consistenta fixtures si 8 teste de respingere.
```

Pornirea prin Docker Compose si autentificarea prin scriptul `scripts/docker.ps1` au fost verificate. Profilul VS Code pentru container se numeste `Broker CRM - Docker`; interfata extensiei poate solicita parola din `.env`.

## Verificare CRUD — 15 noiembrie 2026

Au fost instalate in baza curenta din Docker **40 de functii**, cate patru pentru fiecare dintre cele 10 tabele. Numarul a fost verificat in catalogul PostgreSQL `pg_proc`. Nu au fost adaugate tabele permanente sau trigger-e definite de utilizator.

Au trecut urmatoarele verificari:

- Instalare si reinstalare a `05_crud.sql`, fara modificarea fixture-urilor.
- Integrare pe o baza temporara cu schema goala, apoi pe aceeasi schema populata cu fixture-uri.
- Create, Read, Update si Delete pentru fiecare tabel: valorile returnate si cele din tabele, liste complete, ID-uri inexistente si stergeri repetate.
- Zece cazuri invalide respinse de constrangeri, prin apelarea functiilor CRUD.
- Transmiterea explicita a valorii `NULL` pentru golirea campurilor optionale, impreuna cu starea corespunzatoare.
- Compararea tuturor valorilor randurilor existente inainte si dupa scenariul de test; valorile au ramas identice.
- Executarea completa a demonstratiei, in ordine corecta a dependentelor, incheiata cu `ROLLBACK`.
- Executarea celor trei comenzi exacte configurate pentru sarcinile CRUD din VS Code, prin Docker CLI.
- Verificarea finala a fixture-urilor: exact 10 tabele, 256 de randuri, coerenta si opt respingeri.
- Curatarea bazei temporare de test; containerul proiectului ramane pornit.

Mesajul testelor CRUD:

```text
PASS CRUD: 40 operatii, liste/cazuri id inexistent, 10 respingeri, NULL explicit; datele existente sunt identice.
```

Scripturile PowerShell au fost verificate sintactic, iar cel Docker a fost executat cu PowerShell 7. Windows PowerShell blocheaza fisierul `.ps1` prin politica sa curenta; sarcinile CRUD din VS Code folosesc direct Docker si nu necesita schimbarea acestei politici. Instanta locala separata de pe portul 5433 nu a fost modificata sau testata in aceasta continuare.

`ROLLBACK` pastreaza randurile initiale, dar nu deruleaza inapoi secventele IDENTITY. Functiile CRUD nu implementeaza autentificare, acces pe agentie sau fluxuri comerciale multi-tabel; aceste responsabilitati raman pentru etapa aplicatiei.

## Aplicatia web — 16 noiembrie 2026

- Frontendul a fost construit cu Vite, inclusiv in imaginea Docker; containerele `web` si `postgres` au trecut verificarile de sanatate.
- Sase teste automate au trecut: corespondenta parametrilor API cu toate functiile SQL Create/Update, identificatori si entitati permise, date calendaristice si campuri obligatorii, zecimale si NULL, selectoare relationale si conversia formularelor.
- Testul HTTP a executat Create/Read/Update/Delete pentru toate cele 10 tabele. A verificat erori de integritate, corpuri invalide, ID inexistent, respingerea scrierilor fara antetul aplicatiei, toate cele sase rapoarte si filtrarea pe agentie.
- Testul de integrare a trecut si in containerul aplicatiei. Compara toate valorile initiale si curata numai inregistrarile create de el.
- Browserul integrat a afisat toate cele 10 pagini de tabele si toate cele sase rapoarte. Au fost verificate cautarea, modificarea clientului temporar, persistenta dupa reincarcare, confirmarea de stergere si selectarea agentiei.
- Filtrul Bucuresti a afisat 12 clienti, 9 polite active, 4 oportunitati deschise si 9 rate planificate; fara filtru, valorile sunt 24, 18, 8, 18.
- Designul a fost verificat la dimensiunea conceptului, 1488 × 1056, la dimensiunea normala a browserului integrat si pe mobil, 390 × 844. La 390 px documentul nu depaseste latimea ecranului; tabelele se deruleaza in containerul propriu, iar comenzile formularului sunt accesibile.
- Clientul temporar creat din browser a fost eliminat prin API. Verificarea SQL finala a confirmat din nou exact 10 tabele, 256 de randuri, coerenta fixture-urilor si cele opt respingeri.

Capturi si comparatia cu conceptele: `web/design/VERIFICARE_VIZUALA.md`. Limitele functionale si comenzile de rulare sunt documentate in `SITE.md`.
## Verificare profiluri și sarcini — 16 noiembrie 2026

- Migrarea 08 a fost aplicată peste volumul existent, după backup pg_dump. Reaplicarea prin serviciul `migrate` a trecut fără duplicarea datelor sau a funcțiilor.
- 7 teste unitare trecute, inclusiv ordinea parametrilor SQL și regulile temporale ale sarcinilor.
- `api.integration.js` și `profiles.integration.js`: CRUD pe toate tabelele, cele șase rapoarte, compararea fiecărui profil cu legăturile independente ale tuturor datelor, atribuiri/repuneri în istoric, toate cele patru tipuri, FK, context de profil, rollback la încercarea de mutare în alt profil și apariție automată după atingerea datei afișării.
- Fingerprintul JSON al datelor existente este identic înainte/după testele HTTP. Migrarea păstrează valorile vechi ale celor 60 de activități și completează atributele nou-adăugate.
- SQL `04_verificare.sql`, `07_verificare_crud.sql` și cele șase interogări actualizate au trecut. Rămân 10 tabele, 256 de rânduri și 40 de funcții.
- Browser: clientul #1 are două oportunități, o poliță, două plăți și patru activități; leadul #25 are zero polițe/plăți și două activități. Formularul de plată al clientului afișează numai polița acestuia.
- Sarcină UI temporară creată pentru Elena Demo, programată în viitor, apoi modificată pentru disponibilitate și finalizată. A fost vizibilă în lista agentului potrivit și apoi în Istoric; ulterior a fost eliminată prin API.
- Desktop 1488×1056 și mobil 390×844: liste, profiluri, file orizontale, formular derulabil și subsol fix verificate. Fără depășirea orizontală a documentului. Consola browserului nu a raportat erori JavaScript.
- Docker: serviciile postgres/web healthy; `migrate` terminat cu cod 0. MongoDB și instanțele PostgreSQL locale separate nu au fost folosite.
